# تنظیمات لازم اندروید (بعد از `flutter create .`)

این پوشه فقط «وصله» است؛ فایل‌های پروژه اندروید را خود Flutter می‌سازد.
بعد از اجرای `flutter create .` این سه تغییر را انجام دهید.

## ۱) `android/app/src/main/AndroidManifest.xml`

داخل تگ `<manifest>` و **بیرون** از `<application>` این خط‌ها را اضافه کنید:

```xml
<uses-permission android:name="android.permission.USE_BIOMETRIC"/>
<uses-permission android:name="android.permission.USE_FINGERPRINT"/>
<uses-permission android:name="android.permission.VIBRATE"/>
```

نام برنامه را هم فارسی کنید:

```xml
<application
    android:label="گچ صدف"
    android:icon="@mipmap/ic_launcher">
```

> برای خواندن/نوشتن فایل بکاپ به هیچ مجوز اضافی نیاز نیست؛
> `file_picker` و `share_plus` از سیستم فایل خود اندروید (SAF) استفاده می‌کنند.

## ۲) `MainActivity` باید `FlutterFragmentActivity` باشد

پلاگین `local_auth` (اثر انگشت) روی `FlutterActivity` کار نمی‌کند.
فایل `android/app/src/main/kotlin/.../MainActivity.kt` را این‌گونه کنید:

```kotlin
package com.gachsadaf.app   // همان package خودتان

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity : FlutterFragmentActivity()
```

و در `android/app/src/main/res/values/styles.xml` (و `values-night`)
والد تم را به یکی از تم‌های AppCompat تغییر دهید:

```xml
<style name="LaunchTheme" parent="Theme.AppCompat.DayNight.NoActionBar">
```

## ۳) `android/app/build.gradle`

```gradle
android {
    compileSdk 35

    defaultConfig {
        applicationId "com.gachsadaf.app"
        minSdk 23          // برای local_auth و sqflite لازم است
        targetSdk 35
    }
}
```

## آیکن برنامه

```bash
# تصویر assets/images/crest.png را به عنوان آیکن استفاده کنید
flutter pub add dev:flutter_launcher_icons
```

در `pubspec.yaml`:

```yaml
flutter_launcher_icons:
  android: true
  ios: true
  image_path: "assets/images/crest.png"
  adaptive_icon_background: "#133A57"
  adaptive_icon_foreground: "assets/images/crest.png"
```

سپس:

```bash
dart run flutter_launcher_icons
```
