import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'customers.dart';
import 'models.dart';

/// بک‌اند برنامه: SQLite محلی روی خود گوشی — بدون انترنت و بدون سرور
class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();

  static const String fileName = 'gach_sadaf.db';
  static const int schemaVersion = 5;

  Database? _db;

  Future<Database> get database async {
    _db ??= await _open();
    return _db!;
  }

  Future<String> databaseFilePath() async {
    final dir = await getDatabasesPath();
    return p.join(dir, fileName);
  }

  Future<Database> _open() async {
    final path = await databaseFilePath();
    return openDatabase(
      path,
      version: schemaVersion,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, v) async {
        for (final sql in _schema) {
          await db.execute(sql);
        }
      },
      // نصب‌های قبلی برنامه فقط جدول جدید «انبار» را می‌گیرند؛
      // هیچ داده‌ای از کارگران/سنگ/تولید/فروش/مصارف پاک یا دست‌کاری نمی‌شود
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 3) {
          // انبار به‌تفکیک «نوع گچ + وزن هر خلته» (موجودی در پایان از رکوردها ساخته می‌شود)
          await db.execute('DROP TABLE IF EXISTS stock');
          await db.execute(_stockTableSql);
        }
        if (oldV < 4) {
          // مشتریان: جدول جدا با ID یکتا؛ فروش‌ها با customer_id به آن وصل می‌شوند
          await db.execute(customersTableSql);
          await db.execute(
              'ALTER TABLE sales ADD COLUMN customer_id INTEGER REFERENCES customers(id)');
          await db.execute(
              'CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id)');
          await backfillCustomers(db);
        }
        if (oldV < 5) {
          // فاکتور چند‌قلمی: هر فروش چند قلم دارد (جدول sale_items) + تخفیف
          await db.execute('ALTER TABLE sales ADD COLUMN discount REAL DEFAULT 0');
          await db.execute(_saleItemsTableSql);
          await db.execute(
              'CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id)');
          await backfillSaleItems(db);
        }
        if (oldV < 5) {
          // موجودی انبار از روی تولیدها و اقلام فروش دوباره ساخته می‌شود
          await rebuildStock(db);
        }
      },
    );
  }

  static const List<String> _schema = [
    customersTableSql,
    '''
    CREATE TABLE workers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inv_num TEXT,
      name TEXT NOT NULL,
      shift TEXT,
      start_date TEXT,
      end_date TEXT,
      gunny REAL DEFAULT 0,
      extra_gunny REAL DEFAULT 0,
      rate REAL DEFAULT 0,
      cur TEXT,
      total REAL DEFAULT 0,
      paid REAL DEFAULT 0,
      remaining REAL DEFAULT 0,
      paid_date TEXT,
      paid_time TEXT
    )''',
    '''
    CREATE TABLE stones(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inv_num TEXT,
      seller TEXT NOT NULL,
      type TEXT,
      weight REAL DEFAULT 0,
      price_per_ton REAL DEFAULT 0,
      total REAL DEFAULT 0,
      cur TEXT,
      paid REAL DEFAULT 0,
      remaining REAL DEFAULT 0,
      date TEXT,
      paid_date TEXT,
      driver TEXT,
      driver_rate REAL DEFAULT 0,
      driver_total REAL DEFAULT 0,
      driver_cur TEXT,
      driver_paid REAL DEFAULT 0,
      driver_rem REAL DEFAULT 0,
      deliver_date TEXT,
      driver_paid_date TEXT
    )''',
    '''
    CREATE TABLE production(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inv_num TEXT,
      date TEXT,
      type TEXT,
      gunny REAL DEFAULT 0,
      bag_weight REAL DEFAULT 0
    )''',
    '''
    CREATE TABLE sales(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inv_num TEXT,
      buyer TEXT NOT NULL,
      phone TEXT,
      location TEXT,
      gypsum_type TEXT,
      bag_weight REAL DEFAULT 0,
      qty REAL DEFAULT 0,
      bag_price REAL DEFAULT 0,
      order_type TEXT,
      total REAL DEFAULT 0,
      paid REAL DEFAULT 0,
      remaining REAL DEFAULT 0,
      cur TEXT,
      date TEXT,
      time TEXT,
      truck TEXT,
      customer_id INTEGER REFERENCES customers(id),
      discount REAL DEFAULT 0
    )''',
    '''
    CREATE TABLE expenses(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inv_num TEXT,
      item TEXT NOT NULL,
      price REAL DEFAULT 0,
      paid REAL DEFAULT 0,
      remaining REAL DEFAULT 0,
      cur TEXT,
      date TEXT,
      time TEXT
    )''',
    'CREATE INDEX idx_sales_date ON sales(date)',
    'CREATE INDEX idx_exp_date ON expenses(date)',
    'CREATE INDEX idx_prod_date ON production(date)',
    'CREATE INDEX idx_stones_date ON stones(date)',
    'CREATE INDEX idx_sales_customer ON sales(customer_id)',
    _saleItemsTableSql,
    'CREATE INDEX idx_sale_items_sale ON sale_items(sale_id)',
    _stockTableSql,
  ];

  /// اقلام فاکتور فروش — با حذف فاکتور، اقلامش هم خودکار حذف می‌شود
  static const String _saleItemsTableSql = '''
    CREATE TABLE IF NOT EXISTS sale_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
      type TEXT NOT NULL DEFAULT '',
      weight REAL NOT NULL DEFAULT 0,
      qty REAL NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0,
      line_total REAL NOT NULL DEFAULT 0
    )''';

  /// فروش‌هایی که هنوز قلم ندارند (فروش‌های قدیمی یا بکاپ قدیمی) از ستون‌های قدیمی
  /// یک قلم می‌گیرند؛ مجموع آن‌ها عیناً حفظ می‌شود.
  static Future<void> backfillSaleItems(DatabaseExecutor db) async {
    final rows = await db.query('sales',
        where: 'id NOT IN (SELECT DISTINCT sale_id FROM sale_items)');
    for (final r in rows) {
      final qty = (r['qty'] as num?)?.toDouble() ?? 0;
      final type = (r['gypsum_type'] ?? '').toString();
      if (qty <= 0 && type.trim().isEmpty) continue;
      final total = (r['total'] as num?)?.toDouble() ?? 0;
      final discount = (r['discount'] as num?)?.toDouble() ?? 0;
      await db.insert('sale_items', {
        'sale_id': r['id'],
        'type': normalizeCustomerName(type),
        'weight': (r['bag_weight'] as num?)?.toDouble() ?? 0,
        'qty': qty,
        'price': (r['bag_price'] as num?)?.toDouble() ?? 0,
        'line_total': total + discount,
      });
    }
  }

  /// انبار: موجودی هر نوع گچ به‌تفکیک وزن هر خلته (به تعداد خلته)
  /// مثلاً «گچ سفید ۲۰ کیلویی: ۱۵۰ خلته» و «گچ سفید ۱۷ کیلویی: ۵۰ خلته»
  static const String _stockTableSql = '''
    CREATE TABLE IF NOT EXISTS stock(
      type TEXT NOT NULL,
      weight REAL NOT NULL DEFAULT 0,
      qty REAL NOT NULL DEFAULT 0,
      PRIMARY KEY (type, weight)
    )''';

  static const String untypedStock = '—بدون نوعیت—';

  /// کلید یکسان برای نوع گچ (خالی = بدون نوعیت)
  static String stockType(String type) {
    final t = normalizeCustomerName(type);
    return t.isEmpty ? untypedStock : t;
  }

  /// وزن با سه رقم اعشار گرد می‌شود تا مقایسهٔ اعشاری مشکل نسازد
  static double stockWeight(double w) => (w * 1000).round() / 1000;

  /// بازسازی کامل انبار از روی همهٔ رکوردهای تولید (+) و فروش (−)
  static Future<void> rebuildStock(DatabaseExecutor db) async {
    final totals = <String, Map<double, double>>{};

    void add(String type, double weight, double delta) {
      final t = stockType(type);
      final w = stockWeight(weight);
      final m = totals.putIfAbsent(t, () => <double, double>{});
      m[w] = (m[w] ?? 0) + delta;
    }

    for (final r in await db.query('production')) {
      add((r['type'] ?? '').toString(), (r['bag_weight'] as num?)?.toDouble() ?? 0,
          (r['gunny'] as num?)?.toDouble() ?? 0);
    }
    for (final r in await db.query('sale_items')) {
      add((r['type'] ?? '').toString(), (r['weight'] as num?)?.toDouble() ?? 0,
          -((r['qty'] as num?)?.toDouble() ?? 0));
    }

    await db.delete('stock');
    final batch = db.batch();
    totals.forEach((type, byWeight) {
      byWeight.forEach((weight, qty) {
        batch.insert('stock', {'type': type, 'weight': weight, 'qty': qty});
      });
    });
    await batch.commit(noResult: true);
  }

  // ───────────────────── عملیات عمومی ─────────────────────

  Future<List<Map<String, Object?>>> rows(String table) async {
    final db = await database;
    return db.query(table, orderBy: 'id DESC');
  }

  Future<Map<String, Object?>?> row(String table, int id) async {
    final db = await database;
    final r = await db.query(table, where: 'id = ?', whereArgs: [id], limit: 1);
    return r.isEmpty ? null : r.first;
  }

  Future<int> insert(String table, Map<String, Object?> data) async {
    final db = await database;
    final d = Map<String, Object?>.from(data)..remove('id');
    return db.insert(table, d);
  }

  Future<int> update(String table, int id, Map<String, Object?> data) async {
    final db = await database;
    final d = Map<String, Object?>.from(data)..remove('id');
    return db.update(table, d, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> delete(String table, int id) async {
    final db = await database;
    return db.delete(table, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> clear(String table) async {
    final db = await database;
    await db.delete(table);
    await db.delete('sqlite_sequence', where: 'name = ?', whereArgs: [table]);
  }

  /// اقلام فاکتورهایی که هنوز قلم ندارند (بکاپ قدیمی) از ستون‌های قدیمی ساخته می‌شود
  Future<void> backfillSaleItemsNow() async {
    final db = await database;
    await db.transaction((txn) => backfillSaleItems(txn));
  }

  Future<void> clearAll() async {
    await clear(T.saleItems);
    for (final t in T.all) {
      await clear(t);
    }
    // مشتریان بعد از فروش‌ها پاک می‌شوند (فروش به مشتری ارجاع دارد)
    await clear(T.customers);
    final db = await database;
    await db.delete('stock');
  }

  Future<int> count(String table) async {
    final db = await database;
    final r = await db.rawQuery('SELECT COUNT(*) AS c FROM $table');
    return (r.first['c'] as int?) ?? 0;
  }

  /// شماره فاکتور بعدی — مثلا F-0001
  Future<String> nextInvoiceNumber(String table) async {
    final n = await count(table) + 1;
    return '${T.prefix[table]}-${n.toString().padLeft(4, '0')}';
  }

  /// درج گروهی (برای بازگردانی بکاپ) — داخل یک ترنزکشن
  Future<void> bulkInsert(String table, List<Map<String, Object?>> items,
      {bool keepIds = false}) async {
    final db = await database;
    final batch = db.batch();
    for (final item in items) {
      final d = Map<String, Object?>.from(item);
      if (!keepIds) d.remove('id');
      batch.insert(table, d);
    }
    await batch.commit(noResult: true);
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
