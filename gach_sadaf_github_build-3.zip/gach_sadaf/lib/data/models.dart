import '../core/format.dart';

/// نام جدول‌ها — در کل برنامه از همین ثابت‌ها استفاده می‌شود
class T {
  static const workers = 'workers';
  static const stones = 'stones';
  static const production = 'production';
  static const sales = 'sales';
  static const expenses = 'expenses';
  static const saleItems = 'sale_items'; // اقلام فاکتور فروش (در T.all نیست)
  static const customers = 'customers'; // جدول مشتریان (در T.all نیست؛ جدا مدیریت می‌شود)

  static const all = [workers, stones, production, sales, expenses];

  static const labels = {
    workers: 'کارگران',
    stones: 'خرید سنگ',
    production: 'تولید',
    sales: 'فروشات',
    expenses: 'مصارف',
    customers: 'مشتریان',
  };

  /// پیشوند شماره فاکتور
  static const prefix = {
    workers: 'K',
    stones: 'S',
    production: 'T',
    sales: 'F',
    expenses: 'M',
  };
}

abstract class Rec {
  int? id;
  String invNum;
  Rec(this.id, this.invNum);

  Map<String, Object?> toMap();
  String get table;

  /// تاریخ اصلی رکورد (برای فلتر گزارش)
  String get mainDate;
}

// ─────────────────────────── کارگران ───────────────────────────
/// حقوق کارگر بر اساس تعداد خلته گچ که تولید کرده محاسبه می‌شود، نه روز کاری
class Worker extends Rec {
  String name;
  String shift;
  String startDate;
  String endDate;
  double gunny; // تعداد خلته تولید شده توسط این کارگر
  double extraGunny; // خلته اضافی / اضافه‌کاری
  double rate; // پول فی خلته
  String cur;
  double total;
  double paid;
  double remaining;
  String paidDate;
  String paidTime;

  Worker({
    int? id,
    String invNum = '',
    this.name = '',
    this.shift = 'روز',
    this.startDate = '',
    this.endDate = '',
    this.gunny = 0,
    this.extraGunny = 0,
    this.rate = 0,
    this.cur = kAfghani,
    this.total = 0,
    this.paid = 0,
    this.remaining = 0,
    this.paidDate = '',
    this.paidTime = '',
  }) : super(id, invNum);

  @override
  String get table => T.workers;
  @override
  String get mainDate => startDate;

  void recalc() {
    total = (gunny + extraGunny) * rate;
    remaining = total - paid;
  }

  @override
  Map<String, Object?> toMap() => {
        'id': id,
        'inv_num': invNum,
        'name': name,
        'shift': shift,
        'start_date': startDate,
        'end_date': endDate,
        'gunny': gunny,
        'extra_gunny': extraGunny,
        'rate': rate,
        'cur': cur,
        'total': total,
        'paid': paid,
        'remaining': remaining,
        'paid_date': paidDate,
        'paid_time': paidTime,
      };

  static Worker fromMap(Map<String, Object?> m) => Worker(
        id: m['id'] as int?,
        invNum: (m['inv_num'] ?? '').toString(),
        name: (m['name'] ?? '').toString(),
        shift: (m['shift'] ?? 'روز').toString(),
        startDate: (m['start_date'] ?? '').toString(),
        endDate: (m['end_date'] ?? '').toString(),
        gunny: toDouble(m['gunny']),
        extraGunny: toDouble(m['extra_gunny']),
        rate: toDouble(m['rate']),
        cur: (m['cur'] ?? kAfghani).toString(),
        total: toDouble(m['total']),
        paid: toDouble(m['paid']),
        remaining: toDouble(m['remaining']),
        paidDate: (m['paid_date'] ?? '').toString(),
        paidTime: (m['paid_time'] ?? '').toString(),
      );
}

// ─────────────────────────── خرید سنگ ───────────────────────────
class Stone extends Rec {
  String seller;
  String type;
  double weight;
  double pricePerTon;
  double total;
  String cur;
  double paid;
  double remaining;
  String date;
  String paidDate;
  String driver;
  double driverRate;
  double driverTotal;
  String driverCur;
  double driverPaid;
  double driverRem;
  String deliverDate;
  String driverPaidDate;

  Stone({
    int? id,
    String invNum = '',
    this.seller = '',
    this.type = '',
    this.weight = 0,
    this.pricePerTon = 0,
    this.total = 0,
    this.cur = kAfghani,
    this.paid = 0,
    this.remaining = 0,
    this.date = '',
    this.paidDate = '',
    this.driver = '',
    this.driverRate = 0,
    this.driverTotal = 0,
    this.driverCur = kAfghani,
    this.driverPaid = 0,
    this.driverRem = 0,
    this.deliverDate = '',
    this.driverPaidDate = '',
  }) : super(id, invNum);

  @override
  String get table => T.stones;
  @override
  String get mainDate => date;

  void recalc() {
    if (weight > 0 && pricePerTon > 0) total = weight * pricePerTon;
    remaining = total - paid;
    if (weight > 0 && driverRate > 0) driverTotal = weight * driverRate;
    driverRem = driverTotal - driverPaid;
  }

  @override
  Map<String, Object?> toMap() => {
        'id': id,
        'inv_num': invNum,
        'seller': seller,
        'type': type,
        'weight': weight,
        'price_per_ton': pricePerTon,
        'total': total,
        'cur': cur,
        'paid': paid,
        'remaining': remaining,
        'date': date,
        'paid_date': paidDate,
        'driver': driver,
        'driver_rate': driverRate,
        'driver_total': driverTotal,
        'driver_cur': driverCur,
        'driver_paid': driverPaid,
        'driver_rem': driverRem,
        'deliver_date': deliverDate,
        'driver_paid_date': driverPaidDate,
      };

  static Stone fromMap(Map<String, Object?> m) => Stone(
        id: m['id'] as int?,
        invNum: (m['inv_num'] ?? '').toString(),
        seller: (m['seller'] ?? '').toString(),
        type: (m['type'] ?? '').toString(),
        weight: toDouble(m['weight']),
        pricePerTon: toDouble(m['price_per_ton']),
        total: toDouble(m['total']),
        cur: (m['cur'] ?? kAfghani).toString(),
        paid: toDouble(m['paid']),
        remaining: toDouble(m['remaining']),
        date: (m['date'] ?? '').toString(),
        paidDate: (m['paid_date'] ?? '').toString(),
        driver: (m['driver'] ?? '').toString(),
        driverRate: toDouble(m['driver_rate']),
        driverTotal: toDouble(m['driver_total']),
        driverCur: (m['driver_cur'] ?? kAfghani).toString(),
        driverPaid: toDouble(m['driver_paid']),
        driverRem: toDouble(m['driver_rem']),
        deliverDate: (m['deliver_date'] ?? '').toString(),
        driverPaidDate: (m['driver_paid_date'] ?? '').toString(),
      );
}

// ─────────────────────────── تولید ───────────────────────────
class Production extends Rec {
  String date;
  String type;
  double gunny;
  double bagWeight;

  Production({
    int? id,
    String invNum = '',
    this.date = '',
    this.type = '',
    this.gunny = 0,
    this.bagWeight = 0,
  }) : super(id, invNum);

  @override
  String get table => T.production;
  @override
  String get mainDate => date;

  double get totalWeight => gunny * bagWeight;

  @override
  Map<String, Object?> toMap() => {
        'id': id,
        'inv_num': invNum,
        'date': date,
        'type': type,
        'gunny': gunny,
        'bag_weight': bagWeight,
      };

  static Production fromMap(Map<String, Object?> m) => Production(
        id: m['id'] as int?,
        invNum: (m['inv_num'] ?? '').toString(),
        date: (m['date'] ?? '').toString(),
        type: (m['type'] ?? '').toString(),
        gunny: toDouble(m['gunny']),
        bagWeight: toDouble(m['bag_weight']),
      );
}

// ─────────────────────────── فروشات ───────────────────────────
class Sale extends Rec {
  String buyer;
  String phone;
  String location;
  String gypsumType;
  double bagWeight;
  double qty;
  double bagPrice;
  String orderType;
  double total;
  double paid;
  double remaining;
  String cur;
  String date;
  String time;
  String truck;
  int? customerId;
  double discount;

  /// اقلام فاکتور (هر قلم: نوع گچ، وزن هر خلته، تعداد، قیمت). در جدول جدا ذخیره می‌شود.
  List<SaleItem> items = [];

  Sale({
    int? id,
    String invNum = '',
    this.buyer = '',
    this.phone = '',
    this.location = '',
    this.gypsumType = '',
    this.bagWeight = 0,
    this.qty = 0,
    this.bagPrice = 0,
    this.orderType = '',
    this.total = 0,
    this.paid = 0,
    this.remaining = 0,
    this.cur = kAfghani,
    this.date = '',
    this.time = '',
    this.truck = '',
    this.customerId,
    this.discount = 0,
  }) : super(id, invNum);

  @override
  String get table => T.sales;
  @override
  String get mainDate => date;

  void recalc() {
    if (qty > 0 && bagPrice > 0) total = qty * bagPrice;
    remaining = total - paid;
  }

  /// اقلام برای نمایش؛ فروش‌های خیلی قدیمی که قلم ندارند از ستون‌های قدیمی ساخته می‌شوند
  List<SaleItem> get displayItems {
    if (items.isNotEmpty) return items;
    if (qty <= 0 && gypsumType.isEmpty) return const [];
    return [
      SaleItem(
        type: gypsumType,
        weight: bagWeight,
        qty: qty,
        price: bagPrice,
        lineTotal: total + discount,
      ),
    ];
  }

  double get subtotal => displayItems.fold(0.0, (a, i) => a + i.lineTotal);

  /// اقلام را می‌گیرد و مجموع، باقی و خلاصهٔ ستون‌های قدیمی (برای گزارش‌ها و جستجو) را حساب می‌کند
  void applyItems(List<SaleItem> list) {
    items = list;
    qty = list.fold(0.0, (a, i) => a + i.qty);
    final types = <String>[];
    for (final i in list) {
      if (i.type.isNotEmpty && !types.contains(i.type)) types.add(i.type);
    }
    gypsumType = types.join('، ');
    final weights = list.map((i) => i.weight).toSet();
    bagWeight = weights.length == 1 ? weights.first : 0;
    bagPrice = list.length == 1 ? list.first.price : 0;
    final sub = list.fold(0.0, (a, i) => a + i.lineTotal);
    total = sub - discount < 0 ? 0 : sub - discount;
    remaining = total - paid;
  }

  @override
  Map<String, Object?> toMap() => {
        'id': id,
        'inv_num': invNum,
        'buyer': buyer,
        'phone': phone,
        'location': location,
        'gypsum_type': gypsumType,
        'bag_weight': bagWeight,
        'qty': qty,
        'bag_price': bagPrice,
        'order_type': orderType,
        'total': total,
        'paid': paid,
        'remaining': remaining,
        'cur': cur,
        'date': date,
        'time': time,
        'truck': truck,
        'customer_id': customerId,
        'discount': discount,
      };

  static Sale fromMap(Map<String, Object?> m) => Sale(
        id: m['id'] as int?,
        invNum: (m['inv_num'] ?? '').toString(),
        buyer: (m['buyer'] ?? '').toString(),
        phone: (m['phone'] ?? '').toString(),
        location: (m['location'] ?? '').toString(),
        gypsumType: (m['gypsum_type'] ?? '').toString(),
        bagWeight: toDouble(m['bag_weight']),
        qty: toDouble(m['qty']),
        bagPrice: toDouble(m['bag_price']),
        orderType: (m['order_type'] ?? '').toString(),
        total: toDouble(m['total']),
        paid: toDouble(m['paid']),
        remaining: toDouble(m['remaining']),
        cur: (m['cur'] ?? kAfghani).toString(),
        date: (m['date'] ?? '').toString(),
        time: (m['time'] ?? '').toString(),
        truck: (m['truck'] ?? '').toString(),
        customerId: m['customer_id'] as int?,
        discount: toDouble(m['discount']),
      );
}

// ─────────────────────────── مصارف ───────────────────────────
class Expense extends Rec {
  String item;
  double price;
  double paid;
  double remaining;
  String cur;
  String date;
  String time;

  Expense({
    int? id,
    String invNum = '',
    this.item = '',
    this.price = 0,
    this.paid = 0,
    this.remaining = 0,
    this.cur = kAfghani,
    this.date = '',
    this.time = '',
  }) : super(id, invNum);

  @override
  String get table => T.expenses;
  @override
  String get mainDate => date;

  void recalc() => remaining = price - paid;

  @override
  Map<String, Object?> toMap() => {
        'id': id,
        'inv_num': invNum,
        'item': item,
        'price': price,
        'paid': paid,
        'remaining': remaining,
        'cur': cur,
        'date': date,
        'time': time,
      };

  static Expense fromMap(Map<String, Object?> m) => Expense(
        id: m['id'] as int?,
        invNum: (m['inv_num'] ?? '').toString(),
        item: (m['item'] ?? '').toString(),
        price: toDouble(m['price']),
        paid: toDouble(m['paid']),
        remaining: toDouble(m['remaining']),
        cur: (m['cur'] ?? kAfghani).toString(),
        date: (m['date'] ?? '').toString(),
        time: (m['time'] ?? '').toString(),
      );
}

/// یک قلم از فاکتور فروش: مثلاً «۱۵ خلته ۲۰ کیلویی گچ سفید، فی خلته ۳۵۰»
class SaleItem {
  int? id;
  int? saleId;
  String type;
  double weight;
  double qty;
  double price;
  double lineTotal;

  SaleItem({
    this.id,
    this.saleId,
    this.type = '',
    this.weight = 0,
    this.qty = 0,
    this.price = 0,
    this.lineTotal = 0,
  });

  SaleItem copy() => SaleItem(
        id: id,
        saleId: saleId,
        type: type,
        weight: weight,
        qty: qty,
        price: price,
        lineTotal: lineTotal,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'sale_id': saleId,
        'type': type,
        'weight': weight,
        'qty': qty,
        'price': price,
        'line_total': lineTotal,
      };

  static SaleItem fromMap(Map<String, Object?> m) => SaleItem(
        id: m['id'] as int?,
        saleId: m['sale_id'] as int?,
        type: (m['type'] ?? '').toString(),
        weight: toDouble(m['weight']),
        qty: toDouble(m['qty']),
        price: toDouble(m['price']),
        lineTotal: toDouble(m['line_total']),
      );
}
