import 'package:sqflite/sqflite.dart';

import '../core/jalali.dart';

/// جدول مشتریان — هر مشتری یک ID یکتا (کلید اصلی) دارد
/// و ترکیب «نام + شماره تلفن» هم تکراری ثبت نمی‌شود (UNIQUE).
const String customersTableSql = '''
  CREATE TABLE IF NOT EXISTS customers(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL DEFAULT '',
    location TEXT NOT NULL DEFAULT '',
    created_at TEXT,
    UNIQUE(name, phone)
  )''';

class Customer {
  final int id;
  final String name;
  final String phone;
  final String location;
  final String createdAt;

  const Customer({
    required this.id,
    required this.name,
    required this.phone,
    required this.location,
    required this.createdAt,
  });

  factory Customer.fromMap(Map<String, Object?> m) => Customer(
        id: m['id'] as int,
        name: (m['name'] ?? '').toString(),
        phone: (m['phone'] ?? '').toString(),
        location: (m['location'] ?? '').toString(),
        createdAt: (m['created_at'] ?? '').toString(),
      );
}

/// نتیجهٔ یافتن/ساختن مشتری
class CustomerMatch {
  final Customer customer;
  final bool created;
  const CustomerMatch(this.customer, this.created);
}

/// نام یکدست: فاصله‌های اضافه، نیم‌فاصله و «ي/ك» عربی یکسان می‌شوند
String normalizeCustomerName(String s) {
  return s
      .replaceAll('ي', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('\u200c', ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

/// نوع گچ هم با همان قاعده یکدست می‌شود تا «گچ  سفید» و «گچ سفید» دو نوع جدا نشوند
String normalizeGypsumType(String s) => normalizeCustomerName(s);

/// شماره یکدست: فقط رقم انگلیسی؛ +93 / 0093 / 93 و شمارهٔ بدون صفر اول به شکل 07xxxxxxxx در می‌آیند
String normalizePhone(String s) {
  var d = toEnglishDigits(s).replaceAll(RegExp(r'[^0-9]'), '');
  if (d.isEmpty) return '';
  if (d.startsWith('0093')) {
    d = '0${d.substring(4)}';
  } else if (d.startsWith('93') && d.length >= 11) {
    d = '0${d.substring(2)}';
  } else if (d.length == 9 && !d.startsWith('0')) {
    d = '0$d';
  }
  return d;
}

String _now() => DateTime.now().toIso8601String();

/// مشتری را پیدا می‌کند و اگر نبود (و create=true باشد) می‌سازد.
/// قواعد جلوگیری از تکرار:
///  ۱) نام و شمارهٔ یکسان ← همان مشتری قبلی
///  ۲) شماره خالی + یک مشتری با همین نام ← همان مشتری
///  ۳) شمارهٔ جدید + مشتری هم‌نام که شماره نداشته ← شماره به همان مشتری اضافه می‌شود
Future<CustomerMatch?> resolveCustomer(
  DatabaseExecutor db, {
  required String name,
  String phone = '',
  String location = '',
  required bool create,
}) async {
  final n = normalizeCustomerName(name);
  if (n.isEmpty) return null;
  final p = normalizePhone(phone);
  final loc = location.trim();

  Future<CustomerMatch> existing(Map<String, Object?> row, {String? newPhone}) async {
    final c = Customer.fromMap(row);
    if (!create) return CustomerMatch(c, false);
    final patch = <String, Object?>{};
    if (loc.isNotEmpty && c.location.isEmpty) patch['location'] = loc;
    if (newPhone != null && newPhone.isNotEmpty && c.phone.isEmpty) patch['phone'] = newPhone;
    if (patch.isNotEmpty) {
      await db.update('customers', patch, where: 'id = ?', whereArgs: [c.id]);
      final fresh = await db.query('customers', where: 'id = ?', whereArgs: [c.id]);
      return CustomerMatch(Customer.fromMap(fresh.first), false);
    }
    return CustomerMatch(c, false);
  }

  // ۱) نام + شمارهٔ دقیقاً یکسان
  final exact = await db.query('customers',
      where: 'name = ? AND phone = ?', whereArgs: [n, p], limit: 1);
  if (exact.isNotEmpty) return existing(exact.first);

  if (p.isEmpty) {
    // ۲) شماره ندارد: اگر فقط یک مشتری با این نام هست، همان است
    final sameName = await db.query('customers', where: 'name = ?', whereArgs: [n]);
    if (sameName.length == 1) return existing(sameName.first);
  } else {
    // ۳) مشتری هم‌نام که شماره نداشته، شماره‌اش کامل می‌شود
    final blank = await db.query('customers',
        where: "name = ? AND phone = ''", whereArgs: [n], limit: 1);
    if (blank.isNotEmpty) return existing(blank.first, newPhone: p);
  }

  if (!create) return null;
  final id = await db.insert('customers', {
    'name': n,
    'phone': p,
    'location': loc,
    'created_at': _now(),
  });
  final row = await db.query('customers', where: 'id = ?', whereArgs: [id]);
  return CustomerMatch(Customer.fromMap(row.first), true);
}

/// فروش‌های بدون مشتری (یا با مشتری نامعتبر) را به مشتری وصل می‌کند —
/// فروش‌های تکراری با نام و شمارهٔ یکسان به یک مشتری می‌روند.
Future<void> backfillCustomers(DatabaseExecutor db) async {
  final rows = await db.query('sales',
      where: 'customer_id IS NULL OR customer_id NOT IN (SELECT id FROM customers)',
      orderBy: 'id ASC');
  for (final r in rows) {
    var name = (r['buyer'] ?? '').toString();
    if (normalizeCustomerName(name).isEmpty) name = 'بدون نام';
    final m = await resolveCustomer(
      db,
      name: name,
      phone: (r['phone'] ?? '').toString(),
      location: (r['location'] ?? '').toString(),
      create: true,
    );
    if (m == null) continue;
    await db.update(
      'sales',
      {
        'customer_id': m.customer.id,
        'buyer': m.customer.name,
        'phone': m.customer.phone,
        'location': m.customer.location,
      },
      where: 'id = ?',
      whereArgs: [r['id']],
    );
  }
}
