import '../services/inventory_service.dart';
import 'db.dart';
import 'models.dart';

/// خواندن و ذخیرهٔ فاکتورهای فروش همراه با اقلامشان
class SalesRepo {
  SalesRepo._();

  static Sale _withItems(Map<String, Object?> row, Map<int, List<SaleItem>> byId) {
    final s = Sale.fromMap(row);
    s.items = byId[row['id'] as int] ?? <SaleItem>[];
    return s;
  }

  static Future<Map<int, List<SaleItem>>> _itemsByIds() async {
    final db = await AppDb.instance.database;
    final byId = <int, List<SaleItem>>{};
    for (final r in await db.query('sale_items', orderBy: 'id ASC')) {
      final it = SaleItem.fromMap(r);
      byId.putIfAbsent(it.saleId ?? 0, () => <SaleItem>[]).add(it);
    }
    return byId;
  }

  /// همهٔ فاکتورها (تازه‌ترین اول) با اقلام
  static Future<List<Sale>> all() async {
    final db = await AppDb.instance.database;
    final rows = await db.query('sales', orderBy: 'id DESC');
    final byId = await _itemsByIds();
    return [for (final r in rows) _withItems(r, byId)];
  }

  /// فاکتورهای یک مشتری
  static Future<List<Sale>> ofCustomer(int customerId) async {
    final db = await AppDb.instance.database;
    final rows = await db.query('sales',
        where: 'customer_id = ?', whereArgs: [customerId], orderBy: 'id DESC');
    final byId = await _itemsByIds();
    return [for (final r in rows) _withItems(r, byId)];
  }

  /// ذخیرهٔ فاکتور (جدید یا ویرایش) و اقلامش در یک تراکنش؛ سپس انبار اصلاح می‌شود:
  /// اقلام قبلی به انبار برمی‌گردند و اقلام جدید از انبار کم می‌شوند.
  static Future<void> save(Sale s, {List<SaleItem> oldItems = const []}) async {
    final db = await AppDb.instance.database;
    if (s.id == null) {
      s.invNum = await AppDb.instance.nextInvoiceNumber('sales');
    }
    await db.transaction((txn) async {
      final map = s.toMap()..remove('id');
      if (s.id == null) {
        s.id = await txn.insert('sales', map);
      } else {
        await txn.update('sales', map, where: 'id = ?', whereArgs: [s.id]);
        await txn.delete('sale_items', where: 'sale_id = ?', whereArgs: [s.id]);
      }
      for (final it in s.items) {
        it.saleId = s.id;
        await txn.insert('sale_items', it.toMap()..remove('id'));
      }
    });

    for (final it in oldItems) {
      await InventoryService.instance.adjust(it.type, it.weight, it.qty);
    }
    for (final it in s.items) {
      await InventoryService.instance.adjust(it.type, it.weight, -it.qty);
    }
  }

  /// قبل از حذف فاکتور: اقلامش به انبار برمی‌گردد
  static Future<void> reverseStock(Sale s) async {
    for (final it in s.displayItems) {
      await InventoryService.instance.adjust(it.type, it.weight, it.qty);
    }
  }
}
