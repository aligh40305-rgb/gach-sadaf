import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../data/models.dart';
import '../widgets/invoice.dart' show InvoiceLine, InvoiceRow, InvoiceSec, InvoiceSpec, invoiceSpecFor;
import 'settings_service.dart';

/// چاپ فاکتور روی کاغذ (برای خرید حضوری مشتری) — یک فاکتور = یک PDF مرتب.
/// «چاپ» پنجرهٔ چاپ خود اندروید را باز می‌کند: پرینتر و اندازهٔ کاغذ همان‌جا انتخاب می‌شود
/// (پرینتر وای‌فای، USB-OTG یا ذخیره به‌صورت PDF).
class InvoicePdfService {
  InvoicePdfService._();
  static final InvoicePdfService instance = InvoicePdfService._();

  pw.Font? _regular;
  pw.Font? _bold;

  Future<void> _loadFonts() async {
    if (_regular != null && _bold != null) return;
    _regular = pw.Font.ttf(await rootBundle.load('assets/fonts/Vazirmatn-Regular.ttf'));
    _bold = pw.Font.ttf(await rootBundle.load('assets/fonts/Vazirmatn-Bold.ttf'));
  }

  String _fileName(Rec r) {
    final n = r.invNum.isEmpty ? Jalali.today().storage.replaceAll('/', '-') : r.invNum;
    return 'invoice-$n';
  }

  Future<Uint8List> build(Rec record, PdfPageFormat format) async {
    await _loadFonts();
    final InvoiceSpec spec = invoiceSpecFor(record);
    final st = Settings.instance;

    const navy = PdfColor.fromInt(0xFF133A57);
    const gold = PdfColor.fromInt(0xFFC9A227);
    const light = PdfColor.fromInt(0xFFF2F5F8);

    final doc = pw.Document(
      theme: pw.ThemeData.withFont(base: _regular!, bold: _bold!),
    );
    final margin = format.width < 300 ? 12.0 : 28.0;

    pw.Widget row(InvoiceRow r) => pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 3),
          child: pw.Row(children: [
            pw.Text(r.label,
                style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
            pw.Spacer(),
            pw.Text(r.value,
                style: pw.TextStyle(
                    fontSize: r.big ? 12.5 : 10.5, fontWeight: pw.FontWeight.bold)),
          ]),
        );

    pw.Widget section(InvoiceSec sec) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.SizedBox(height: 8),
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 8),
              color: light,
              child: pw.Text(sec.title,
                  style: pw.TextStyle(
                      fontSize: 10.5, fontWeight: pw.FontWeight.bold, color: navy)),
            ),
            pw.SizedBox(height: 3),
            ...sec.rows.map(row),
          ],
        );

    pw.Widget statusBox(String label, String value, PdfColor color) => pw.Expanded(
          child: pw.Container(
            padding: const pw.EdgeInsets.symmetric(vertical: 8),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: color, width: 1),
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: pw.Column(children: [
              pw.Text(label, style: pw.TextStyle(fontSize: 9.5, color: color)),
              pw.SizedBox(height: 3),
              pw.Text(value,
                  style: pw.TextStyle(
                      fontSize: 12, fontWeight: pw.FontWeight.bold, color: color)),
            ]),
          ),
        );

    final hasDate = spec.date.trim().isNotEmpty;
    final hasTime = spec.time.trim().isNotEmpty;

    doc.addPage(
      pw.MultiPage(
        pageFormat: format,
        margin: pw.EdgeInsets.all(margin),
        textDirection: pw.TextDirection.rtl,
        build: (ctx) => [
          // سربرگ کارخانه
          pw.Container(
            padding: const pw.EdgeInsets.only(bottom: 8),
            decoration: const pw.BoxDecoration(
              border: pw.Border(bottom: pw.BorderSide(color: gold, width: 2)),
            ),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('کارخانه گچ صدف',
                  style: pw.TextStyle(
                      fontSize: 18, fontWeight: pw.FontWeight.bold, color: navy)),
              pw.SizedBox(height: 3),
              pw.Text(
                '${st.owner}  |  ${toPersianDigits(st.phone)}',
                style: const pw.TextStyle(fontSize: 9.5),
              ),
              if (st.address.trim().isNotEmpty)
                pw.Text(st.address, style: const pw.TextStyle(fontSize: 9.5)),
            ]),
          ),
          pw.SizedBox(height: 10),

          // عنوان و شماره فاکتور
          pw.Row(children: [
            pw.Text(spec.title,
                style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
            pw.Spacer(),
            pw.Text('شماره: ${showText(record.invNum)}',
                style: pw.TextStyle(
                    fontSize: 11, fontWeight: pw.FontWeight.bold, color: navy)),
          ]),
          if (hasDate || hasTime)
            pw.Padding(
              padding: const pw.EdgeInsets.only(top: 3),
              child: pw.Text(
                '${hasDate ? showDate(spec.date) : ''}${hasDate && hasTime ? '   •   ' : ''}${hasTime ? showTime(spec.time) : ''}',
                style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey700),
              ),
            ),

          ...spec.sections.map(section),
          pw.SizedBox(height: 12),

          // جدول اقلام فاکتور
          if (spec.lines.isNotEmpty) ...[
            pw.TableHelper.fromTextArray(
              headers: ['#', 'شرح', 'تعداد', 'قیمت واحد', 'مبلغ'],
              data: [
                for (var i = 0; i < spec.lines.length; i++)
                  [
                    toPersianDigits(i + 1),
                    spec.lines[i].detail.isEmpty
                        ? spec.lines[i].title
                        : '${spec.lines[i].title} — ${spec.lines[i].detail}',
                    spec.lines[i].qty,
                    spec.lines[i].unit,
                    spec.lines[i].amount,
                  ],
              ],
              columnWidths: {
                0: const pw.FixedColumnWidth(24),
                1: const pw.FlexColumnWidth(4),
                2: const pw.FlexColumnWidth(1.6),
                3: const pw.FlexColumnWidth(2.2),
                4: const pw.FlexColumnWidth(2.4),
              },
              headerStyle: pw.TextStyle(
                  fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
              headerDecoration: const pw.BoxDecoration(color: navy),
              cellStyle: const pw.TextStyle(fontSize: 10),
              cellAlignment: pw.Alignment.center,
              headerAlignment: pw.Alignment.center,
              cellAlignments: {1: pw.Alignment.centerRight},
              oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
              border: pw.TableBorder.all(color: PdfColors.grey400, width: .5),
            ),
            pw.SizedBox(height: 8),
            if (spec.subtotal != null)
              pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 2),
                child: pw.Row(children: [
                  pw.Text('جمع اقلام', style: const pw.TextStyle(fontSize: 10.5)),
                  pw.Spacer(),
                  pw.Text(spec.subtotal!,
                      style: pw.TextStyle(fontSize: 10.5, fontWeight: pw.FontWeight.bold)),
                ]),
              ),
            if (spec.discount != null)
              pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 2),
                child: pw.Row(children: [
                  pw.Text('تخفیف', style: const pw.TextStyle(fontSize: 10.5)),
                  pw.Spacer(),
                  pw.Text('- ${spec.discount!}',
                      style: pw.TextStyle(
                          fontSize: 10.5,
                          fontWeight: pw.FontWeight.bold,
                          color: PdfColors.red800)),
                ]),
              ),
            pw.SizedBox(height: 6),
          ],

          // مجموع
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: pw.BoxDecoration(
              color: navy,
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: pw.Row(children: [
              pw.Text(spec.totalLabel,
                  style: const pw.TextStyle(fontSize: 11, color: PdfColors.white)),
              pw.Spacer(),
              pw.Text(spec.totalValue,
                  style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                      color: PdfColors.white)),
            ]),
          ),

          if (spec.paid != null) ...[
            pw.SizedBox(height: 8),
            pw.Row(children: [
              statusBox('پرداخت شده', fmtMoney(spec.paid, spec.cur), PdfColors.green800),
              pw.SizedBox(width: 8),
              statusBox(
                'باقی مانده',
                fmtMoney(spec.remaining, spec.cur),
                (spec.remaining ?? 0) > 0 ? PdfColors.red800 : PdfColors.green800,
              ),
            ]),
          ],

          pw.SizedBox(height: 26),
          pw.Row(children: [
            pw.Expanded(
              child: pw.Column(children: [
                pw.Container(height: 1, color: PdfColors.grey500),
                pw.SizedBox(height: 3),
                pw.Text('امضای فروشنده', style: const pw.TextStyle(fontSize: 9)),
              ]),
            ),
            pw.SizedBox(width: 30),
            pw.Expanded(
              child: pw.Column(children: [
                pw.Container(height: 1, color: PdfColors.grey500),
                pw.SizedBox(height: 3),
                pw.Text('امضای خریدار', style: const pw.TextStyle(fontSize: 9)),
              ]),
            ),
          ]),
          pw.SizedBox(height: 14),
          pw.Center(
            child: pw.Text('با تشکر از خرید شما — کارخانه گچ صدف',
                style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
          ),
          pw.SizedBox(height: 2),
          pw.Center(
            child: pw.Text('سازنده: انجنیر علی محمد غلامی',
                style: const pw.TextStyle(fontSize: 7.5, color: PdfColors.grey500)),
          ),
        ],
      ),
    );

    return doc.save();
  }

  /// باز کردن پنجرهٔ چاپ: انتخاب پرینتر، اندازهٔ کاغذ و تعداد نسخه
  Future<void> printInvoice(Rec record) {
    return Printing.layoutPdf(
      name: _fileName(record),
      format: PdfPageFormat.a5,
      onLayout: (format) => build(record, format),
    );
  }

  /// ارسال فاکتور به‌صورت فایل PDF (واتساپ، تلگرام، ایمیل…)
  Future<void> shareInvoicePdf(Rec record) async {
    final bytes = await build(record, PdfPageFormat.a5);
    await Printing.sharePdf(bytes: bytes, filename: '${_fileName(record)}.pdf');
  }
}
