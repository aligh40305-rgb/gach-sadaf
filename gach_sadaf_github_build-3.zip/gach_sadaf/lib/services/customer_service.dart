import '../core/jalali.dart';
import '../data/customers.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../data/sales_repo.dart';

/// خلاصهٔ حساب یک مشتری (مبلغ‌ها به‌تفکیک واحد پول)
class CustomerSummary {
  final Customer customer;
  final int count;
  final Map<String, double> totals;
  final Map<String, double> paid;
  final Map<String, double> remaining;

  const CustomerSummary(
      this.customer, this.count, this.totals, this.paid, this.remaining);

  bool get hasDebt => remaining.values.any((v) => v > 0.0001);
}

/// پیش‌نمایش هنگام ثبت فروش: آیا این مشتری قبلاً ثبت شده؟ چه پیشنهادهایی هست؟
class CustomerPreview {
  final Customer? match;
  final int matchSalesCount;
  final List<Customer> suggestions;
  const CustomerPreview(this.match, this.matchSalesCount, this.suggestions);
}

/// مدیریت مشتریان — مشتری تکراری ساخته نمی‌شود (نام + شماره)
class CustomerService {
  CustomerService._();
  static final CustomerService instance = CustomerService._();

  /// مشتری را پیدا می‌کند یا می‌سازد؛ اگر قبلاً ثبت بود همان رکورد را برمی‌گرداند
  Future<CustomerMatch?> findOrCreate({
    required String name,
    String phone = '',
    String location = '',
  }) async {
    final db = await AppDb.instance.database;
    return db.transaction((txn) async {
      final m = await resolveCustomer(txn,
          name: name, phone: phone, location: location, create: true);
      if (m != null && !m.created) {
        // اگر شماره/موقعیت تکمیل شده، فروش‌های قبلی همین مشتری هم هماهنگ شوند
        await txn.update(
          'sales',
          {'phone': m.customer.phone, 'location': m.customer.location},
          where: 'customer_id = ?',
          whereArgs: [m.customer.id],
        );
      }
      return m;
    });
  }

  Future<CustomerPreview> preview(String name, String phone) async {
    final db = await AppDb.instance.database;
    final m = await resolveCustomer(db, name: name, phone: phone, create: false);
    var count = 0;
    if (m != null) {
      final r = await db.rawQuery(
          'SELECT COUNT(*) c FROM sales WHERE customer_id = ?', [m.customer.id]);
      count = (r.first['c'] as int?) ?? 0;
    }
    final found = await search(name.trim().isNotEmpty ? name : phone, limit: 6);
    final extra = await search(phone, limit: 6);
    final seen = <int>{if (m != null) m.customer.id};
    final suggestions = <Customer>[];
    for (final c in [...found, ...extra]) {
      if (seen.add(c.id)) suggestions.add(c);
      if (suggestions.length >= 5) break;
    }
    return CustomerPreview(m?.customer, count, suggestions);
  }

  Future<List<Customer>> search(String query, {int limit = 5}) async {
    final db = await AppDb.instance.database;
    final q = normalizeCustomerName(query);
    final digits = toEnglishDigits(query).replaceAll(RegExp(r'[^0-9]'), '');
    final conds = <String>[];
    final args = <Object?>[];
    if (q.isNotEmpty && digits.length != q.replaceAll(' ', '').length) {
      conds.add('name LIKE ?');
      args.add('%$q%');
    }
    if (digits.length >= 3) {
      conds.add('phone LIKE ?');
      args.add('%$digits%');
    }
    if (conds.isEmpty) return [];
    final rows = await db.query('customers',
        where: conds.join(' OR '), whereArgs: args, orderBy: 'name ASC', limit: limit);
    return [for (final r in rows) Customer.fromMap(r)];
  }

  Future<List<CustomerSummary>> summaries() async {
    final db = await AppDb.instance.database;
    final custRows = await db.query('customers', orderBy: 'name ASC');
    final agg = await db.rawQuery(
        'SELECT customer_id, cur, COUNT(*) c, SUM(total) t, SUM(paid) p, SUM(remaining) r '
        'FROM sales WHERE customer_id IS NOT NULL GROUP BY customer_id, cur');

    final count = <int, int>{};
    final totals = <int, Map<String, double>>{};
    final paid = <int, Map<String, double>>{};
    final rem = <int, Map<String, double>>{};
    for (final r in agg) {
      final id = r['customer_id'] as int;
      final cur = (r['cur'] ?? '').toString();
      count[id] = (count[id] ?? 0) + ((r['c'] as int?) ?? 0);
      totals.putIfAbsent(id, () => {})[cur] = (r['t'] as num?)?.toDouble() ?? 0;
      paid.putIfAbsent(id, () => {})[cur] = (r['p'] as num?)?.toDouble() ?? 0;
      rem.putIfAbsent(id, () => {})[cur] = (r['r'] as num?)?.toDouble() ?? 0;
    }
    return [
      for (final r in custRows)
        CustomerSummary(
          Customer.fromMap(r),
          count[r['id']] ?? 0,
          totals[r['id']] ?? const {},
          paid[r['id']] ?? const {},
          rem[r['id']] ?? const {},
        ),
    ];
  }

  Future<List<Sale>> salesOf(int customerId) => SalesRepo.ofCustomer(customerId);

  /// ویرایش مشتری؛ اگر نام + شماره با مشتری دیگری یکی شود، رد می‌شود
  Future<String?> update(int id,
      {required String name, String phone = '', String location = ''}) async {
    final n = normalizeCustomerName(name);
    final p = normalizePhone(phone);
    if (n.isEmpty) return 'نام مشتری ضروری است';
    final db = await AppDb.instance.database;
    final dup = await db.query('customers',
        where: 'name = ? AND phone = ? AND id != ?', whereArgs: [n, p, id], limit: 1);
    if (dup.isNotEmpty) {
      return 'مشتری دیگری با همین نام و شماره ثبت است — برای یکی کردن، از «ادغام» استفاده کنید';
    }
    await db.transaction((txn) async {
      await txn.update('customers', {'name': n, 'phone': p, 'location': location.trim()},
          where: 'id = ?', whereArgs: [id]);
      await txn.update(
        'sales',
        {'buyer': n, 'phone': p, 'location': location.trim()},
        where: 'customer_id = ?',
        whereArgs: [id],
      );
    });
    return null;
  }

  /// حذف فقط وقتی مجاز است که مشتری هیچ فروشی نداشته باشد
  Future<String?> delete(int id) async {
    final db = await AppDb.instance.database;
    final r = await db
        .rawQuery('SELECT COUNT(*) c FROM sales WHERE customer_id = ?', [id]);
    final n = (r.first['c'] as int?) ?? 0;
    if (n > 0) {
      return 'این مشتری ${toPersianDigits(n)} فروش دارد؛ حذف ممکن نیست. اگر تکراری است از «ادغام» استفاده کنید';
    }
    await db.delete('customers', where: 'id = ?', whereArgs: [id]);
    return null;
  }

  /// ادغام: همهٔ فروش‌های [fromId] به [intoId] منتقل و [fromId] حذف می‌شود
  Future<String?> merge(int fromId, int intoId) async {
    if (fromId == intoId) return 'یک مشتری را نمی‌توان با خودش ادغام کرد';
    final db = await AppDb.instance.database;
    return db.transaction((txn) async {
      final from = await txn.query('customers', where: 'id = ?', whereArgs: [fromId]);
      final into = await txn.query('customers', where: 'id = ?', whereArgs: [intoId]);
      if (from.isEmpty || into.isEmpty) return 'مشتری پیدا نشد';
      final src = Customer.fromMap(from.first);
      var dst = Customer.fromMap(into.first);

      // شماره/موقعیت خالیِ مقصد از مبدأ کامل می‌شود
      final patch = <String, Object?>{};
      if (dst.location.isEmpty && src.location.isNotEmpty) patch['location'] = src.location;
      if (dst.phone.isEmpty && src.phone.isNotEmpty) {
        final clash = await txn.query('customers',
            where: 'name = ? AND phone = ?', whereArgs: [dst.name, src.phone], limit: 1);
        if (clash.isEmpty) patch['phone'] = src.phone;
      }
      if (patch.isNotEmpty) {
        await txn.update('customers', patch, where: 'id = ?', whereArgs: [intoId]);
        dst = Customer.fromMap(
            (await txn.query('customers', where: 'id = ?', whereArgs: [intoId])).first);
      }

      await txn.update(
        'sales',
        {
          'customer_id': intoId,
          'buyer': dst.name,
          'phone': dst.phone,
          'location': dst.location,
        },
        where: 'customer_id = ?',
        whereArgs: [fromId],
      );
      await txn.delete('customers', where: 'id = ?', whereArgs: [fromId]);
      return null;
    });
  }

  /// بعد از بازگردانی بکاپ: فروش‌های بدون مشتری را به مشتری وصل می‌کند
  Future<void> backfill() async {
    final db = await AppDb.instance.database;
    await db.transaction((txn) => backfillCustomers(txn));
  }
}
