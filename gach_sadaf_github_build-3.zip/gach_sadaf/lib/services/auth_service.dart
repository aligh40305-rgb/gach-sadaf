import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// ورود به برنامه: پسورد (هش‌شده با SHA-256 + salt) و اثر انگشت دستگاه
class Auth {
  Auth._();
  static final Auth instance = Auth._();

  static const _kHash = 'pw_hash';
  static const _kSalt = 'pw_salt';
  static const _kBio = 'bio_enabled';
  static const _kBioAsked = 'bio_asked';
  static const _kPinLen = 'pin_len';
  static const String defaultPassword = '1234';

  late SharedPreferences _p;
  final LocalAuthentication _auth = LocalAuthentication();

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    if (_p.getString(_kHash) == null) {
      await setPassword(defaultPassword);
    }
  }

  String _hash(String pw, String salt) =>
      sha256.convert(utf8.encode('$salt::$pw')).toString();

  String _newSalt() {
    final r = Random.secure();
    return base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  Future<void> setPassword(String pw) async {
    final salt = _newSalt();
    await _p.setString(_kSalt, salt);
    await _p.setString(_kHash, _hash(pw, salt));
    final numeric = RegExp(r'^[0-9]{4,8}$').hasMatch(pw);
    await _p.setInt(_kPinLen, numeric ? pw.length : 0);
  }

  /// طول پین عددی؛ اگر ۰ باشد رمز فعلی حروف دارد (نسخه‌های قدیمی) و صفحهٔ قفل حالت متنی می‌گیرد
  int get pinLength => _p.getInt(_kPinLen) ?? 4;

  /// تنظیم پین عددی جدید (۴ رقم)
  Future<void> setPin(String pin) => setPassword(pin);

  bool checkPassword(String pw) {
    final salt = _p.getString(_kSalt);
    final hash = _p.getString(_kHash);
    if (salt == null || hash == null) return false;
    return _hash(pw, salt) == hash;
  }

  bool get isDefaultPassword => checkPassword(defaultPassword);

  // ───────────────── اثر انگشت ─────────────────

  // پیش‌فرض: اگر گوشی اثر انگشت دارد، این قابلیت خودکار فعال است
  bool get bioEnabled => _p.getBool(_kBio) ?? true;
  Future<void> setBioEnabled(bool v) => _p.setBool(_kBio, v);

  bool get bioAsked => _p.getBool(_kBioAsked) ?? false;
  Future<void> markBioAsked() => _p.setBool(_kBioAsked, true);

  /// آیا دستگاه اثر انگشت/چهره دارد؟
  Future<bool> bioAvailable() async {
    try {
      final supported = await _auth.isDeviceSupported();
      if (!supported) return false;
      final can = await _auth.canCheckBiometrics;
      if (!can) return false;
      final list = await _auth.getAvailableBiometrics();
      return list.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<bool> authenticateBio() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'برای ورود به سیستم گچ صدف، اثر انگشت خود را بگذارید',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }
}
