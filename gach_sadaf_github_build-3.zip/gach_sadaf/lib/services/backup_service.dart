import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../data/db.dart';
import '../data/models.dart';
import 'customer_service.dart';
import 'inventory_service.dart';
import 'settings_service.dart';

class RestoreResult {
  final bool ok;
  final String message;
  final Map<String, int> counts;
  const RestoreResult(this.ok, this.message, [this.counts = const {}]);
}

/// بکاپ‌گیری و بازگردانی اطلاعات
class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();

  static const int formatVersion = 4;

  // ───────────────── ساخت فایل بکاپ ─────────────────

  Future<Map<String, Object?>> _collect() async {
    final data = <String, Object?>{};
    for (final t in T.all) {
      data[t] = await AppDb.instance.rows(t);
    }
    data[T.customers] = await AppDb.instance.rows(T.customers);
    data[T.saleItems] = await AppDb.instance.rows(T.saleItems);
    return {
      'app': 'گچ صدف',
      'format': 'gach-sadaf-backup',
      'version': formatVersion,
      'created_at': DateTime.now().toIso8601String(),
      'date_jalali': Jalali.today().storage,
      'owner': Settings.instance.owner,
      'phone': Settings.instance.phone,
      'data': data,
    };
  }

  String _stamp() => Jalali.today().storage.replaceAll('/', '-');

  /// فایل بکاپ را در حافظه داخلی برنامه می‌سازد و مسیر آن را برمی‌گرداند
  Future<File> writeBackupFile() async {
    final payload = await _collect();
    final dir = await getApplicationDocumentsDirectory();
    final backupDir = Directory(p.join(dir.path, 'backups'));
    if (!backupDir.existsSync()) backupDir.createSync(recursive: true);

    final file = File(p.join(backupDir.path, 'backup-gach-sadaf-${_stamp()}.json'));
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(payload),
      encoding: utf8,
      flush: true,
    );
    await Settings.instance.markBackupDone();
    return file;
  }

  /// بکاپ + باز کردن پنجره اشتراک‌گذاری گوشی (واتساپ، تلگرام، ایمیل، گوگل درایو…)
  Future<File> shareBackup() async {
    final file = await writeBackupFile();
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/json')],
      subject: 'بکاپ گچ صدف — ${Jalali.today().display}',
      text: 'فایل بکاپ سیستم مدیریت کارخانه گچ صدف — تاریخ: ${Jalali.today().display}',
    );
    return file;
  }

  /// کپی خام فایل دیتابیس (برای انتقال کامل به گوشی جدید)
  Future<File> shareRawDatabase() async {
    final dbPath = await AppDb.instance.databaseFilePath();
    final dir = await getApplicationDocumentsDirectory();
    final out = File(p.join(dir.path, 'gach-sadaf-db-${_stamp()}.db'));
    await File(dbPath).copy(out.path);
    await Share.shareXFiles(
      [XFile(out.path)],
      subject: 'دیتابیس گچ صدف',
      text: 'فایل کامل دیتابیس گچ صدف — ${Jalali.today().display}',
    );
    return out;
  }

  /// لیست بکاپ‌های ذخیره‌شده روی خود گوشی
  Future<List<File>> localBackups() async {
    final dir = await getApplicationDocumentsDirectory();
    final backupDir = Directory(p.join(dir.path, 'backups'));
    if (!backupDir.existsSync()) return [];
    final files = backupDir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.json'))
        .toList();
    files.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    return files;
  }

  // ───────────────── بازگردانی ─────────────────

  /// انتخاب فایل بکاپ از حافظه گوشی و بازگردانی آن
  Future<RestoreResult> pickAndRestore({bool replace = true}) async {
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.any,
      withData: false,
    );
    if (picked == null || picked.files.isEmpty) {
      return const RestoreResult(false, 'هیچ فایلی انتخاب نشد');
    }
    final path = picked.files.single.path;
    if (path == null) {
      return const RestoreResult(false, 'دسترسی به فایل ممکن نشد');
    }
    if (!path.toLowerCase().endsWith('.json')) {
      return const RestoreResult(false, 'لطفاً فایل بکاپ با پسوند .json را انتخاب کنید');
    }
    return restoreFromFile(File(path), replace: replace);
  }

  Future<RestoreResult> restoreFromFile(File file, {bool replace = true}) async {
    try {
      final raw = await file.readAsString(encoding: utf8);
      final decoded = jsonDecode(raw);
      if (decoded is! Map) {
        return const RestoreResult(false, 'ساختار فایل معتبر نیست');
      }
      final tables = _normalize(Map<String, dynamic>.from(decoded));
      if (tables.values.every((v) => v.isEmpty)) {
        return const RestoreResult(false, 'این فایل بکاپ معتبر گچ صدف نیست');
      }

      if (replace) {
        await AppDb.instance.clearAll();
      }
      final counts = <String, int>{};

      // مشتریان اول با همان IDها برمی‌گردند تا پیوند فروش‌ها حفظ شود
      final customers = tables[T.customers] ?? const <Map<String, Object?>>[];
      final validIds = <int>{};
      if (replace && customers.isNotEmpty) {
        await AppDb.instance.bulkInsert(T.customers, customers, keepIds: true);
        for (final c in customers) {
          final id = c['id'];
          if (id is int) validIds.add(id);
        }
        counts[T.customers] = customers.length;
      }

      for (final entry in tables.entries) {
        if (entry.key == T.customers || entry.key == T.saleItems || entry.value.isEmpty) {
          continue;
        }
        var rows = entry.value;
        if (entry.key == T.sales) {
          // پیوند نامعتبر حذف می‌شود؛ پایین‌تر خودکار به مشتری وصل می‌شود
          rows = [
            for (final r in rows)
              {
                ...r,
                'customer_id': validIds.contains(r['customer_id']) ? r['customer_id'] : null,
              },
          ];
        }
        // شناسهٔ فاکتورها حفظ می‌شود تا اقلامشان درست به آن‌ها وصل بماند
        await AppDb.instance
            .bulkInsert(entry.key, rows, keepIds: replace && entry.key == T.sales);
        counts[entry.key] = rows.length;
      }

      // اقلام فاکتورها (فقط فاکتورهایی که واقعاً برگشته‌اند)
      final itemRows = tables[T.saleItems] ?? const <Map<String, Object?>>[];
      if (replace && itemRows.isNotEmpty) {
        final saleIds = <int>{
          for (final r in tables[T.sales] ?? const <Map<String, Object?>>[])
            if (r['id'] is int) r['id'] as int,
        };
        final valid = [
          for (final r in itemRows)
            if (saleIds.contains(r['sale_id'])) r,
        ];
        if (valid.isNotEmpty) {
          await AppDb.instance.bulkInsert(T.saleItems, valid);
          counts[T.saleItems] = valid.length;
        }
      }
      await AppDb.instance.backfillSaleItemsNow();
      await CustomerService.instance.backfill();
      await InventoryService.instance.recompute();

      final total = counts.values.fold<int>(0, (a, b) => a + b);
      return RestoreResult(
        true,
        'بازگردانی موفق بود — مجموعاً ${toPersianDigits(total)} رکورد برگشت',
        counts,
      );
    } on FormatException {
      return const RestoreResult(false, 'فایل خراب است یا JSON معتبر نیست');
    } catch (e) {
      return RestoreResult(false, 'خطا در بازگردانی: $e');
    }
  }

  /// پشتیبانی هم از بکاپ نسخه موبایل و هم از بکاپ نسخه قدیمی HTML
  Map<String, List<Map<String, Object?>>> _normalize(Map<String, dynamic> j) {
    final out = <String, List<Map<String, Object?>>>{
      for (final t in [...T.all, T.customers, T.saleItems]) t: <Map<String, Object?>>[],
    };

    // نسخه جدید: { data: { workers: [...], ... } }
    final data = j['data'];
    if (data is Map) {
      for (final t in [...T.all, T.customers, T.saleItems]) {
        final list = data[t];
        if (list is List) {
          out[t] = list
              .whereType<Map>()
              .map((e) => Map<String, Object?>.from(e))
              .toList();
        }
      }
      if (out.values.any((v) => v.isNotEmpty)) return out;
    }

    // نسخه قدیمی HTML/IndexedDB
    List<Map> pick(String key) =>
        (j[key] is List) ? (j[key] as List).whereType<Map>().toList() : const [];

    out[T.workers] = pick('workers').map(_legacyWorker).toList();
    out[T.stones] = pick('stones').map(_legacyStone).toList();
    out[T.production] = pick('prod').map(_legacyProd).toList();
    out[T.sales] = pick('sales').map(_legacySale).toList();
    out[T.expenses] = pick('exp').map(_legacyExpense).toList();
    return out;
  }

  String _d(Object? v) => toEnglishDigits(v?.toString() ?? '').trim();

  Map<String, Object?> _legacyWorker(Map m) {
    // نسخه قدیمی بر اساس روز کاری بود؛ در نبود عدد خلته، همان روزها به‌عنوان
    // مقدار اولیه خلته وارد می‌شود تا داده‌ای گم نشود (قابل اصلاح دستی است)
    final w = Worker(
      invNum: (m['invNum'] ?? '').toString(),
      name: (m['name'] ?? '').toString(),
      shift: (m['shift'] ?? 'روز').toString(),
      startDate: _d(m['start']),
      endDate: _d(m['end']),
      gunny: toDouble(m['gunny'] ?? m['days']),
      extraGunny: toDouble(m['extra_gunny'] ?? m['ot']),
      rate: toDouble(m['rate']),
      cur: (m['cur'] ?? kAfghani).toString(),
      paid: toDouble(m['paid']),
      paidDate: _d(m['paidDate']),
      paidTime: _d(m['paidTime']),
    )..recalc();
    return w.toMap();
  }

  Map<String, Object?> _legacyStone(Map m) {
    final s = Stone(
      invNum: (m['invNum'] ?? '').toString(),
      seller: (m['seller'] ?? '').toString(),
      type: (m['type'] ?? '').toString(),
      weight: toDouble(m['weight']),
      pricePerTon: toDouble(m['pricePerTon']),
      total: toDouble(m['total']),
      cur: (m['cur'] ?? kAfghani).toString(),
      paid: toDouble(m['paid']),
      date: _d(m['date']),
      paidDate: _d(m['paidDate']),
      driver: (m['driver'] ?? '').toString(),
      driverRate: toDouble(m['driverRate']),
      driverTotal: toDouble(m['driverTotal']),
      driverCur: (m['dCur'] ?? kAfghani).toString(),
      driverPaid: toDouble(m['driverPaid']),
      deliverDate: _d(m['deliverDate']),
      driverPaidDate: _d(m['driverPaidDate']),
    )..recalc();
    return s.toMap();
  }

  Map<String, Object?> _legacyProd(Map m) => Production(
        invNum: (m['invNum'] ?? '').toString(),
        date: _d(m['date']),
        type: (m['type'] ?? '').toString(),
        gunny: toDouble(m['gunny']),
        bagWeight: toDouble(m['weight']),
      ).toMap();

  Map<String, Object?> _legacySale(Map m) {
    final s = Sale(
      invNum: (m['invNum'] ?? '').toString(),
      buyer: (m['buyer'] ?? '').toString(),
      phone: (m['phone'] ?? '').toString(),
      location: (m['location'] ?? '').toString(),
      gypsumType: (m['gypsumType'] ?? '').toString(),
      bagWeight: toDouble(m['bagWeight']),
      qty: toDouble(m['qty']),
      bagPrice: toDouble(m['bagPrice']),
      orderType: (m['orderType'] ?? '').toString(),
      total: toDouble(m['total']),
      cur: (m['cur'] ?? kAfghani).toString(),
      paid: toDouble(m['paid']),
      date: _d(m['date']),
      time: _d(m['time']),
      truck: (m['truck'] ?? '').toString(),
    )..recalc();
    return s.toMap();
  }

  Map<String, Object?> _legacyExpense(Map m) {
    final e = Expense(
      invNum: (m['invNum'] ?? '').toString(),
      item: (m['item'] ?? '').toString(),
      price: toDouble(m['price']),
      cur: (m['cur'] ?? kAfghani).toString(),
      paid: toDouble(m['paid']),
      date: _d(m['date']),
      time: _d(m['time']),
    )..recalc();
    return e.toMap();
  }

  // ───────────────── خروجی CSV (اکسل) ─────────────────

  String _esc(Object? v) {
    var s = v?.toString() ?? '';
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      s = '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }

  Future<File> exportCsv() async {
    final lines = <String>[];
    void section(String title, List<String> head, List<List<Object?>> body) {
      lines.add('--- $title ---');
      lines.add(head.map(_esc).join(','));
      for (final r in body) {
        lines.add(r.map(_esc).join(','));
      }
      lines.add('');
    }

    lines.add('=== گزارش کامل گچ صدف — ${Jalali.today().fullDisplay} ===');
    lines.add('');

    final workers = (await AppDb.instance.rows(T.workers)).map(Worker.fromMap);
    section('کارگران', [
      'شماره', 'اسم', 'شیفت', 'شروع', 'ختم', 'تعداد خلته', 'خلته اضافی', //
      'فی خلته', 'واحد', 'پول کل', 'پرداخت', 'باقی', 'تاریخ پرداخت',
    ], [
      for (final w in workers)
        [w.invNum, w.name, w.shift, w.startDate, w.endDate, w.gunny, w.extraGunny,
            w.rate, w.cur, w.total, w.paid, w.remaining, w.paidDate],
    ]);

    final stones = (await AppDb.instance.rows(T.stones)).map(Stone.fromMap);
    section('خرید سنگ', [
      'شماره', 'صاحب سنگ', 'نوع', 'وزن (تن)', 'فی تن', 'قیمت کل', 'واحد', //
      'پرداخت', 'باقی', 'تاریخ خرید', 'راننده', 'کرایه کل', 'پرداخت راننده', 'باقی راننده',
    ], [
      for (final s in stones)
        [s.invNum, s.seller, s.type, s.weight, s.pricePerTon, s.total, s.cur,
            s.paid, s.remaining, s.date, s.driver, s.driverTotal, s.driverPaid, s.driverRem],
    ]);

    final prods = (await AppDb.instance.rows(T.production)).map(Production.fromMap);
    section('تولید', ['شماره', 'تاریخ', 'نوعیت گچ', 'تعداد خلته', 'وزن هر خلته', 'وزن کل'], [
      for (final r in prods)
        [r.invNum, r.date, r.type, r.gunny, r.bagWeight, r.totalWeight],
    ]);

    final sales = (await AppDb.instance.rows(T.sales)).map(Sale.fromMap);
    section('فروشات', [
      'شماره', 'خریدار', 'موبایل', 'موقعیت', 'نوعیت گچ', 'وزن خلته', 'تعداد', //
      'فی خلته', 'مجموع', 'واحد', 'پرداخت', 'باقی', 'تاریخ', 'ساعت', 'موتر',
    ], [
      for (final s in sales)
        [s.invNum, s.buyer, s.phone, s.location, s.gypsumType, s.bagWeight, s.qty,
            s.bagPrice, s.total, s.cur, s.paid, s.remaining, s.date, s.time, s.truck],
    ]);

    final exps = (await AppDb.instance.rows(T.expenses)).map(Expense.fromMap);
    section('مصارف', ['شماره', 'تاریخ', 'ساعت', 'جنس', 'قیمت', 'واحد', 'پرداخت', 'باقی'], [
      for (final e in exps)
        [e.invNum, e.date, e.time, e.item, e.price, e.cur, e.paid, e.remaining],
    ]);

    final dir = await getTemporaryDirectory();
    final file = File(p.join(dir.path, 'گزارش-گچ-صدف-${_stamp()}.csv'));
    // BOM تا اکسل، فارسی را درست نشان دهد
    await file.writeAsString('\uFEFF${lines.join('\n')}', encoding: utf8, flush: true);
    return file;
  }

  Future<void> shareCsv() async {
    final f = await exportCsv();
    await Share.shareXFiles([XFile(f.path)], subject: 'گزارش اکسل گچ صدف');
  }
}
