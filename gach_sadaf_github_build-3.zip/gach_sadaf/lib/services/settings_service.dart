import 'package:shared_preferences/shared_preferences.dart';

import '../core/format.dart';

/// تنظیمات برنامه — در حافظه محلی گوشی ذخیره می‌شود
class Settings {
  Settings._();
  static final Settings instance = Settings._();

  static const _kOwner = 'owner';
  static const _kPhone = 'phone';
  static const _kAddress = 'address';
  static const _kDefCur = 'def_cur';
  static const _kBackupEvery = 'backup_every_days';
  static const _kLastBackup = 'last_backup_ms';
  static const _kThemeMode = 'theme_mode'; // 'system' | 'light' | 'dark'
  static const _kLowStock = 'low_stock_threshold';
  static const _kAutoLock = 'auto_lock_minutes';

  late SharedPreferences _p;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
  }

  String get owner => _p.getString(_kOwner) ?? 'رضا محمدی';
  set owner(String v) => _p.setString(_kOwner, v);

  String get phone => _p.getString(_kPhone) ?? '0093781419161';
  set phone(String v) => _p.setString(_kPhone, v);

  String get address => _p.getString(_kAddress) ?? 'کابل، قلعه حیدر خان';
  set address(String v) => _p.setString(_kAddress, v);

  String get defaultCurrency => _p.getString(_kDefCur) ?? kAfghani;
  set defaultCurrency(String v) => _p.setString(_kDefCur, v);

  /// ۰ = بدون یادآوری
  int get backupEveryDays => _p.getInt(_kBackupEvery) ?? 3;
  set backupEveryDays(int v) => _p.setInt(_kBackupEvery, v);

  String get themeModeStorage => _p.getString(_kThemeMode) ?? 'system';
  set themeModeStorage(String v) => _p.setString(_kThemeMode, v);

  /// وقتی موجودی یک نوع گچ از این عدد کمتر شود، در انبار به رنگ هشدار نشان داده می‌شود
  int get lowStockThreshold => _p.getInt(_kLowStock) ?? 15;
  set lowStockThreshold(int v) => _p.setInt(_kLowStock, v);

  /// بعد از چند دقیقه دور بودن از برنامه، دوباره قفل شود؛ ۰ = هیچ‌وقت
  int get autoLockMinutes => _p.getInt(_kAutoLock) ?? 5;
  set autoLockMinutes(int v) => _p.setInt(_kAutoLock, v);

  /// بازگرداندن تنظیمات ظاهری و عملکردی به حالت پیش‌فرض
  /// (اطلاعات کارخانه، رکوردها، بکاپ‌ها و پین/اثر انگشت دست‌نخورده می‌مانند)
  Future<void> resetPreferences() async {
    for (final k in [_kDefCur, _kBackupEvery, _kThemeMode, _kLowStock, _kAutoLock]) {
      await _p.remove(k);
    }
  }

  DateTime? get lastBackup {
    final ms = _p.getInt(_kLastBackup);
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  Future<void> markBackupDone() =>
      _p.setInt(_kLastBackup, DateTime.now().millisecondsSinceEpoch);

  /// آیا وقت یادآوری بکاپ رسیده است؟
  bool get backupReminderDue {
    final days = backupEveryDays;
    if (days <= 0) return false;
    final last = lastBackup;
    if (last == null) return true;
    return DateTime.now().difference(last).inDays >= days;
  }
}
