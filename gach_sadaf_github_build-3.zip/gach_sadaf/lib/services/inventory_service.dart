import '../data/db.dart';

/// پیشنهاد اولیه برای نوع گچ — کاربر هر نوع دلخواه را خودش هم می‌تواند تایپ کند
const List<String> kDefaultGypsumTypes = [
  'گچ سفید',
  'گچ خاکستری',
  'گچ صنعتی',
  'گچ طبی',
];

/// یک ردیف انبار: نوع گچ + وزن هر خلته + تعداد خلتهٔ باقی‌مانده
class StockItem {
  final String type;
  final double weight;
  final double qty;
  const StockItem(this.type, this.weight, this.qty);

  /// وزن کل این ردیف به کیلو
  double get totalKg => weight * qty;
}

/// موجودی انبار — به‌تفکیک نوع گچ و وزن هر خلته.
/// مثال: «گچ سفید ۲۰ کیلویی: ۱۵۰ خلته» و «گچ سفید ۱۷ کیلویی: ۵۰ خلته» دو ردیف جدا هستند.
/// تولید → موجودی همان نوع و همان وزن زیاد می‌شود، فروش → از همان نوع و وزن کم می‌شود.
class InventoryService {
  InventoryService._();
  static final InventoryService instance = InventoryService._();

  /// موجودی یک ردیف را به‌اندازهٔ delta تغییر می‌دهد (مثبت = افزایش، منفی = کاهش)
  Future<void> adjust(String type, double weight, double delta) async {
    if (delta == 0) return;
    final db = await AppDb.instance.database;
    final t = AppDb.stockType(type);
    final w = AppDb.stockWeight(weight);
    await db.transaction((txn) async {
      final rows = await txn.query('stock',
          where: 'type = ? AND weight = ?', whereArgs: [t, w]);
      if (rows.isEmpty) {
        await txn.insert('stock', {'type': t, 'weight': w, 'qty': delta});
      } else {
        final current = (rows.first['qty'] as num?)?.toDouble() ?? 0;
        await txn.update('stock', {'qty': current + delta},
            where: 'type = ? AND weight = ?', whereArgs: [t, w]);
      }
    });
  }

  /// وقتی کاربر در ویرایش، نوع یا وزن را عوض می‌کند: اثر قبلی برگردانده و اثر جدید اعمال می‌شود
  Future<void> move({
    required String fromType,
    required double fromWeight,
    required double fromDelta,
    required String toType,
    required double toWeight,
    required double toDelta,
  }) async {
    final sameRow = AppDb.stockType(fromType) == AppDb.stockType(toType) &&
        AppDb.stockWeight(fromWeight) == AppDb.stockWeight(toWeight);
    if (sameRow) {
      await adjust(toType, toWeight, fromDelta + toDelta);
    } else {
      await adjust(fromType, fromWeight, fromDelta);
      await adjust(toType, toWeight, toDelta);
    }
  }

  Future<double> qtyFor(String type, double weight) async {
    final db = await AppDb.instance.database;
    final rows = await db.query('stock',
        where: 'type = ? AND weight = ?',
        whereArgs: [AppDb.stockType(type), AppDb.stockWeight(weight)]);
    if (rows.isEmpty) return 0;
    return (rows.first['qty'] as num?)?.toDouble() ?? 0;
  }

  /// وزن‌های موجود برای یک نوع گچ (فقط ردیف‌هایی که موجودی دارند)
  Future<List<StockItem>> forType(String type) async {
    final db = await AppDb.instance.database;
    final rows = await db.query('stock',
        where: 'type = ? AND qty != 0',
        whereArgs: [AppDb.stockType(type)],
        orderBy: 'weight ASC');
    return [for (final r in rows) _item(r)];
  }

  Future<List<StockItem>> all() async {
    final db = await AppDb.instance.database;
    final rows = await db.query('stock', orderBy: 'type ASC, weight ASC');
    return [for (final r in rows) _item(r)];
  }

  StockItem _item(Map<String, Object?> r) => StockItem(
        r['type'] as String,
        (r['weight'] as num?)?.toDouble() ?? 0,
        (r['qty'] as num?)?.toDouble() ?? 0,
      );

  /// نوع‌های گچی که قبلاً استفاده شده (انبار، تولید، فروش) + پیشنهادهای اولیه —
  /// برای پیشنهاد هنگام تایپ، تا یک نوع با املای متفاوت دوباره ثبت نشود
  Future<List<String>> knownTypes() async {
    final db = await AppDb.instance.database;
    final out = <String>[];
    void add(Object? v) {
      final t = (v ?? '').toString().trim();
      if (t.isEmpty || t == AppDb.untypedStock || out.contains(t)) return;
      out.add(t);
    }

    for (final table in ['stock', 'production', 'sale_items']) {
      final rows = await db.rawQuery('SELECT DISTINCT type AS t FROM $table ORDER BY t');
      for (final r in rows) {
        add(r['t']);
      }
    }
    kDefaultGypsumTypes.forEach(add);
    return out;
  }

  Future<void> clearAll() async {
    final db = await AppDb.instance.database;
    await db.delete('stock');
  }

  /// بازسازی کامل موجودی از روی تمام رکوردهای تولید و فروش
  Future<void> recompute() async {
    final db = await AppDb.instance.database;
    await db.transaction((txn) => AppDb.rebuildStock(txn));
  }
}
