import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../data/db.dart';
import '../data/models.dart';
import 'settings_service.dart';

enum ReportRange { day, month, year, all }

class ReportData {
  final String title;
  final List<Worker> workers;
  final List<Stone> stones;
  final List<Production> production;
  final List<Sale> sales;
  final List<Expense> expenses;

  ReportData({
    required this.title,
    required this.workers,
    required this.stones,
    required this.production,
    required this.sales,
    required this.expenses,
  });

  double get totalSalesPaid => sales.fold(0, (s, r) => s + r.paid);
  double get totalSalesValue => sales.fold(0, (s, r) => s + r.total);
  double get totalSalesRemaining => sales.fold(0, (s, r) => s + r.remaining);
  double get totalExpenses => expenses.fold(0, (s, r) => s + r.paid);
  double get totalStonePaid => stones.fold(0, (s, r) => s + r.paid);
  double get totalWages => workers.fold(0, (s, r) => s + r.paid);
  double get totalGunny => production.fold(0, (s, r) => s + r.gunny);
  double get totalProducedWeight => production.fold(0, (s, r) => s + r.totalWeight);

  /// سود خالص تخمینی = فروش وصول‌شده − مصارف − پول سنگ − معاش کارگران
  double get netProfit => totalSalesPaid - totalExpenses - totalStonePaid - totalWages;

  bool get isEmpty =>
      workers.isEmpty &&
      stones.isEmpty &&
      production.isEmpty &&
      sales.isEmpty &&
      expenses.isEmpty;
}

class ReportService {
  ReportService._();
  static final ReportService instance = ReportService._();

  /// ساخت گزارش بر اساس بازه
  Future<ReportData> build({
    required ReportRange range,
    Jalali? day,
    int? month,
    int? year,
  }) async {
    bool keep(String date) {
      switch (range) {
        case ReportRange.all:
          return true;
        case ReportRange.day:
          final d = Jalali.tryParse(date);
          return d != null &&
              day != null &&
              d.year == day.year &&
              d.month == day.month &&
              d.day == day.day;
        case ReportRange.month:
          final d = Jalali.tryParse(date);
          return d != null && d.month == month && d.year == year;
        case ReportRange.year:
          final d = Jalali.tryParse(date);
          return d != null && d.year == year;
      }
    }

    String title;
    switch (range) {
      case ReportRange.all:
        title = 'گزارش کامل همه رکوردها';
        break;
      case ReportRange.day:
        title = 'گزارش روز ${day?.display ?? ''}';
        break;
      case ReportRange.month:
        title =
            'گزارش ماهانه — ${afghanMonths[(month ?? 1) - 1]} ${toPersianDigits(year)}';
        break;
      case ReportRange.year:
        title = 'گزارش سالانه — سال ${toPersianDigits(year)}';
        break;
    }

    final workers = (await AppDb.instance.rows(T.workers))
        .map(Worker.fromMap)
        .where((r) => keep(r.startDate) || keep(r.paidDate))
        .toList();
    final stones = (await AppDb.instance.rows(T.stones))
        .map(Stone.fromMap)
        .where((r) => keep(r.date))
        .toList();
    final production = (await AppDb.instance.rows(T.production))
        .map(Production.fromMap)
        .where((r) => keep(r.date))
        .toList();
    final sales = (await AppDb.instance.rows(T.sales))
        .map(Sale.fromMap)
        .where((r) => keep(r.date))
        .toList();
    final expenses = (await AppDb.instance.rows(T.expenses))
        .map(Expense.fromMap)
        .where((r) => keep(r.date))
        .toList();

    return ReportData(
      title: title,
      workers: workers,
      stones: stones,
      production: production,
      sales: sales,
      expenses: expenses,
    );
  }

  // ───────────────── خروجی PDF ─────────────────

  pw.Font? _regular;
  pw.Font? _bold;

  Future<void> _loadFonts() async {
    if (_regular != null && _bold != null) return;
    final r = await rootBundle.load('assets/fonts/Vazirmatn-Regular.ttf');
    final b = await rootBundle.load('assets/fonts/Vazirmatn-Bold.ttf');
    _regular = pw.Font.ttf(r);
    _bold = pw.Font.ttf(b);
  }

  Future<Uint8List> buildPdf(ReportData data) async {
    await _loadFonts();
    final theme = pw.ThemeData.withFont(base: _regular!, bold: _bold!);
    final doc = pw.Document(theme: theme);

    const navy = PdfColor.fromInt(0xFF133A57);
    const gold = PdfColor.fromInt(0xFFC9A227);
    const light = PdfColor.fromInt(0xFFF2F5F8);

    pw.Widget header() => pw.Container(
          padding: const pw.EdgeInsets.only(bottom: 10),
          decoration: const pw.BoxDecoration(
            border: pw.Border(bottom: pw.BorderSide(color: gold, width: 2)),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('کارخانه گچ صدف — ${data.title}',
                  style: pw.TextStyle(
                      fontSize: 17, fontWeight: pw.FontWeight.bold, color: navy)),
              pw.SizedBox(height: 4),
              pw.Text(
                '${Settings.instance.owner}  |  ${Settings.instance.phone}  |  ${Settings.instance.address}',
                style: const pw.TextStyle(fontSize: 9),
              ),
              pw.Text('تاریخ چاپ: ${Jalali.today().fullDisplay}',
                  style: const pw.TextStyle(fontSize: 9)),
            ],
          ),
        );

    pw.Widget summaryBox(String label, String value) => pw.Container(
          width: 118,
          padding: const pw.EdgeInsets.symmetric(vertical: 8, horizontal: 6),
          decoration: pw.BoxDecoration(
            color: light,
            borderRadius: pw.BorderRadius.circular(6),
            border: pw.Border.all(color: PdfColors.grey300),
          ),
          child: pw.Column(children: [
            pw.Text(label, style: const pw.TextStyle(fontSize: 8.5)),
            pw.SizedBox(height: 3),
            pw.Text(value,
                style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
          ]),
        );

    pw.Widget table(String title, List<String> head, List<List<String>> rows) {
      if (rows.isEmpty) return pw.SizedBox();
      return pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.SizedBox(height: 14),
        pw.Container(
          padding: const pw.EdgeInsets.symmetric(vertical: 4, horizontal: 8),
          color: light,
          child: pw.Text('$title (${toPersianDigits(rows.length)} رکورد)',
              style: pw.TextStyle(
                  fontSize: 11, fontWeight: pw.FontWeight.bold, color: navy)),
        ),
        pw.SizedBox(height: 5),
        pw.TableHelper.fromTextArray(
          headers: head,
          data: rows,
          headerStyle: pw.TextStyle(
              fontSize: 8.5, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
          headerDecoration: const pw.BoxDecoration(color: navy),
          cellStyle: const pw.TextStyle(fontSize: 8.5),
          cellAlignment: pw.Alignment.centerRight,
          headerAlignment: pw.Alignment.centerRight,
          oddRowDecoration: const pw.BoxDecoration(color: PdfColors.grey100),
          border: pw.TableBorder.all(color: PdfColors.grey300, width: .4),
        ),
      ]);
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(28),
        textDirection: pw.TextDirection.rtl,
        header: (_) => header(),
        footer: (ctx) => pw.Align(
          alignment: pw.Alignment.centerLeft,
          child: pw.Text(
            'صفحه ${toPersianDigits(ctx.pageNumber)} از ${toPersianDigits(ctx.pagesCount)}  •  سازنده: انجنیر علی محمد غلامی',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
          ),
        ),
        build: (ctx) => [
          pw.SizedBox(height: 10),
          pw.Wrap(spacing: 8, runSpacing: 8, children: [
            summaryBox('فروشات (وصول‌شده)', fmtNum(data.totalSalesPaid)),
            summaryBox('باقی از مشتریان', fmtNum(data.totalSalesRemaining)),
            summaryBox('مصارف', fmtNum(data.totalExpenses)),
            summaryBox('پول سنگ', fmtNum(data.totalStonePaid)),
            summaryBox('معاش کارگران', fmtNum(data.totalWages)),
            summaryBox('تولید', '${fmtNum(data.totalGunny)} خلته'),
            summaryBox('سود خالص تخمینی', fmtNum(data.netProfit)),
          ]),
          table(
            'تولید',
            ['#', 'شماره', 'تاریخ', 'نوعیت', 'خلته', 'وزن هر خلته', 'وزن کل'],
            [
              for (var i = 0; i < data.production.length; i++)
                [
                  toPersianDigits(i + 1),
                  data.production[i].invNum,
                  showDate(data.production[i].date),
                  showText(data.production[i].type),
                  fmtNum(data.production[i].gunny),
                  '${fmtNum(data.production[i].bagWeight)} کیلو',
                  '${fmtNum(data.production[i].totalWeight)} کیلو',
                ],
            ],
          ),
          table(
            'فروشات',
            ['#', 'شماره', 'خریدار', 'تعداد', 'مجموع', 'پرداخت', 'باقی', 'تاریخ'],
            [
              for (var i = 0; i < data.sales.length; i++)
                [
                  toPersianDigits(i + 1),
                  data.sales[i].invNum,
                  data.sales[i].buyer,
                  fmtNum(data.sales[i].qty),
                  fmtMoney(data.sales[i].total, data.sales[i].cur),
                  fmtMoney(data.sales[i].paid, data.sales[i].cur),
                  fmtMoney(data.sales[i].remaining, data.sales[i].cur),
                  showDate(data.sales[i].date),
                ],
            ],
          ),
          table(
            'خرید سنگ',
            ['#', 'صاحب سنگ', 'وزن', 'قیمت کل', 'پرداخت', 'باقی', 'راننده', 'تاریخ'],
            [
              for (var i = 0; i < data.stones.length; i++)
                [
                  toPersianDigits(i + 1),
                  data.stones[i].seller,
                  '${fmtNum(data.stones[i].weight)} تن',
                  fmtMoney(data.stones[i].total, data.stones[i].cur),
                  fmtMoney(data.stones[i].paid, data.stones[i].cur),
                  fmtMoney(data.stones[i].remaining, data.stones[i].cur),
                  showText(data.stones[i].driver),
                  showDate(data.stones[i].date),
                ],
            ],
          ),
          table(
            'کارگران',
            ['#', 'اسم', 'شیفت', 'تعداد خلته', 'معاش کل', 'پرداخت', 'باقی'],
            [
              for (var i = 0; i < data.workers.length; i++)
                [
                  toPersianDigits(i + 1),
                  data.workers[i].name,
                  showText(data.workers[i].shift),
                  fmtNum(data.workers[i].gunny + data.workers[i].extraGunny),
                  fmtMoney(data.workers[i].total, data.workers[i].cur),
                  fmtMoney(data.workers[i].paid, data.workers[i].cur),
                  fmtMoney(data.workers[i].remaining, data.workers[i].cur),
                ],
            ],
          ),
          table(
            'مصارف',
            ['#', 'تاریخ', 'جنس', 'قیمت', 'پرداخت', 'باقی'],
            [
              for (var i = 0; i < data.expenses.length; i++)
                [
                  toPersianDigits(i + 1),
                  showDate(data.expenses[i].date),
                  data.expenses[i].item,
                  fmtMoney(data.expenses[i].price, data.expenses[i].cur),
                  fmtMoney(data.expenses[i].paid, data.expenses[i].cur),
                  fmtMoney(data.expenses[i].remaining, data.expenses[i].cur),
                ],
            ],
          ),
          if (data.isEmpty)
            pw.Padding(
              padding: const pw.EdgeInsets.all(30),
              child: pw.Center(
                child: pw.Text('برای این بازه هیچ رکوردی ثبت نشده است',
                    style: const pw.TextStyle(fontSize: 12)),
              ),
            ),
        ],
      ),
    );

    return doc.save();
  }

  /// پیش‌نمایش/چاپ/ذخیره PDF با پنجره سیستم
  Future<void> printReport(ReportData data) async {
    final bytes = await buildPdf(data);
    await Printing.layoutPdf(
      onLayout: (_) async => bytes,
      name: 'گزارش-گچ-صدف-${Jalali.today().storage.replaceAll('/', '-')}',
    );
  }

  Future<void> shareReportPdf(ReportData data) async {
    final bytes = await buildPdf(data);
    await Printing.sharePdf(
      bytes: bytes,
      filename: 'گزارش-گچ-صدف-${Jalali.today().storage.replaceAll('/', '-')}.pdf',
    );
  }
}
