import 'dart:math' as math;

import 'package:flutter/material.dart';

/// توکن‌های حرکت — همه انیمیشن‌های برنامه از همین‌ها استفاده می‌کنند
/// تا سرعت و حس حرکت در کل اپ یکدست باشد.
class AppMotion {
  static const fast = Duration(milliseconds: 140);
  static const base = Duration(milliseconds: 220);
  static const slow = Duration(milliseconds: 380);

  static const enter = Curves.easeOutCubic;
  static const exit = Curves.easeInCubic;
  static const press = Curves.easeOut;
  static const bouncy = Curves.easeOutBack;
}

/// ظاهر شدن نرم یک ویجت هنگام ورود به صفحه (Fade + Slide Up)
/// برای ظاهر شدن پی‌درپی کارت‌ها، `delay` را افزایشی بدهید (Stagger).
class FadeSlideIn extends StatefulWidget {
  final Widget child;
  final Duration delay;
  final double offsetY;

  const FadeSlideIn({
    super.key,
    required this.child,
    this.delay = Duration.zero,
    this.offsetY = 14,
  });

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: AppMotion.slow);
  late final Animation<double> _fade =
      CurvedAnimation(parent: _c, curve: AppMotion.enter);
  late final Animation<Offset> _slide = Tween(
    begin: Offset(0, widget.offsetY / 100),
    end: Offset.zero,
  ).animate(CurvedAnimation(parent: _c, curve: AppMotion.enter));

  @override
  void initState() {
    super.initState();
    Future.delayed(widget.delay, () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

/// واکنش فشردن (Press/Scale Effect) برای هر عنصر قابل کلیک —
/// کارت‌ها، دکمه‌ها و آیتم‌های لیست هنگام لمس کمی جمع می‌شوند.
class Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double scaleTo;
  final BorderRadius? borderRadius;

  const Pressable({
    super.key,
    required this.child,
    this.onTap,
    this.scaleTo = 0.97,
    this.borderRadius,
  });

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;

  void _set(bool v) {
    if (widget.onTap == null) return;
    setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => _set(true),
      onTapUp: (_) => _set(false),
      onTapCancel: () => _set(false),
      child: AnimatedScale(
        scale: _down ? widget.scaleTo : 1.0,
        duration: AppMotion.fast,
        curve: AppMotion.press,
        child: widget.child,
      ),
    );
  }
}

/// خط چشمک‌زن (Shimmer) برای حالت بارگذاری — جایگزین حرفه‌ای اسپینر
class Shimmer extends StatefulWidget {
  final double width;
  final double height;
  final BorderRadius borderRadius;
  const Shimmer({
    super.key,
    this.width = double.infinity,
    this.height = 14,
    this.borderRadius = const BorderRadius.all(Radius.circular(8)),
  });

  @override
  State<Shimmer> createState() => _ShimmerState();
}

class _ShimmerState extends State<Shimmer> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF2A3542)
        : const Color(0xFFE7EBEF);
    final hi = Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF3A4756)
        : const Color(0xFFF6F8FA);

    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        return Container(
          width: widget.width,
          height: widget.height,
          decoration: BoxDecoration(
            borderRadius: widget.borderRadius,
            gradient: LinearGradient(
              begin: Alignment(-1 + _c.value * 3, 0),
              end: Alignment(1 + _c.value * 3, 0),
              colors: [base, hi, base],
              stops: const [0.35, 0.5, 0.65],
            ),
          ),
        );
      },
    );
  }
}

/// یک کارت اسکلتی برای لیست‌های در حال بارگذاری
class SkeletonCard extends StatelessWidget {
  const SkeletonCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          const Shimmer(width: 110, height: 15),
          const Spacer(),
          const Shimmer(width: 50, height: 15),
        ]),
        const SizedBox(height: 12),
        const Shimmer(height: 12),
        const SizedBox(height: 8),
        Shimmer(width: MediaQuery.sizeOf(context).width * .5, height: 12),
      ]),
    );
  }
}

class SkeletonList extends StatelessWidget {
  final int count;
  const SkeletonList({super.key, this.count = 4});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(children: List.generate(count, (_) => const SkeletonCard())),
    );
  }
}

/// انتقال صفحه مدرن (Fade + Slide) به‌جای پرش خام Navigator
Route<T> modernRoute<T>(Widget page) {
  return PageRouteBuilder<T>(
    transitionDuration: AppMotion.base,
    reverseTransitionDuration: AppMotion.base,
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final curved = CurvedAnimation(parent: animation, curve: AppMotion.enter);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween(begin: const Offset(0, .04), end: Offset.zero)
              .animate(curved),
          child: child,
        ),
      );
    },
  );
}

/// لرزش افقی کوتاه — با تغییر `trigger` یک‌بار اجرا می‌شود (مثلاً هنگام پین اشتباه)
class Shake extends StatefulWidget {
  final Widget child;
  final int trigger;
  const Shake({super.key, required this.child, required this.trigger});

  @override
  State<Shake> createState() => _ShakeState();
}

class _ShakeState extends State<Shake> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void didUpdateWidget(Shake old) {
    super.didUpdateWidget(old);
    if (old.trigger != widget.trigger) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) {
        final t = _c.value;
        final dx = math.sin(t * math.pi * 5) * (1 - t) * 12;
        return Transform.translate(offset: Offset(dx, 0), child: child);
      },
    );
  }
}
