import 'package:flutter/material.dart';

/// هر بار که رکوردی ثبت/ویرایش/حذف شود این شمارنده بالا می‌رود
/// و همه صفحه‌هایی که به آن گوش می‌دهند خودکار تازه می‌شوند.
final ValueNotifier<int> dataChanged = ValueNotifier<int>(0);

void notifyDataChanged() => dataChanged.value++;

/// ساخت ویجتی که با هر تغییر اطلاعات، دوباره ساخته می‌شود
class DataBuilder<T> extends StatelessWidget {
  final Future<T> Function() load;
  final Widget Function(BuildContext context, T data) builder;
  final Widget? loading;

  const DataBuilder({super.key, required this.load, required this.builder, this.loading});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: dataChanged,
      builder: (context, _, __) => FutureBuilder<T>(
        future: load(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return loading ??
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: CircularProgressIndicator(strokeWidth: 2.5)),
                );
          }
          return builder(context, snap.data as T);
        },
      ),
    );
  }
}
