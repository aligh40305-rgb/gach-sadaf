import 'jalali.dart';

/// واحدهای پول
const String kAfghani = 'افغانی';
const String kDollar = 'دالر';
const List<String> kCurrencies = [kAfghani, kDollar];

String curSymbol(String? cur) => cur == kDollar ? '\$' : '؋';

/// جداکننده هزارگان + ارقام فارسی: 125000 -> ۱۲۵,۰۰۰
String fmtNum(Object? value) {
  final n = toDouble(value);
  final isNeg = n < 0;
  final abs = n.abs();
  final intPart = abs.truncate();
  final frac = abs - intPart;

  final raw = intPart.toString();
  final buf = StringBuffer();
  for (var i = 0; i < raw.length; i++) {
    if (i > 0 && (raw.length - i) % 3 == 0) buf.write(',');
    buf.write(raw[i]);
  }
  var out = buf.toString();
  if (frac > 0.0001) {
    final f = frac.toStringAsFixed(2).substring(2);
    out = '$out.$f';
  }
  return toPersianDigits((isNeg ? '-' : '') + out);
}

/// مبلغ همراه با نشانه پول: ۱۲۵,۰۰۰ ؋
String fmtMoney(Object? value, String? cur) => '${fmtNum(value)} ${curSymbol(cur)}';

double toDouble(Object? v) {
  if (v == null) return 0;
  if (v is num) return v.toDouble();
  final s = toEnglishDigits(v.toString()).replaceAll(',', '').trim();
  if (s.isEmpty) return 0;
  return double.tryParse(s) ?? 0;
}

int toInt(Object? v) => toDouble(v).round();

/// عدد بدون اعشار اضافی: 12.0 -> 12
String plainNum(Object? v) {
  final d = toDouble(v);
  if (d == d.truncateToDouble()) return d.truncate().toString();
  return d.toString();
}

String nowTimeStorage() {
  final n = DateTime.now();
  return '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}';
}

String showTime(String? t) =>
    (t == null || t.trim().isEmpty) ? '—' : toPersianDigits(t);

String showDate(String? d) =>
    (d == null || d.trim().isEmpty) ? '—' : toPersianDigits(d);

String showText(Object? v) {
  final s = v?.toString().trim() ?? '';
  return s.isEmpty ? '—' : s;
}
