/// تبدیل تاریخ میلادی <-> هجری شمسی (تقویم افغانی)
/// الگوریتم استاندارد jalaali — بدون هیچ وابستگی بیرونی.

const List<String> afghanMonths = [
  'حمل',
  'ثور',
  'جوزا',
  'سرطان',
  'اسد',
  'سنبله',
  'میزان',
  'عقرب',
  'قوس',
  'جدی',
  'دلو',
  'حوت',
];

const List<String> weekDays = [
  'دوشنبه', // DateTime.weekday == 1
  'سه‌شنبه',
  'چهارشنبه',
  'پنجشنبه',
  'جمعه',
  'شنبه',
  'یکشنبه',
];

const List<int> _breaks = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, //
  1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178,
];

int _div(int a, int b) => a ~/ b;
int _mod(int a, int b) => a - (a ~/ b) * b;

class _JalCal {
  final int leap;
  final int gy;
  final int march;
  const _JalCal(this.leap, this.gy, this.march);
}

_JalCal _jalCal(int jy) {
  final bl = _breaks.length;
  final gy = jy + 621;
  var leapJ = -14;
  var jp = _breaks[0];

  if (jy < jp || jy >= _breaks[bl - 1]) {
    throw ArgumentError('سال شمسی نامعتبر: $jy');
  }

  var jump = 0;
  for (var i = 1; i < bl; i++) {
    final jm = _breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + _div(jump, 33) * 8 + _div(_mod(jump, 33), 4);
    jp = jm;
  }
  var n = jy - jp;

  leapJ = leapJ + _div(n, 33) * 8 + _div(_mod(n, 33) + 3, 4);
  if (_mod(jump, 33) == 4 && jump - n == 4) leapJ += 1;

  final leapG = _div(gy, 4) - _div((_div(gy, 100) + 1) * 3, 4) - 150;
  final march = 20 + leapJ - leapG;

  if (jump - n < 6) n = n - jump + _div(jump + 4, 33) * 33;
  var leap = _mod(_mod(n + 1, 33) - 1, 4);
  if (leap == -1) leap = 4;

  return _JalCal(leap, gy, march);
}

int _g2d(int gy, int gm, int gd) {
  var d = _div((gy + _div(gm - 8, 6) + 100100) * 1461, 4) +
      _div(153 * _mod(gm + 9, 12) + 2, 5) +
      gd -
      34840408;
  d = d - _div(_div(gy + 100100 + _div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

List<int> _d2g(int jdn) {
  var j = 4 * jdn + 139361631;
  j = j + _div(_div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  final i = _div(_mod(j, 1461), 4) * 5 + 308;
  final gd = _div(_mod(i, 153), 5) + 1;
  final gm = _mod(_div(i, 153), 12) + 1;
  final gy = _div(j, 1461) - 100100 + _div(8 - gm, 6);
  return [gy, gm, gd];
}

int _j2d(int jy, int jm, int jd) {
  final r = _jalCal(jy);
  return _g2d(r.gy, 3, r.march) + (jm - 1) * 31 - _div(jm, 7) * (jm - 7) + jd - 1;
}

/// یک تاریخ شمسی (افغانی)
class Jalali {
  final int year;
  final int month; // ۱ = حمل
  final int day;

  const Jalali(this.year, this.month, this.day);

  factory Jalali.fromDateTime(DateTime dt) {
    final jdn = _g2d(dt.year, dt.month, dt.day);
    final g = _d2g(jdn);
    var jy = g[0] - 621;
    final r = _jalCal(jy);
    final jdn1f = _g2d(r.gy, 3, r.march);
    var k = jdn - jdn1f;
    if (k >= 0) {
      if (k <= 185) {
        return Jalali(jy, 1 + _div(k, 31), _mod(k, 31) + 1);
      }
      k -= 186;
    } else {
      jy -= 1;
      k += 179;
      if (r.leap == 1) k += 1;
    }
    return Jalali(jy, 7 + _div(k, 30), _mod(k, 30) + 1);
  }

  factory Jalali.today() => Jalali.fromDateTime(DateTime.now());

  /// از رشتهٔ «۱۴۰۵/۰۳/۲۲» یا «1405/3/22»
  static Jalali? tryParse(String? s) {
    if (s == null || s.trim().isEmpty) return null;
    final en = toEnglishDigits(s).replaceAll('-', '/').trim();
    final parts = en.split('/');
    if (parts.length != 3) return null;
    final y = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    final d = int.tryParse(parts[2]);
    if (y == null || m == null || d == null) return null;
    if (m < 1 || m > 12 || d < 1 || d > 31) return null;
    return Jalali(y, m, d);
  }

  DateTime toDateTime() {
    final g = _d2g(_j2d(year, month, day));
    return DateTime(g[0], g[1], g[2]);
  }

  bool get isLeapYear => _jalCal(year).leap == 1;

  int get monthLength {
    if (month <= 6) return 31;
    if (month <= 11) return 30;
    return isLeapYear ? 30 : 29;
  }

  String get monthName => afghanMonths[month - 1];

  /// قالب ذخیره در دیتابیس (همیشه ارقام انگلیسی): 1405/03/22
  String get storage =>
      '$year/${month.toString().padLeft(2, '0')}/${day.toString().padLeft(2, '0')}';

  /// نمایش برای کاربر: ۱۴۰۵/۰۳/۲۲
  String get display => toPersianDigits(storage);

  /// نمایش کامل: دوشنبه ۲۲ جوزا ۱۴۰۵
  String get fullDisplay {
    final w = weekDays[toDateTime().weekday - 1];
    return '$w ${toPersianDigits(day.toString())} $monthName ${toPersianDigits(year.toString())}';
  }

  @override
  String toString() => storage;
}

const _fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

String toPersianDigits(Object? input) {
  var s = input?.toString() ?? '';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(i.toString(), _fa[i]);
  }
  return s;
}

String toEnglishDigits(Object? input) {
  var s = input?.toString() ?? '';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(_fa[i], i.toString());
    s = s.replaceAll(['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'][i], i.toString());
  }
  return s;
}
