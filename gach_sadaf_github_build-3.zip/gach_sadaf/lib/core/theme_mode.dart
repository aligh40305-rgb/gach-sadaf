import 'package:flutter/material.dart';

import '../services/settings_service.dart';

/// حالت روشن/تاریک برنامه — یک نوتیفایر سراسری که در main.dart گوش داده می‌شود
final ValueNotifier<ThemeMode> appThemeMode =
    ValueNotifier<ThemeMode>(_fromStorage(Settings.instance.themeModeStorage));

ThemeMode _fromStorage(String s) {
  switch (s) {
    case 'light':
      return ThemeMode.light;
    case 'dark':
      return ThemeMode.dark;
    default:
      return ThemeMode.system;
  }
}

String _toStorage(ThemeMode m) {
  switch (m) {
    case ThemeMode.light:
      return 'light';
    case ThemeMode.dark:
      return 'dark';
    case ThemeMode.system:
      return 'system';
  }
}

void setAppThemeMode(ThemeMode mode) {
  appThemeMode.value = mode;
  Settings.instance.themeModeStorage = _toStorage(mode);
}
