import 'package:flutter/material.dart';

/// سیستم رنگ گچ صدف — یک منبع واحد رنگ برای کل اپلیکیشن (روشن + تاریک)
/// برگرفته از پالت لوگوی کارخانه (سرمه‌ای + طلایی)
class AppColors {
  // برند
  static const navy = Color(0xFF13324A);
  static const navyDark = Color(0xFF0A1E2E);
  static const navySoft = Color(0xFF1E4E73);
  static const gold = Color(0xFFC9A227);
  static const goldLight = Color(0xFFE7C765);

  // خاکستری‌های خنثی (نسخه روشن)
  static const sky = Color(0xFFE4EEF7);
  static const cream = Color(0xFFF3F5F8);
  static const surface = Color(0xFFFFFFFF);
  static const border = Color(0xFFE7EAEE);

  // متن (نسخه روشن)
  static const textDark = Color(0xFF16202B);
  static const textMid = Color(0xFF5B6774);
  static const textLight = Color(0xFF98A2AD);

  // وضعیت‌ها
  static const green = Color(0xFF0F9D6B);
  static const greenBg = Color(0xFFE3F7EE);
  static const greenText = Color(0xFF0B7A54);
  static const red = Color(0xFFE5484D);
  static const redBg = Color(0xFFFCE9E9);
  static const redText = Color(0xFFC22B30);
  static const blue = Color(0xFF2D6FE0);
  static const blueBg = Color(0xFFE7EFFD);
  static const amber = Color(0xFFB4740E);
  static const amberBg = Color(0xFFFCF0DA);
  static const purple = Color(0xFF7C5CE0);
  static const purpleBg = Color(0xFFEEE9FC);

  // --- نسخه تاریک ---
  static const darkBg = Color(0xFF0D1420);
  static const darkSurface = Color(0xFF16202E);
  static const darkSurfaceAlt = Color(0xFF1D2937);
  static const darkBorder = Color(0xFF2A3747);
  static const darkTextPrimary = Color(0xFFEDF1F5);
  static const darkTextMid = Color(0xFFA9B4C0);
  static const darkTextLight = Color(0xFF6E7A88);

  static const LinearGradient navyGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [navyDark, navy, navySoft],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [goldLight, gold],
  );
}

/// دسترسی سریع به رنگ‌های متن/سطح که خودکار بین حالت روشن و تاریک سوییچ می‌کنند —
/// ویجت‌های مشترک (SectionCard، KeyValueRow، Pill، ...) از همین استفاده می‌کنند
/// تا با هر دو حالت درست به نظر برسند.
extension AppThemeX on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  Color get textPrimary => isDark ? AppColors.darkTextPrimary : AppColors.textDark;
  Color get textSecondary => isDark ? AppColors.darkTextMid : AppColors.textMid;
  Color get textMuted => isDark ? AppColors.darkTextLight : AppColors.textLight;
  Color get cardBg => isDark ? AppColors.darkSurface : AppColors.surface;
  Color get cardBgAlt => isDark ? AppColors.darkSurfaceAlt : AppColors.sky;
  Color get borderColor => isDark ? AppColors.darkBorder : AppColors.border;
  Color get accent => isDark ? AppColors.goldLight : AppColors.navy;
}

/// شعاع گردی و سایه‌های استاندارد — برای یکدست بودن عمق بصری در کل اپ
class AppRadii {
  static const sm = 10.0;
  static const md = 14.0;
  static const lg = 18.0;
  static const xl = 24.0;
}

class AppShadows {
  static List<BoxShadow> soft(Brightness b) => [
        BoxShadow(
          color: b == Brightness.dark
              ? Colors.black.withValues(alpha: .35)
              : const Color(0x141B2A3A),
          blurRadius: 18,
          offset: const Offset(0, 6),
        ),
      ];

  static List<BoxShadow> lifted(Brightness b) => [
        BoxShadow(
          color: b == Brightness.dark
              ? Colors.black.withValues(alpha: .45)
              : const Color(0x1F1B2A3A),
          blurRadius: 26,
          offset: const Offset(0, 10),
        ),
      ];
}

ThemeData buildAppTheme() {
  const scheme = ColorScheme.light(
    primary: AppColors.navy,
    secondary: AppColors.gold,
    surface: AppColors.surface,
    error: AppColors.red,
  );

  return _base(scheme, Brightness.light);
}

ThemeData buildAppDarkTheme() {
  const scheme = ColorScheme.dark(
    primary: AppColors.goldLight,
    secondary: AppColors.gold,
    surface: AppColors.darkSurface,
    error: AppColors.red,
  );

  return _base(scheme, Brightness.dark);
}

ThemeData _base(ColorScheme scheme, Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final bg = dark ? AppColors.darkBg : AppColors.cream;
  final surface = dark ? AppColors.darkSurface : AppColors.surface;
  final border = dark ? AppColors.darkBorder : AppColors.border;
  final textDark = dark ? AppColors.darkTextPrimary : AppColors.textDark;
  final textMid = dark ? AppColors.darkTextMid : AppColors.textMid;

  final base = ThemeData(
    useMaterial3: true,
    fontFamily: 'Vazirmatn',
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    cardColor: surface,
    dividerColor: border,
    splashFactory: InkRipple.splashFactory,
  );

  return base.copyWith(
    textTheme: base.textTheme.apply(
      bodyColor: textDark,
      displayColor: textDark,
      fontFamily: 'Vazirmatn',
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: dark ? AppColors.darkSurface : AppColors.navy,
      foregroundColor: Colors.white,
      elevation: 0,
      centerTitle: false,
      surfaceTintColor: Colors.transparent,
      titleTextStyle: const TextStyle(
        fontFamily: 'Vazirmatn',
        fontSize: 16,
        fontWeight: FontWeight.w800,
        color: Colors.white,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.sm),
        borderSide: BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.sm),
        borderSide: BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.sm),
        borderSide: BorderSide(
            color: dark ? AppColors.goldLight : AppColors.navy, width: 1.8),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.sm),
        borderSide: const BorderSide(color: AppColors.red, width: 1.4),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.sm),
        borderSide: const BorderSide(color: AppColors.red, width: 1.8),
      ),
      labelStyle: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: textMid),
      floatingLabelStyle: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w800,
        color: dark ? AppColors.goldLight : AppColors.navy,
      ),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.lg),
        side: BorderSide(color: border),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: dark ? AppColors.goldLight : AppColors.navy,
        foregroundColor: dark ? AppColors.navyDark : Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.md)),
        textStyle: const TextStyle(
          fontFamily: 'Vazirmatn',
          fontWeight: FontWeight.w800,
          fontSize: 14,
        ),
      ).copyWith(
        overlayColor: WidgetStatePropertyAll(Colors.white.withValues(alpha: .08)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: dark ? AppColors.darkTextPrimary : AppColors.navy,
        side: BorderSide(color: border, width: 1.3),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.md)),
        textStyle: const TextStyle(
            fontFamily: 'Vazirmatn', fontWeight: FontWeight.w700, fontSize: 13.5),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: dark ? AppColors.goldLight : AppColors.navy,
        textStyle:
            const TextStyle(fontFamily: 'Vazirmatn', fontWeight: FontWeight.w800),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: dark ? AppColors.darkSurfaceAlt : AppColors.sky,
      labelStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: textDark),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      side: BorderSide.none,
    ),
    dividerTheme: DividerThemeData(color: border, thickness: 1, space: 1),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: dark ? AppColors.darkSurfaceAlt : AppColors.navyDark,
      behavior: SnackBarBehavior.floating,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.md)),
      contentTextStyle: const TextStyle(
          fontFamily: 'Vazirmatn', fontSize: 13, color: Colors.white, height: 1.5),
      insetPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.lg)),
      titleTextStyle: TextStyle(
          fontFamily: 'Vazirmatn', fontWeight: FontWeight.w800, fontSize: 16, color: textDark),
      contentTextStyle:
          TextStyle(fontFamily: 'Vazirmatn', fontSize: 13.5, height: 1.7, color: textMid),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(AppRadii.xl)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      indicatorColor: dark
          ? AppColors.goldLight.withValues(alpha: .18)
          : AppColors.navy.withValues(alpha: .10),
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontFamily: 'Vazirmatn',
          fontSize: 11,
          fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
          color: selected
              ? (dark ? AppColors.goldLight : AppColors.navy)
              : textMid,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          color: selected
              ? (dark ? AppColors.goldLight : AppColors.navy)
              : textMid,
        );
      }),
    ),
    drawerTheme: DrawerThemeData(
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(AppRadii.xl)),
      ),
    ),
    checkboxTheme: CheckboxThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      fillColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return dark ? AppColors.goldLight : AppColors.navy;
        }
        return Colors.transparent;
      }),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return dark ? AppColors.navyDark : Colors.white;
        }
        return null;
      }),
      trackColor: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return dark ? AppColors.goldLight : AppColors.navy;
        }
        return null;
      }),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: ButtonStyle(
        textStyle: const WidgetStatePropertyAll(
            TextStyle(fontFamily: 'Vazirmatn', fontSize: 12, fontWeight: FontWeight.w700)),
        backgroundColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return dark ? AppColors.goldLight : AppColors.navy;
          }
          return surface;
        }),
        foregroundColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return dark ? AppColors.navyDark : Colors.white;
          }
          return textMid;
        }),
        side: WidgetStatePropertyAll(BorderSide(color: border)),
      ),
    ),
  );
}
