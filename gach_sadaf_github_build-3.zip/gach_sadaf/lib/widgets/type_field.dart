import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/inventory_service.dart';
import 'common.dart';

/// نوع گچ را کاربر خودش تایپ می‌کند؛ زیر فیلد، نوع‌هایی که قبلاً استفاده شده
/// پیشنهاد می‌شود تا با یک لمس پر شود (و املای یک نوع در انبار پراکنده نشود).
class TypeField extends StatefulWidget {
  final TextEditingController controller;
  final VoidCallback? onChanged;
  final String label;

  const TypeField({
    super.key,
    required this.controller,
    this.onChanged,
    this.label = 'نوعیت گچ *',
  });

  @override
  State<TypeField> createState() => _TypeFieldState();
}

class _TypeFieldState extends State<TypeField> {
  late final Future<List<String>> _known = InventoryService.instance.knownTypes();

  void _changed() {
    setState(() {});
    widget.onChanged?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      AppField(
        controller: widget.controller,
        label: widget.label,
        hint: 'مثلاً: گچ سفید',
        icon: Icons.category_rounded,
        onChanged: (_) => _changed(),
      ),
      FutureBuilder<List<String>>(
        future: _known,
        builder: (context, snap) {
          final all = snap.data ?? const <String>[];
          final typed = widget.controller.text.trim();
          final list = [
            for (final t in all)
              if (t != typed && (typed.isEmpty || t.contains(typed))) t,
          ].take(6).toList();
          if (list.isEmpty) return const SizedBox.shrink();
          return Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Wrap(spacing: 6, runSpacing: 4, children: [
              for (final t in list)
                ActionChip(
                  visualDensity: VisualDensity.compact,
                  onPressed: () {
                    widget.controller.text = t;
                    _changed();
                  },
                  label: Text(t,
                      style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                          color: context.textPrimary)),
                ),
            ]),
          );
        },
      ),
    ]);
  }
}
