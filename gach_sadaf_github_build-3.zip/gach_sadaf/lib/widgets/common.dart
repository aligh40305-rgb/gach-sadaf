import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';

// ───────────────────────── فیلدهای فرم ─────────────────────────

/// فیلد متن با نشانگر فوکوس متحرک — وقتی کاربر روی فیلد می‌رود
/// یک خط رنگی کنار آن به‌نرمی ظاهر می‌شود.
class AppField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final bool number;
  final bool readOnly;
  final int maxLines;
  final TextInputType? keyboard;
  final ValueChanged<String>? onChanged;
  final Color? fill;
  final Color? textColor;
  final String? errorText;
  final IconData? icon;

  const AppField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.number = false,
    this.readOnly = false,
    this.maxLines = 1,
    this.keyboard,
    this.onChanged,
    this.fill,
    this.textColor,
    this.errorText,
    this.icon,
  });

  @override
  State<AppField> createState() => _AppFieldState();
}

class _AppFieldState extends State<AppField> {
  final _focusNode = FocusNode();
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      if (mounted) setState(() => _focused = _focusNode.hasFocus);
    });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasError = (widget.errorText ?? '').isNotEmpty;
    final accent = hasError ? AppColors.red : context.accent;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        AnimatedContainer(
          duration: AppMotion.base,
          curve: AppMotion.enter,
          width: _focused || hasError ? 3 : 0,
          margin: const EdgeInsets.only(left: 6),
          decoration: BoxDecoration(
            color: accent,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: widget.controller,
                focusNode: _focusNode,
                readOnly: widget.readOnly,
                maxLines: widget.maxLines,
                onChanged: widget.onChanged,
                textDirection: widget.number ? TextDirection.ltr : null,
                textAlign: widget.number ? TextAlign.right : TextAlign.start,
                keyboardType: widget.keyboard ??
                    (widget.number
                        ? const TextInputType.numberWithOptions(decimal: true)
                        : TextInputType.text),
                inputFormatters: widget.number
                    ? [FilteringTextInputFormatter.allow(RegExp(r'[0-9.\-]'))]
                    : null,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: widget.readOnly ? FontWeight.w800 : FontWeight.w500,
                  color: widget.textColor ?? context.textPrimary,
                ),
                decoration: InputDecoration(
                  labelText: widget.label,
                  hintText: widget.hint,
                  errorText: widget.errorText,
                  prefixIcon: widget.icon == null
                      ? null
                      : Icon(widget.icon, size: 19, color: context.textMuted),
                  hintStyle: TextStyle(fontSize: 12, color: context.textMuted),
                  fillColor: widget.fill ?? context.cardBg,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class AppDropdown extends StatelessWidget {
  final String label;
  final String? value;
  final List<String> items;
  final ValueChanged<String?> onChanged;
  final bool allowEmpty;

  const AppDropdown({
    super.key,
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
    this.allowEmpty = false,
  });

  @override
  Widget build(BuildContext context) {
    final list = allowEmpty ? ['', ...items] : items;
    final v = list.contains(value) ? value : (allowEmpty ? '' : null);
    return DropdownButtonFormField<String>(
      value: v,
      isExpanded: true,
      icon: Icon(Icons.keyboard_arrow_down_rounded, color: context.textMuted),
      decoration: InputDecoration(labelText: label),
      dropdownColor: context.cardBg,
      borderRadius: BorderRadius.circular(AppRadii.md),
      style: TextStyle(
        fontFamily: 'Vazirmatn',
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: context.textPrimary,
      ),
      items: [
        for (final it in list)
          DropdownMenuItem(
            value: it,
            child: Text(it.isEmpty ? 'انتخاب کنید' : it,
                style: const TextStyle(fontSize: 14)),
          ),
      ],
      onChanged: onChanged,
    );
  }
}

/// فیلد تاریخ شمسی — با انتخابگر سال/ماه/روز
class JalaliField extends StatefulWidget {
  final String label;
  final String? value; // ذخیره: 1405/03/22
  final ValueChanged<String> onChanged;

  const JalaliField({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  State<JalaliField> createState() => _JalaliFieldState();
}

class _JalaliFieldState extends State<JalaliField> {
  @override
  Widget build(BuildContext context) {
    final has = (widget.value ?? '').trim().isNotEmpty;
    return Pressable(
      borderRadius: BorderRadius.circular(AppRadii.sm),
      onTap: () async {
        final picked = await showJalaliPicker(
          context,
          initial: Jalali.tryParse(widget.value) ?? Jalali.today(),
        );
        if (picked != null) widget.onChanged(picked.storage);
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: widget.label,
          suffixIcon: has
              ? IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => widget.onChanged(''),
                )
              : Icon(Icons.calendar_month_rounded, size: 20, color: context.accent),
        ),
        child: Text(
          has ? toPersianDigits(widget.value) : 'انتخاب تاریخ',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: has ? context.textPrimary : context.textMuted,
          ),
        ),
      ),
    );
  }
}

/// فیلد ساعت
class TimeField extends StatelessWidget {
  final String label;
  final String? value; // 14:30
  final ValueChanged<String> onChanged;

  const TimeField({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final has = (value ?? '').trim().isNotEmpty;
    return Pressable(
      borderRadius: BorderRadius.circular(AppRadii.sm),
      onTap: () async {
        final parts = toEnglishDigits(value ?? '').split(':');
        final now = TimeOfDay.now();
        final init = parts.length == 2
            ? TimeOfDay(
                hour: int.tryParse(parts[0]) ?? now.hour,
                minute: int.tryParse(parts[1]) ?? now.minute)
            : now;
        final picked = await showTimePicker(context: context, initialTime: init);
        if (picked != null) {
          onChanged('${picked.hour.toString().padLeft(2, '0')}:'
              '${picked.minute.toString().padLeft(2, '0')}');
        }
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: Icon(Icons.schedule_rounded, size: 20, color: context.accent),
        ),
        child: Text(
          has ? toPersianDigits(value) : 'انتخاب ساعت',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: has ? context.textPrimary : context.textMuted,
          ),
        ),
      ),
    );
  }
}

Future<Jalali?> showJalaliPicker(BuildContext context, {required Jalali initial}) {
  var year = initial.year;
  var month = initial.month;
  var day = initial.day;

  return showGeneralDialog<Jalali>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'انتخاب تاریخ',
    barrierColor: Colors.black.withValues(alpha: .45),
    transitionDuration: AppMotion.base,
    pageBuilder: (ctx, _, __) => const SizedBox.shrink(),
    transitionBuilder: (ctx, anim, __, ___) {
      final curved = CurvedAnimation(parent: anim, curve: AppMotion.bouncy);
      return Opacity(
        opacity: anim.value.clamp(0.0, 1.0).toDouble(),
        child: ScaleTransition(
          scale: Tween(begin: .92, end: 1.0).animate(curved),
          child: Center(
            child: StatefulBuilder(
              builder: (ctx, setState) {
                final maxDay = Jalali(year, month, 1).monthLength;
                if (day > maxDay) day = maxDay;
                return Dialog(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadii.lg)),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Row(children: [
                        Icon(Icons.calendar_month_rounded, color: ctx.accent, size: 20),
                        const SizedBox(width: 8),
                        const Text('انتخاب تاریخ',
                            style:
                                TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      ]),
                      const SizedBox(height: 16),
                      Row(children: [
                        Expanded(
                          child: AppDropdown(
                            label: 'روز',
                            value: day.toString(),
                            items: [for (var i = 1; i <= maxDay; i++) i.toString()],
                            onChanged: (v) => setState(() => day = int.parse(v!)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          flex: 2,
                          child: AppDropdown(
                            label: 'ماه',
                            value: afghanMonths[month - 1],
                            items: afghanMonths,
                            onChanged: (v) =>
                                setState(() => month = afghanMonths.indexOf(v!) + 1),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: AppDropdown(
                            label: 'سال',
                            value: year.toString(),
                            items: [
                              for (var y = Jalali.today().year - 5;
                                  y <= Jalali.today().year + 2;
                                  y++)
                                y.toString()
                            ],
                            onChanged: (v) => setState(() => year = int.parse(v!)),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: ctx.cardBgAlt,
                          borderRadius: BorderRadius.circular(AppRadii.sm),
                        ),
                        child: Text(
                          Jalali(year, month, day).fullDisplay,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontWeight: FontWeight.w800, color: ctx.accent),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, Jalali.today()),
                          child: const Text('امروز'),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('انصراف'),
                        ),
                        const SizedBox(width: 4),
                        ElevatedButton(
                          onPressed: () =>
                              Navigator.pop(ctx, Jalali(year, month, day)),
                          child: const Text('تایید'),
                        ),
                      ]),
                    ]),
                  ),
                );
              },
            ),
          ),
        ),
      );
    },
  );
}

// ───────────────────────── کارت‌ها و نشان‌ها ─────────────────────────

class SectionCard extends StatelessWidget {
  final String? title;
  final IconData? icon;
  final Color? titleColor;
  final Color? background;
  final Widget child;
  final EdgeInsetsGeometry padding;

  const SectionCard({
    super.key,
    this.title,
    this.icon,
    this.titleColor,
    this.background,
    required this.child,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: background ?? context.cardBg,
        borderRadius: BorderRadius.circular(AppRadii.lg),
        border: Border.all(color: context.borderColor),
        boxShadow: AppShadows.soft(Theme.of(context).brightness),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null) ...[
            Row(children: [
              if (icon != null) ...[
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: (titleColor ?? context.accent).withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, size: 16, color: titleColor ?? context.accent),
                ),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Text(
                  title!,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: titleColor ?? context.textPrimary,
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 12),
          ],
          child,
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  final IconData? icon;
  const Pill(this.text, {super.key, required this.bg, required this.fg, this.icon});

  factory Pill.green(String t, {IconData? icon}) =>
      Pill(t, bg: AppColors.greenBg, fg: AppColors.greenText, icon: icon);
  factory Pill.red(String t, {IconData? icon}) =>
      Pill(t, bg: AppColors.redBg, fg: AppColors.redText, icon: icon);
  factory Pill.blue(String t, {IconData? icon}) =>
      Pill(t, bg: AppColors.blueBg, fg: AppColors.blue, icon: icon);
  factory Pill.amber(String t, {IconData? icon}) =>
      Pill(t, bg: AppColors.amberBg, fg: AppColors.amber, icon: icon);

  @override
  Widget build(BuildContext context) {
    final dark = context.isDark;
    final bgColor = dark ? fg.withValues(alpha: .16) : bg;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[
          Icon(icon, size: 12, color: fg),
          const SizedBox(width: 4),
        ],
        Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: fg)),
      ]),
    );
  }
}

class KeyValueRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool big;

  const KeyValueRow(this.label, this.value,
      {super.key, this.valueColor, this.big = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontSize: 12.5, color: context.textSecondary)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: big ? 15 : 13,
                fontWeight: FontWeight.w800,
                color: valueColor ?? context.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// حالت خالی — با آیکن، توضیح کوتاه و در صورت نیاز یک دکمه اقدام
class EmptyState extends StatelessWidget {
  final String text;
  final IconData icon;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyState(this.text,
      {super.key, this.icon = Icons.inbox_outlined, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return FadeSlideIn(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 44),
        child: Column(children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: context.cardBgAlt,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 32, color: context.textMuted),
          ),
          const SizedBox(height: 14),
          Text(text,
              textAlign: TextAlign.center,
              style: TextStyle(color: context.textSecondary, fontSize: 13.5, height: 1.6)),
          if (actionLabel != null && onAction != null) ...[
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: onAction,
              icon: const Icon(Icons.add, size: 17),
              label: Text(actionLabel!),
            ),
          ],
        ]),
      ),
    );
  }
}

class SearchBox extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  const SearchBox({super.key, required this.hint, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return TextField(
      onChanged: onChanged,
      style: const TextStyle(fontSize: 13.5),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(fontSize: 13, color: context.textMuted),
        prefixIcon: Icon(Icons.search_rounded, size: 21, color: context.textMuted),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.md),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.md),
          borderSide: BorderSide.none,
        ),
        fillColor: context.cardBgAlt,
      ),
    );
  }
}

// ───────────────────────── کمک‌کننده‌ها ─────────────────────────

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String okText = 'تایید',
  bool danger = false,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          color: danger ? AppColors.redBg : AppColors.blueBg,
          shape: BoxShape.circle,
        ),
        child: Icon(
          danger ? Icons.warning_amber_rounded : Icons.help_outline_rounded,
          color: danger ? AppColors.redText : AppColors.blue,
        ),
      ),
      title: Text(title, style: const TextStyle(fontSize: 16), textAlign: TextAlign.center),
      content:
          Text(message, style: const TextStyle(fontSize: 13.5, height: 1.8), textAlign: TextAlign.center),
      actionsAlignment: MainAxisAlignment.center,
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
        ElevatedButton(
          style: danger
              ? ElevatedButton.styleFrom(backgroundColor: AppColors.red)
              : null,
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(okText),
        ),
      ],
    ),
  );
  return r ?? false;
}

/// نوتیفیکیشن سبک با آیکن — برای اعلام موفقیت یا خطا بعد از هر عملیات
void toast(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Row(children: [
        Icon(
          error ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded,
          size: 19,
          color: error ? const Color(0xFFFFB4B7) : const Color(0xFF8CE8C3),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(message, style: const TextStyle(fontSize: 13))),
      ]),
      duration: const Duration(seconds: 3),
    ));
}

/// چیدمان دوستون‌هٔ فرم‌ها (روی موبایل خودکار یک‌ستونه می‌شود)
class FieldGrid extends StatelessWidget {
  final List<Widget> children;
  const FieldGrid({super.key, required this.children});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (ctx, c) {
      final two = c.maxWidth > 420;
      final width = two ? (c.maxWidth - 10) / 2 : c.maxWidth;
      return Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [
          for (final ch in children) SizedBox(width: width, child: ch),
        ],
      );
    });
  }
}
