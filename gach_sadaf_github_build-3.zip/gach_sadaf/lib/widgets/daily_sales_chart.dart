import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../data/models.dart';
import 'common.dart';

class _Day {
  final Jalali date;
  double total = 0;
  double paid = 0;
  int count = 0;
  _Day(this.date);
  double get remaining => total - paid;
}

/// گراف فروش روزانه برای داشبورد — مثل گزارش یک حسابدار:
/// برای هر روز دو ستون (فروش کل / وصول‌شده)، فیلتر ۷/۱۴/۳۰ روز،
/// فیلتر واحد پول، خلاصهٔ شاخص‌ها و جزئیات روز انتخاب‌شده.
class DailySalesChart extends StatefulWidget {
  final List<Sale> sales;
  const DailySalesChart({super.key, required this.sales});

  @override
  State<DailySalesChart> createState() => _DailySalesChartState();
}

class _DailySalesChartState extends State<DailySalesChart> {
  static const double _plotH = 150;
  static const double _labelH = 34;

  int _days = 7;
  String _cur = kAfghani;
  int? _selected;

  bool get _hasDollar => widget.sales.any((s) => s.cur == kDollar);

  /// از قدیمی‌ترین روز تا امروز؛ روزهای بدون فروش هم با مقدار صفر می‌آیند
  List<_Day> _build() {
    final now = DateTime.now();
    final list = <_Day>[];
    final index = <String, _Day>{};
    for (var i = _days - 1; i >= 0; i--) {
      final j = Jalali.fromDateTime(now.subtract(Duration(days: i)));
      final d = _Day(j);
      list.add(d);
      index[j.storage] = d;
    }
    for (final s in widget.sales) {
      if (s.cur != _cur) continue;
      final j = Jalali.tryParse(s.date);
      if (j == null) continue;
      final d = index[j.storage];
      if (d == null) continue;
      d.total += s.total;
      d.paid += s.paid;
      d.count++;
    }
    return list;
  }

  double _niceMax(double v) {
    if (v <= 0) return 1;
    final mag = math.pow(10, (math.log(v) / math.ln10).floor()).toDouble();
    final n = v / mag;
    final nice = n <= 1 ? 1 : (n <= 2 ? 2 : (n <= 5 ? 5 : 10));
    return nice * mag;
  }

  String _compact(double v) {
    String fix(double x) =>
        toPersianDigits(x == x.truncateToDouble() ? x.toStringAsFixed(0) : x.toStringAsFixed(1));
    if (v >= 1e6) return '${fix(v / 1e6)}M';
    if (v >= 1e3) return '${fix(v / 1e3)}K';
    return fix(v);
  }

  Widget _bar(double v, double top, double w, Color c) {
    final target = top <= 0 ? 0.0 : (v / top) * (_plotH - 6);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: target),
      duration: AppMotion.slow,
      curve: AppMotion.enter,
      builder: (_, h, __) => Container(
        width: w,
        height: h,
        decoration: BoxDecoration(
          color: c,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
        ),
      ),
    );
  }

  Widget _slot(BuildContext context, int i, _Day d, double slotW, double top, int selIndex) {
    final selected = i == selIndex;
    final barW = ((slotW * 0.72) / 2 - 1).clamp(4.0, 14.0).toDouble();
    final showMonth = i == 0 || d.date.day == 1;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _selected = i),
      child: SizedBox(
        width: slotW,
        child: Column(children: [
          SizedBox(
            height: _plotH,
            child: AnimatedContainer(
              duration: AppMotion.base,
              margin: const EdgeInsets.symmetric(horizontal: 1),
              decoration: BoxDecoration(
                color: selected ? context.accent.withValues(alpha: .10) : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _bar(d.total, top, barW, context.accent),
                  const SizedBox(width: 2),
                  _bar(d.paid, top, barW, AppColors.green),
                ],
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            toPersianDigits(d.date.day),
            style: TextStyle(
              fontSize: 10,
              fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
              color: selected ? context.accent : context.textSecondary,
            ),
          ),
          Text(
            showMonth ? d.date.monthName : '',
            maxLines: 1,
            style: TextStyle(fontSize: 8.5, color: context.textMuted),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final days = _build();
    final n = days.length;
    final maxV = days.fold<double>(0, (m, d) => d.total > m ? d.total : m);
    final top = _niceMax(maxV);

    final totalSum = days.fold<double>(0, (s, d) => s + d.total);
    final paidSum = days.fold<double>(0, (s, d) => s + d.paid);
    final avg = totalSum / n;
    final best = days.reduce((a, b) => b.total > a.total ? b : a);
    final today = days.last;

    final selIndex = (_selected ?? n - 1).clamp(0, n - 1).toInt();
    final sel = days[selIndex];

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // انتخاب بازه و واحد پول
      Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
        for (final d in const [7, 14, 30])
          ChoiceChip(
            label: Text('${toPersianDigits(d)} روز'),
            selected: _days == d,
            showCheckmark: false,
            selectedColor: context.accent.withValues(alpha: .18),
            onSelected: (_) => setState(() {
              _days = d;
              _selected = null;
            }),
          ),
        if (_hasDollar)
          for (final c in const [kAfghani, kDollar])
            ChoiceChip(
              avatar: Text(curSymbol(c), style: const TextStyle(fontWeight: FontWeight.w800)),
              label: Text(c),
              selected: _cur == c,
              showCheckmark: false,
              selectedColor: AppColors.gold.withValues(alpha: .25),
              onSelected: (_) => setState(() => _cur = c),
            ),
      ]),
      const SizedBox(height: 14),

      // شاخص‌های خلاصه
      Row(children: [
        Expanded(child: _Kpi('فروش امروز', fmtMoney(today.total, _cur), AppColors.blue)),
        const SizedBox(width: 8),
        Expanded(child: _Kpi('میانگین روزانه', fmtMoney(avg, _cur), AppColors.amber)),
        const SizedBox(width: 8),
        Expanded(
          child: _Kpi(
            'بهترین روز',
            best.total > 0 ? fmtMoney(best.total, _cur) : '—',
            AppColors.greenText,
            sub: best.total > 0 ? best.date.display.substring(5) : null,
          ),
        ),
      ]),
      const SizedBox(height: 16),

      // راهنمای رنگ‌ها
      Row(children: [
        _Legend(context.accent, 'فروش کل'),
        const SizedBox(width: 14),
        _Legend(AppColors.green, 'وصول‌شده'),
        const Spacer(),
        Text('مجموع ${toPersianDigits(_days)} روز: ${fmtMoney(totalSum, _cur)}',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: context.textSecondary)),
      ]),
      const SizedBox(height: 10),

      // نمودار
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: 38,
          height: _plotH + _labelH,
          child: Stack(children: [
            for (var k = 0; k <= 3; k++)
              Positioned(
                top: _plotH * k / 3 - 6,
                left: 0,
                right: 0,
                child: Text(
                  _compact(top * (3 - k) / 3),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 9, color: context.textMuted),
                ),
              ),
          ]),
        ),
        Expanded(
          child: LayoutBuilder(builder: (context, c) {
            final fit = c.maxWidth / n;
            final scroll = fit < 26;
            final slotW = scroll ? 26.0 : fit;
            final plot = SizedBox(
              width: slotW * n,
              height: _plotH + _labelH,
              child: Stack(children: [
                for (var k = 0; k <= 3; k++)
                  Positioned(
                    top: _plotH * k / 3,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 1,
                      color: k == 3
                          ? context.borderColor
                          : context.borderColor.withValues(alpha: .55),
                    ),
                  ),
                Row(children: [
                  for (var i = 0; i < n; i++) _slot(context, i, days[i], slotW, top, selIndex),
                ]),
              ]),
            );
            return scroll
                ? SingleChildScrollView(scrollDirection: Axis.horizontal, reverse: true, child: plot)
                : plot;
          }),
        ),
      ]),
      const SizedBox(height: 12),

      // جزئیات روز انتخاب‌شده
      AnimatedSwitcher(
        duration: AppMotion.base,
        child: Container(
          key: ValueKey('${sel.date.storage}-$_cur-$_days'),
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: context.cardBgAlt,
            borderRadius: BorderRadius.circular(AppRadii.md),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.event_note_rounded, size: 16, color: context.accent),
              const SizedBox(width: 6),
              Expanded(
                child: Text(sel.date.fullDisplay,
                    style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: context.textPrimary)),
              ),
              Pill.blue('${toPersianDigits(sel.count)} فاکتور'),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _Mini('فروش کل', fmtMoney(sel.total, _cur), context.textPrimary)),
              Expanded(child: _Mini('وصول‌شده', fmtMoney(sel.paid, _cur), AppColors.greenText)),
              Expanded(
                child: _Mini('باقی', fmtMoney(sel.remaining, _cur),
                    sel.remaining > 0 ? AppColors.redText : context.textSecondary),
              ),
            ]),
          ]),
        ),
      ),
      if (paidSum < totalSum) ...[
        const SizedBox(height: 8),
        Text(
          'در این بازه ${fmtMoney(totalSum - paidSum, _cur)} از فروش هنوز وصول نشده است.',
          style: const TextStyle(fontSize: 11, color: AppColors.redText, fontWeight: FontWeight.w700),
        ),
      ],
    ]);
  }
}

class _Kpi extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final String? sub;
  const _Kpi(this.label, this.value, this.color, {this.sub});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: context.isDark ? .16 : .09),
        borderRadius: BorderRadius.circular(AppRadii.md),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: color)),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: AlignmentDirectional.centerStart,
          child: Text(value, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: color)),
        ),
        if (sub != null)
          Text(sub!, style: TextStyle(fontSize: 9.5, color: color.withValues(alpha: .8))),
      ]),
    );
  }
}

class _Mini extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _Mini(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: TextStyle(fontSize: 10.5, color: context.textSecondary)),
      const SizedBox(height: 3),
      FittedBox(
        fit: BoxFit.scaleDown,
        alignment: AlignmentDirectional.centerStart,
        child: Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: color)),
      ),
    ]);
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend(this.color, this.label);

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3)),
      ),
      const SizedBox(width: 5),
      Text(label, style: TextStyle(fontSize: 11, color: context.textSecondary)),
    ]);
  }
}
