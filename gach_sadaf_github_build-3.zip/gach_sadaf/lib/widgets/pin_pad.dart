import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/motion.dart';
import '../core/theme.dart';

/// نقطه‌های پین — هر رقم واردشده یک نقطه را پر می‌کند
class PinDots extends StatelessWidget {
  final int length;
  final int filled;
  final bool error;
  final bool onDark;

  const PinDots({
    super.key,
    required this.length,
    required this.filled,
    this.error = false,
    this.onDark = true,
  });

  @override
  Widget build(BuildContext context) {
    final fillColor = error
        ? AppColors.red
        : (onDark ? AppColors.goldLight : context.accent);
    final emptyBorder = onDark ? Colors.white38 : context.borderColor;

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (var i = 0; i < length; i++)
          AnimatedContainer(
            duration: AppMotion.fast,
            curve: AppMotion.bouncy,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            width: i < filled ? 18 : 16,
            height: i < filled ? 18 : 16,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: i < filled ? fillColor : Colors.transparent,
              border: Border.all(
                color: i < filled ? fillColor : emptyBorder,
                width: 1.6,
              ),
            ),
          ),
      ],
    );
  }
}

/// صفحه‌کلید عددی ۰ تا ۹ با دکمهٔ پاک‌کردن؛ در خانهٔ پایین-چپ می‌توان ویجت دلخواه
/// (مثلاً دکمهٔ اثر انگشت) گذاشت.
class NumPad extends StatelessWidget {
  final ValueChanged<String> onDigit;
  final VoidCallback onBackspace;
  final Widget? extra;
  final bool onDark;

  const NumPad({
    super.key,
    required this.onDigit,
    required this.onBackspace,
    this.extra,
    this.onDark = true,
  });

  @override
  Widget build(BuildContext context) {
    final fill = onDark ? Colors.white.withValues(alpha: .08) : context.cardBgAlt;
    final fg = onDark ? Colors.white : context.textPrimary;

    Widget keyBox({String? label, IconData? icon, required VoidCallback onTap}) {
      return Expanded(
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Pressable(
            scaleTo: 0.9,
            onTap: () {
              HapticFeedback.selectionClick();
              onTap();
            },
            child: Container(
              height: 58,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: fill, shape: BoxShape.circle),
              child: icon != null
                  ? Icon(icon, size: 21, color: fg.withValues(alpha: .75))
                  : Text(label!,
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: fg)),
            ),
          ),
        ),
      );
    }

    Widget digitRow(List<String> d) => Row(children: [
          for (final x in d) keyBox(label: x, onTap: () => onDigit(x)),
        ]);

    // صفحه‌کلید عددی همیشه چپ‌به‌راست است (۱ ۲ ۳ از چپ) مثل همهٔ گوشی‌ها
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
      digitRow(const ['1', '2', '3']),
      digitRow(const ['4', '5', '6']),
      digitRow(const ['7', '8', '9']),
      Row(children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(6),
            child: SizedBox(height: 58, child: Center(child: extra)),
          ),
        ),
        keyBox(label: '0', onTap: () => onDigit('0')),
        keyBox(icon: Icons.backspace_outlined, onTap: onBackspace),
      ]),
    ]),
    );
  }
}
