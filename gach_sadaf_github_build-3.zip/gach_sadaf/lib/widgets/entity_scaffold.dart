import 'package:flutter/material.dart';

import '../core/events.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../data/db.dart';
import '../data/models.dart';
import 'common.dart';
import 'invoice.dart';

/// اسکلت مشترک همه صفحه‌های ثبت (کارگران، سنگ، تولید، فروشات، مصارف)
class EntityScaffold<TRec extends Rec> extends StatefulWidget {
  final String table;
  final String searchHint;
  final String emptyText;
  final String addLabel;
  final Color color;

  /// خواندن رکوردها از دیتابیس
  final Future<List<TRec>> Function() load;

  /// آیا رکورد با متن جستجو می‌خواند؟
  final bool Function(TRec rec, String query) match;

  /// کارت نمایش یک رکورد
  final Widget Function(BuildContext context, TRec rec) card;

  /// فرم ثبت/ویرایش — اگر rec خالی باشد یعنی رکورد جدید
  final Future<bool> Function(BuildContext context, TRec? rec) openForm;

  /// ویجت اختیاری بالای لیست (مثلا دکمه گروه‌بندی)
  final Widget? topBar;

  const EntityScaffold({
    super.key,
    required this.table,
    required this.searchHint,
    required this.emptyText,
    required this.addLabel,
    required this.color,
    required this.load,
    required this.match,
    required this.card,
    required this.openForm,
    this.topBar,
  });

  @override
  State<EntityScaffold<TRec>> createState() => _EntityScaffoldState<TRec>();
}

class _EntityScaffoldState<TRec extends Rec> extends State<EntityScaffold<TRec>> {
  String _query = '';
  bool _fabDown = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: GestureDetector(
        onTapDown: (_) => setState(() => _fabDown = true),
        onTapUp: (_) => setState(() => _fabDown = false),
        onTapCancel: () => setState(() => _fabDown = false),
        child: AnimatedScale(
          scale: _fabDown ? 0.93 : 1.0,
          duration: AppMotion.fast,
          curve: AppMotion.press,
          child: FloatingActionButton.extended(
            backgroundColor: widget.color,
            foregroundColor: Colors.white,
            elevation: 3,
            onPressed: () => widget.openForm(context, null),
            icon: const Icon(Icons.add_rounded),
            label: Text(widget.addLabel,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          ),
        ),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
          child: SearchBox(
            hint: widget.searchHint,
            onChanged: (v) => setState(() => _query = v.trim()),
          ),
        ),
        if (widget.topBar != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
            child: widget.topBar!,
          ),
        Expanded(
          child: DataBuilder<List<TRec>>(
            load: widget.load,
            loading: const SkeletonList(),
            builder: (context, all) {
              final list = _query.isEmpty
                  ? all
                  : all.where((r) => widget.match(r, _query)).toList();
              if (list.isEmpty) {
                return SingleChildScrollView(
                  child: EmptyState(
                    _query.isEmpty ? widget.emptyText : 'نتیجه‌ای پیدا نشد',
                    icon: _query.isEmpty ? Icons.inbox_outlined : Icons.search_off_rounded,
                    actionLabel: _query.isEmpty ? widget.addLabel : null,
                    onAction: _query.isEmpty ? () => widget.openForm(context, null) : null,
                  ),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) => FadeSlideIn(
                  delay: Duration(milliseconds: 28 * i.clamp(0, 10).toInt()),
                  child: widget.card(context, list[i]),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

/// کارت استاندارد یک رکورد با دکمه‌های فاکتور/ویرایش/حذف — با واکنش فشردن
class RecordCard extends StatefulWidget {
  final Rec record;
  final String title;
  final String? subtitle;
  final Color color;
  final List<Widget> rows;
  final Future<bool> Function() onEdit;

  /// وقتی رکورد حذف می‌شود، قبل از حذف واقعی صدا زده می‌شود —
  /// برای مثال برگرداندن اثر آن روی موجودی انبار (تولید/فروش)
  final Future<void> Function()? onBeforeDelete;

  const RecordCard({
    super.key,
    required this.record,
    required this.title,
    required this.color,
    required this.rows,
    required this.onEdit,
    this.subtitle,
    this.onBeforeDelete,
  });

  @override
  State<RecordCard> createState() => _RecordCardState();
}

class _RecordCardState extends State<RecordCard> {
  bool _pressed = false;

  void _setPressed(bool v) => setState(() => _pressed = v);

  @override
  Widget build(BuildContext context) {
    final record = widget.record;
    final color = widget.color;
    final brightness = Theme.of(context).brightness;

    final header = Column(children: [
      Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: context.isDark ? .16 : .08),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadii.lg)),
        ),
        child: Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title,
                  style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: color)),
              if (widget.subtitle != null && widget.subtitle!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 3),
                  child: Text(widget.subtitle!,
                      style: TextStyle(fontSize: 11.5, color: context.textSecondary)),
                ),
            ]),
          ),
          if (record.invNum.isNotEmpty) Pill.blue(record.invNum),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
        child: Column(children: widget.rows),
      ),
    ]);

    final actionsRow = Row(children: [
      Expanded(
        child: TextButton.icon(
          onPressed: () => showInvoiceSheet(context, record),
          icon: const Icon(Icons.receipt_long_rounded, size: 17),
          label: const Text('فاکتور', style: TextStyle(fontSize: 12.5)),
        ),
      ),
      SizedBox(height: 22, child: VerticalDivider(width: 1, thickness: 1, color: context.borderColor)),
      Expanded(
        child: TextButton.icon(
          onPressed: widget.onEdit,
          icon: const Icon(Icons.edit_rounded, size: 17),
          label: const Text('ویرایش', style: TextStyle(fontSize: 12.5)),
        ),
      ),
      SizedBox(height: 22, child: VerticalDivider(width: 1, thickness: 1, color: context.borderColor)),
      Expanded(
        child: TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: AppColors.red),
          onPressed: () async {
            final ok = await confirmDialog(
              context,
              title: 'حذف رکورد',
              message: 'این رکورد برای همیشه حذف می‌شود. مطمئن هستید؟',
              okText: 'حذف',
              danger: true,
            );
            if (!ok || record.id == null) return;
            await widget.onBeforeDelete?.call();
            await AppDb.instance.delete(record.table, record.id!);
            notifyDataChanged();
            if (context.mounted) toast(context, 'رکورد حذف شد');
          },
          icon: const Icon(Icons.delete_outline_rounded, size: 17),
          label: const Text('حذف', style: TextStyle(fontSize: 12.5)),
        ),
      ),
    ]);

    return AnimatedContainer(
      duration: AppMotion.fast,
      curve: AppMotion.press,
      transform: Matrix4.identity()..translate(0.0, _pressed ? 1.0 : 0.0),
      decoration: BoxDecoration(
        color: context.cardBg,
        borderRadius: BorderRadius.circular(AppRadii.lg),
        border: Border.all(color: context.borderColor),
        boxShadow: _pressed ? AppShadows.soft(brightness) : AppShadows.lifted(brightness),
      ),
      child: Column(children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => _setPressed(true),
          onTapUp: (_) => _setPressed(false),
          onTapCancel: () => _setPressed(false),
          onTap: widget.onEdit,
          child: header,
        ),
        Divider(height: 1, color: context.borderColor),
        actionsRow,
      ]),
    );
  }
}

/// پنجره پایینی فرم ثبت/ویرایش — با هندل کشیدنی و ورود نرم
Future<bool> openFormSheet({
  required BuildContext context,
  required String title,
  required IconData icon,
  required Color color,
  required Widget Function(BuildContext context, void Function() refresh) body,
  required Future<String?> Function() onSave,
}) async {
  final bg = Theme.of(context).scaffoldBackgroundColor;
  bool saving = false;

  final result = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: .5),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSheetState) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: DraggableScrollableSheet(
          initialChildSize: .92,
          minChildSize: .5,
          maxChildSize: .95,
          expand: false,
          builder: (ctx, controller) => Container(
            decoration: BoxDecoration(
              color: bg,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadii.xl)),
            ),
            child: Column(children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 10, bottom: 2),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .35),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              Container(
                margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withValues(alpha: .78)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.circular(AppRadii.md),
                ),
                child: Row(children: [
                  Icon(icon, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(title,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: Colors.white),
                    onPressed: () => Navigator.pop(ctx, false),
                  ),
                ]),
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: controller,
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                  child: body(ctx, () => setSheetState(() {})),
                ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white),
                      onPressed: saving
                          ? null
                          : () async {
                              setSheetState(() => saving = true);
                              final error = await onSave();
                              setSheetState(() => saving = false);
                              if (error != null) {
                                if (ctx.mounted) toast(ctx, error, error: true);
                                return;
                              }
                              notifyDataChanged();
                              if (ctx.mounted) Navigator.pop(ctx, true);
                            },
                      icon: saving
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.save_rounded, size: 18),
                      label: Text(saving ? 'در حال ذخیره…' : 'ذخیره'),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    ),
  );
  return result ?? false;
}
