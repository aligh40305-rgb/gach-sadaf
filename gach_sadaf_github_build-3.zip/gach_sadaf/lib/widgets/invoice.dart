import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../services/invoice_pdf_service.dart';
import '../services/settings_service.dart';

/// داده‌های یک فاکتور — هم برای تصویر فاکتور و هم برای چاپ PDF استفاده می‌شود
InvoiceSpec invoiceSpecFor(Rec record) => InvoiceCard(record: record).spec;

/// فاکتور قابل ارسال در واتساپ/تلگرام — به شکل تصویر PNG
class InvoiceCard extends StatelessWidget {
  final Rec record;
  const InvoiceCard({super.key, required this.record});

  InvoiceSpec get spec {
    final r = record;
    if (r is Sale) {
      return InvoiceSpec(
        title: 'فاکتور فروش',
        icon: Icons.receipt_long,
        color: AppColors.green,
        sections: [
          InvoiceSec('مشخصات خریدار', [
            InvoiceRow('اسم خریدار', r.buyer, big: true),
            if (r.customerId != null) InvoiceRow('کد مشتری', toPersianDigits(r.customerId)),
            if (r.phone.isNotEmpty) InvoiceRow('موبایل', toPersianDigits(r.phone)),
            if (r.location.isNotEmpty) InvoiceRow('موقعیت', r.location),
          ]),
          if (r.orderType.isNotEmpty || r.truck.isNotEmpty)
            InvoiceSec('توضیحات', [
              if (r.orderType.isNotEmpty) InvoiceRow('توضیح', r.orderType),
              if (r.truck.isNotEmpty) InvoiceRow('موتر تحویل', r.truck),
            ]),
        ],
        lines: [
          for (final it in r.displayItems)
            InvoiceLine(
              title: it.type.isEmpty ? 'بدون نوعیت' : it.type,
              detail: it.weight > 0 ? '${fmtNum(it.weight)} کیلویی' : '',
              qty: fmtNum(it.qty),
              unit: fmtNum(it.price),
              amount: fmtNum(it.lineTotal),
            ),
        ],
        subtotal: (r.discount > 0 || r.displayItems.length > 1)
            ? fmtMoney(r.subtotal, r.cur)
            : null,
        discount: r.discount > 0 ? fmtMoney(r.discount, r.cur) : null,
        totalLabel: 'مجموع قابل پرداخت',
        totalValue: fmtMoney(r.total, r.cur),
        paid: r.paid,
        remaining: r.remaining,
        cur: r.cur,
        date: r.date,
        time: r.time,
      );
    }
    if (r is Stone) {
      return InvoiceSpec(
        title: 'فاکتور خرید سنگ',
        icon: Icons.landscape,
        color: AppColors.purple,
        sections: [
          InvoiceSec('مشخصات فروشنده', [
            InvoiceRow('اسم صاحب سنگ', r.seller, big: true),
            if (r.type.isNotEmpty) InvoiceRow('نوعیت سنگ', r.type),
          ]),
          InvoiceSec('جزئیات خرید', [
            InvoiceRow('وزن', '${fmtNum(r.weight)} تن', big: true),
            InvoiceRow('قیمت فی تن', fmtMoney(r.pricePerTon, r.cur)),
            InvoiceRow('تاریخ خرید', showDate(r.date)),
          ]),
          if (r.driver.isNotEmpty)
            InvoiceSec('مشخصات راننده', [
              InvoiceRow('اسم راننده', r.driver, big: true),
              InvoiceRow('کرایه کل', fmtMoney(r.driverTotal, r.driverCur)),
              InvoiceRow('پرداخت به راننده', fmtMoney(r.driverPaid, r.driverCur)),
              InvoiceRow('باقی راننده', fmtMoney(r.driverRem, r.driverCur)),
            ]),
        ],
        totalLabel: 'قیمت کل سنگ',
        totalValue: fmtMoney(r.total, r.cur),
        paid: r.paid,
        remaining: r.remaining,
        cur: r.cur,
        date: r.date,
        time: '',
      );
    }
    if (r is Worker) {
      return InvoiceSpec(
        title: 'فاکتور معاش',
        icon: Icons.engineering,
        color: AppColors.navySoft,
        sections: [
          InvoiceSec('مشخصات کارگر', [
            InvoiceRow('اسم کارگر', r.name, big: true),
            InvoiceRow('شیفت کاری', r.shift),
            InvoiceRow('تاریخ شروع', showDate(r.startDate)),
            if (r.endDate.isNotEmpty) InvoiceRow('تاریخ ختم', showDate(r.endDate)),
          ]),
          InvoiceSec('محاسبه معاش', [
            InvoiceRow('خلته تولید شده', '${fmtNum(r.gunny)} خلته'),
            if (r.extraGunny > 0) InvoiceRow('خلته اضافی', '${fmtNum(r.extraGunny)} خلته'),
            InvoiceRow('مجموع خلته', '${fmtNum(r.gunny + r.extraGunny)} خلته', big: true),
            InvoiceRow('فی خلته', fmtMoney(r.rate, r.cur)),
          ]),
        ],
        totalLabel: 'معاش کل',
        totalValue: fmtMoney(r.total, r.cur),
        paid: r.paid,
        remaining: r.remaining,
        cur: r.cur,
        date: r.paidDate,
        time: r.paidTime,
      );
    }
    if (r is Expense) {
      return InvoiceSpec(
        title: 'فاکتور مصرف',
        icon: Icons.shopping_bag,
        color: AppColors.red,
        sections: [
          InvoiceSec('مشخصات مصرف', [
            InvoiceRow('اسم جنس', r.item, big: true),
            InvoiceRow('تاریخ', showDate(r.date)),
            if (r.time.isNotEmpty) InvoiceRow('ساعت', showTime(r.time)),
          ]),
        ],
        totalLabel: 'قیمت کل',
        totalValue: fmtMoney(r.price, r.cur),
        paid: r.paid,
        remaining: r.remaining,
        cur: r.cur,
        date: r.date,
        time: r.time,
      );
    }
    final pr = r as Production;
    return InvoiceSpec(
      title: 'رسید تولید',
      icon: Icons.factory,
      color: AppColors.amber,
      sections: [
        InvoiceSec('جزئیات تولید', [
          InvoiceRow('تاریخ تولید', showDate(pr.date), big: true),
          if (pr.type.isNotEmpty) InvoiceRow('نوعیت گچ', pr.type),
          InvoiceRow('تعداد خلته', '${fmtNum(pr.gunny)} خلته', big: true),
          InvoiceRow('وزن هر خلته', '${fmtNum(pr.bagWeight)} کیلو'),
        ]),
      ],
      totalLabel: 'مجموع وزن تولید',
      totalValue: '${fmtNum(pr.totalWeight)} کیلو',
      paid: null,
      remaining: null,
      cur: kAfghani,
      date: pr.date,
      time: '',
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = spec;
    final st = Settings.instance;

    return Container(
      width: 380,
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // سربرگ
          Container(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.navyDark, s.color],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
            ),
            child: Column(children: [
              Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.asset('assets/images/crest.png',
                      width: 52, height: 52, fit: BoxFit.cover),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('کارخانه گچ صدف',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 3),
                      Text('${st.owner}  •  ${toPersianDigits(st.phone)}',
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 11)),
                      Text(st.address,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 11)),
                    ],
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .18),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(s.icon, size: 14, color: Colors.white),
                    const SizedBox(width: 5),
                    Text(s.title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800)),
                  ]),
                ),
                const Spacer(),
                Text('شماره: ${showText(record.invNum)}',
                    style: const TextStyle(
                        color: AppColors.goldLight,
                        fontSize: 12,
                        fontWeight: FontWeight.w800)),
              ]),
            ]),
          ),

          // بدنه
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Column(children: [
              for (final sec in s.sections) ...[
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.sky.withValues(alpha: .45),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(sec.title,
                        style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppColors.navy)),
                  ),
                ),
                for (final row in sec.rows)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(children: [
                      Text(row.label,
                          style: const TextStyle(
                              fontSize: 12, color: AppColors.textMid)),
                      const Spacer(),
                      Text(row.value,
                          style: TextStyle(
                            fontSize: row.big ? 14.5 : 12.5,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textDark,
                          )),
                    ]),
                  ),
                const SizedBox(height: 10),
              ],

              if (s.lines.isNotEmpty) ...[
                _LinesTable(lines: s.lines, color: s.color),
                const SizedBox(height: 10),
                if (s.subtotal != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(children: [
                      const Text('جمع اقلام',
                          style: TextStyle(fontSize: 12, color: AppColors.textMid)),
                      const Spacer(),
                      Text(s.subtotal!,
                          style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textDark)),
                    ]),
                  ),
                if (s.discount != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(children: [
                      const Text('تخفیف',
                          style: TextStyle(fontSize: 12, color: AppColors.textMid)),
                      const Spacer(),
                      Text('- ${s.discount!}',
                          style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: AppColors.redText)),
                    ]),
                  ),
                const SizedBox(height: 6),
              ],

              // مجموع
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: s.color,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(children: [
                  Text(s.totalLabel,
                      style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text(s.totalValue,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w800)),
                ]),
              ),

              if (s.paid != null) ...[
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: _StatusBox(
                      label: 'پرداخت شده',
                      value: fmtMoney(s.paid, s.cur),
                      color: AppColors.greenText,
                      bg: AppColors.greenBg,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatusBox(
                      label: 'باقی مانده',
                      value: fmtMoney(s.remaining, s.cur),
                      color: (s.remaining ?? 0) > 0
                          ? AppColors.redText
                          : AppColors.greenText,
                      bg: (s.remaining ?? 0) > 0
                          ? AppColors.redBg
                          : AppColors.greenBg,
                    ),
                  ),
                ]),
              ],
            ]),
          ),

          // پاورقی
          Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
            decoration: const BoxDecoration(
              color: Color(0xFFF7F5F0),
              border: Border(top: BorderSide(color: Color(0x14000000))),
            ),
            child: Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('گچ صدف',
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppColors.navy)),
                    Text(
                      '${showDate(s.date)}${s.time.isNotEmpty ? '  •  ${showTime(s.time)}' : ''}',
                      style: const TextStyle(
                          fontSize: 11, color: AppColors.textMid),
                    ),
                    const Text('سازنده: انجنیر علی محمد غلامی',
                        style: TextStyle(
                            fontSize: 9.5, color: AppColors.textLight)),
                  ],
                ),
              ),
              Icon(s.icon, size: 26, color: AppColors.textLight),
            ]),
          ),
        ],
      ),
    );
  }
}

/// جدول اقلام فاکتور: ردیف | شرح | تعداد | قیمت واحد | مبلغ
class _LinesTable extends StatelessWidget {
  final List<InvoiceLine> lines;
  final Color color;
  const _LinesTable({required this.lines, required this.color});

  @override
  Widget build(BuildContext context) {
    Widget cell(String t,
            {int flex = 1,
            bool bold = false,
            Color? c,
            TextAlign align = TextAlign.center,
            double size = 11.5}) =>
        Expanded(
          flex: flex,
          child: Text(t,
              textAlign: align,
              style: TextStyle(
                  fontSize: size,
                  fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
                  color: c ?? AppColors.textDark)),
        );

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0x22000000)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: BoxDecoration(
            color: color,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(9)),
          ),
          child: Row(children: [
            cell('#', c: Colors.white, bold: true, size: 10.5),
            cell('شرح', flex: 4, c: Colors.white, bold: true, size: 10.5),
            cell('تعداد', flex: 2, c: Colors.white, bold: true, size: 10.5),
            cell('قیمت واحد', flex: 3, c: Colors.white, bold: true, size: 10.5),
            cell('مبلغ', flex: 3, c: Colors.white, bold: true, size: 10.5),
          ]),
        ),
        for (var i = 0; i < lines.length; i++)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(
              color: i.isOdd ? const Color(0x0A000000) : null,
              border: i == lines.length - 1
                  ? null
                  : const Border(bottom: BorderSide(color: Color(0x14000000))),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              cell(toPersianDigits(i + 1), size: 10.5),
              Expanded(
                flex: 4,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(lines[i].title,
                      style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textDark)),
                  if (lines[i].detail.isNotEmpty)
                    Text(lines[i].detail,
                        style: const TextStyle(fontSize: 10, color: AppColors.textMid)),
                ]),
              ),
              cell(lines[i].qty, flex: 2),
              cell(lines[i].unit, flex: 3),
              cell(lines[i].amount, flex: 3, bold: true),
            ]),
          ),
      ]),
    );
  }
}

class _StatusBox extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final Color bg;
  const _StatusBox({
    required this.label,
    required this.value,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
      child: Column(children: [
        Text(label,
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color)),
        const SizedBox(height: 3),
        Text(value,
            style:
                TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: color)),
      ]),
    );
  }
}

class InvoiceSpec {
  final String title;
  final IconData icon;
  final Color color;
  final List<InvoiceSec> sections;
  final String totalLabel;
  final String totalValue;
  final double? paid;
  final double? remaining;
  final String cur;
  final String date;
  final String time;

  /// جدول اقلام فاکتور (فقط فاکتور فروش)
  final List<InvoiceLine> lines;
  final String? subtotal;
  final String? discount;

  InvoiceSpec({
    required this.title,
    required this.icon,
    required this.color,
    required this.sections,
    required this.totalLabel,
    required this.totalValue,
    required this.paid,
    required this.remaining,
    required this.cur,
    required this.date,
    required this.time,
    this.lines = const [],
    this.subtotal,
    this.discount,
  });
}

/// یک ردیف از جدول اقلام فاکتور
class InvoiceLine {
  final String title;
  final String detail;
  final String qty;
  final String unit;
  final String amount;
  const InvoiceLine({
    required this.title,
    required this.detail,
    required this.qty,
    required this.unit,
    required this.amount,
  });
}

class InvoiceSec {
  final String title;
  final List<InvoiceRow> rows;
  InvoiceSec(this.title, this.rows);
}

class InvoiceRow {
  final String label;
  final String value;
  final bool big;
  InvoiceRow(this.label, this.value, {this.big = false});
}

// ───────────────── نمایش و ارسال فاکتور ─────────────────

Future<void> showInvoiceSheet(BuildContext context, Rec record) async {
  final captureKey = GlobalKey();

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => DraggableScrollableSheet(
      initialChildSize: .9,
      minChildSize: .5,
      maxChildSize: .95,
      builder: (ctx, controller) => Container(
        decoration: const BoxDecoration(
          color: AppColors.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(children: [
          Container(
            width: 44,
            height: 4,
            margin: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
                color: AppColors.textLight,
                borderRadius: BorderRadius.circular(4)),
          ),
          Expanded(
            child: SingleChildScrollView(
              controller: controller,
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Center(
                child: RepaintBoundary(
                  key: captureKey,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: InvoiceCard(record: record),
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.navy,
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14)),
                    onPressed: () async {
                      final messenger = ScaffoldMessenger.of(ctx);
                      try {
                        await InvoicePdfService.instance.printInvoice(record);
                      } catch (e) {
                        messenger.showSnackBar(SnackBar(
                            content: Text('چاپ ناموفق بود: $e'),
                            backgroundColor: AppColors.red));
                      }
                    },
                    icon: const Icon(Icons.print_rounded, size: 18),
                    label: const Text('چاپ فاکتور'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.green,
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14)),
                    onPressed: () async {
                      final messenger = ScaffoldMessenger.of(ctx);
                      try {
                        await shareInvoiceImage(captureKey, record);
                      } catch (e) {
                        messenger.showSnackBar(SnackBar(
                            content: Text('ارسال ناموفق بود: $e'),
                            backgroundColor: AppColors.red));
                      }
                    },
                    icon: const Icon(Icons.share_rounded, size: 18),
                    label: const Text('ارسال'),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('بستن'),
                ),
              ]),
            ),
          ),
        ]),
      ),
    ),
  );
}

/// گرفتن عکس از فاکتور و باز کردن پنجره اشتراک‌گذاری گوشی
Future<void> shareInvoiceImage(GlobalKey key, Rec record) async {
  final boundary =
      key.currentContext!.findRenderObject() as RenderRepaintBoundary;
  final image = await boundary.toImage(pixelRatio: 3);
  final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
  final bytes = byteData!.buffer.asUint8List();

  final dir = await getTemporaryDirectory();
  final name = 'فاکتور-${record.invNum.isEmpty ? Jalali.today().storage.replaceAll('/', '-') : record.invNum}.png';
  final file = File(p.join(dir.path, name));
  await file.writeAsBytes(bytes, flush: true);

  await Share.shareXFiles(
    [XFile(file.path, mimeType: 'image/png')],
    text: 'فاکتور کارخانه گچ صدف — ${Jalali.today().display}',
  );
}
