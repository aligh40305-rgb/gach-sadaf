import 'package:flutter/material.dart';

import '../core/events.dart';
import '../core/format.dart';
import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../services/inventory_service.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';

class InventoryPage extends StatelessWidget {
  const InventoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DataBuilder<List<StockItem>>(
      load: InventoryService.instance.all,
      loading: const SkeletonList(count: 3),
      builder: (context, items) {
        final total = items.fold<double>(0, (s, i) => s + i.qty);
        final totalKg = items.fold<double>(0, (s, i) => s + i.totalKg);
        final threshold = Settings.instance.lowStockThreshold;
        final byType = <String, List<StockItem>>{};
        for (final it in items) {
          byType.putIfAbsent(it.type, () => []).add(it);
        }
        final types = byType.keys.toList();
        final lowCount = items.where((i) => i.qty < threshold).length;

        return ListView(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 30),
          children: [
            FadeSlideIn(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: AppColors.navyGradient,
                  borderRadius: BorderRadius.circular(AppRadii.xl),
                  boxShadow: AppShadows.lifted(Theme.of(context).brightness),
                ),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('مجموع موجودی انبار',
                          style: TextStyle(color: Colors.white70, fontSize: 12.5, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      Text('${fmtNum(total)} خلته',
                          style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text('وزن کل: ${fmtNum(totalKg)} کیلو',
                          style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      if (lowCount > 0) ...[
                        const SizedBox(height: 8),
                        Pill(
                          '${toPersianDigits(lowCount)} ردیف رو به اتمام',
                          bg: Colors.white.withValues(alpha: .16),
                          fg: AppColors.goldLight,
                          icon: Icons.warning_amber_rounded,
                        ),
                      ],
                    ]),
                  ),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .12),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.warehouse_rounded, color: Colors.white, size: 30),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 14),

            if (items.isEmpty)
              const SectionCard(
                child: EmptyState(
                  'هنوز موجودی‌ای ثبت نشده — با اولین ثبت تولید، انبار خودکار پر می‌شود',
                  icon: Icons.warehouse_outlined,
                ),
              )
            else
              ...List.generate(types.length, (i) {
                final type = types[i];
                final rows = byType[type]!;
                final typeTotal = rows.fold<double>(0, (s, r) => s + r.qty);
                final typeKg = rows.fold<double>(0, (s, r) => s + r.totalKg);

                return FadeSlideIn(
                  delay: Duration(milliseconds: 40 * i),
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      decoration: BoxDecoration(
                        color: context.cardBg,
                        borderRadius: BorderRadius.circular(AppRadii.lg),
                        border: Border.all(color: context.borderColor),
                        boxShadow: AppShadows.soft(Theme.of(context).brightness),
                      ),
                      child: Column(children: [
                        Container(
                          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                          decoration: BoxDecoration(
                            color: AppColors.navySoft.withValues(alpha: context.isDark ? .22 : .08),
                            borderRadius:
                                const BorderRadius.vertical(top: Radius.circular(AppRadii.lg)),
                          ),
                          child: Row(children: [
                            const Icon(Icons.inventory_2_rounded, size: 19, color: AppColors.navySoft),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(type,
                                  style: TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w800,
                                      color: context.textPrimary)),
                            ),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text('${fmtNum(typeTotal)} خلته',
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      color: context.textPrimary)),
                              Text('${fmtNum(typeKg)} کیلو',
                                  style: TextStyle(fontSize: 10.5, color: context.textSecondary)),
                            ]),
                          ]),
                        ),
                        for (var k = 0; k < rows.length; k++) ...[
                          if (k > 0) Divider(height: 1, color: context.borderColor),
                          _WeightRow(item: rows[k], threshold: threshold),
                        ],
                      ]),
                    ),
                  ),
                );
              }),

            const SizedBox(height: 8),
            SectionCard(
              title: 'نگهداری انبار',
              icon: Icons.build_outlined,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  'موجودی به‌صورت خودکار با ثبت تولید (افزایش) و ثبت فروش (کاهش) به‌روز می‌شود. '
                  'اگر روزی موجودی با واقعیت انبار همخوانی نداشت، می‌توانید آن را از روی تمام رکوردهای '
                  'تولید و فروش دوباره محاسبه کنید.',
                  style: TextStyle(fontSize: 12, height: 1.9, color: context.textSecondary),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    final ok = await confirmDialog(
                      context,
                      title: 'بازسازی موجودی انبار',
                      message:
                          'موجودی فعلی پاک و از روی تمام رکوردهای تولید و فروش دوباره محاسبه می‌شود. ادامه می‌دهید؟',
                      okText: 'بازسازی',
                    );
                    if (!ok) return;
                    await InventoryService.instance.recompute();
                    notifyDataChanged();
                    if (context.mounted) toast(context, 'موجودی انبار بازسازی شد');
                  },
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text('بازسازی موجودی از رکوردها'),
                ),
              ]),
            ),
          ],
        );
      },
    );
  }
}

/// یک ردیف وزن: «۲۰ کیلویی — ۱۵۰ خلته» با رنگ وضعیت
class _WeightRow extends StatelessWidget {
  final StockItem item;
  final int threshold;
  const _WeightRow({required this.item, required this.threshold});

  @override
  Widget build(BuildContext context) {
    final empty = item.qty <= 0;
    final low = item.qty < threshold;
    final color = empty ? AppColors.red : (low ? AppColors.amber : AppColors.green);
    final status = empty ? 'تمام شده' : (low ? 'رو به اتمام' : 'کافی');

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: context.cardBgAlt,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            item.weight > 0 ? '${fmtNum(item.weight)} کیلویی' : 'بدون وزن',
            style: TextStyle(
                fontSize: 12.5, fontWeight: FontWeight.w800, color: context.textPrimary),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(status,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color)),
        ),
        Text(fmtNum(item.qty),
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
        const SizedBox(width: 4),
        Text('خلته', style: TextStyle(fontSize: 11.5, color: context.textSecondary)),
        if (item.weight > 0) ...[
          const SizedBox(width: 8),
          Text('(${fmtNum(item.totalKg)} کیلو)',
              style: TextStyle(fontSize: 10.5, color: context.textMuted)),
        ],
      ]),
    );
  }
}
