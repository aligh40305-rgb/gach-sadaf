import 'package:flutter/material.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';
import '../widgets/entity_scaffold.dart';

class ExpensesPage extends StatelessWidget {
  const ExpensesPage({super.key});

  static const Color _color = AppColors.red;

  Future<List<Expense>> _load() async =>
      (await AppDb.instance.rows(T.expenses)).map(Expense.fromMap).toList();

  @override
  Widget build(BuildContext context) {
    return EntityScaffold<Expense>(
      table: T.expenses,
      color: _color,
      addLabel: 'ثبت مصرف',
      searchHint: 'جستجو با اسم جنس یا تاریخ…',
      emptyText: 'هنوز مصرفی ثبت نشده است',
      load: _load,
      match: (r, q) => [r.item, r.invNum, r.date]
          .any((f) => f.toLowerCase().contains(q.toLowerCase())),
      openForm: (ctx, rec) => _openExpenseForm(ctx, rec),
      card: (context, e) => RecordCard(
        record: e,
        color: _color,
        title: e.item,
        subtitle: '${showDate(e.date)}  •  ${showTime(e.time)}',
        onEdit: () => _openExpenseForm(context, e),
        rows: [
          KeyValueRow('قیمت کل', fmtMoney(e.price, e.cur), big: true),
          Row(children: [
            Pill.green('پرداخت: ${fmtMoney(e.paid, e.cur)}'),
            const SizedBox(width: 8),
            if (e.remaining > 0)
              Pill.red('باقی: ${fmtMoney(e.remaining, e.cur)}')
            else
              Pill.green('تصفیه شده'),
          ]),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

Future<bool> _openExpenseForm(BuildContext context, Expense? existing) async {
  final e = existing ??
      Expense(
        cur: Settings.instance.defaultCurrency,
        date: Jalali.today().storage,
        time: nowTimeStorage(),
      );

  final item = TextEditingController(text: e.item);
  final price = TextEditingController(text: e.price == 0 ? '' : plainNum(e.price));
  final paid = TextEditingController(text: e.paid == 0 ? '' : plainNum(e.paid));

  return openFormSheet(
    context: context,
    title: existing == null ? 'ثبت مصرف جدید' : 'ویرایش مصرف',
    icon: Icons.receipt_long,
    color: AppColors.red,
    body: (ctx, refresh) => FieldGrid(children: [
      AppField(controller: item, label: 'اسم جنس *', hint: 'مثلا: روغن ماشین'),
      AppField(
          controller: price,
          label: 'قیمت کل',
          number: true,
          onChanged: (_) => refresh()),
      AppDropdown(
        label: 'واحد پول',
        value: e.cur,
        items: kCurrencies,
        onChanged: (v) {
          e.cur = v ?? kAfghani;
          refresh();
        },
      ),
      AppField(
          controller: paid,
          label: 'پول پرداخت شده',
          number: true,
          onChanged: (_) => refresh()),
      AppField(
        controller: TextEditingController(
            text: fmtMoney(toDouble(price.text) - toDouble(paid.text), e.cur)),
        label: 'باقی پول (خودکار)',
        readOnly: true,
        fill: AppColors.redBg,
        textColor: AppColors.redText,
      ),
      JalaliField(
          label: 'تاریخ',
          value: e.date,
          onChanged: (v) {
            e.date = v;
            refresh();
          }),
      TimeField(
          label: 'ساعت',
          value: e.time,
          onChanged: (v) {
            e.time = v;
            refresh();
          }),
    ]),
    onSave: () async {
      if (item.text.trim().isEmpty) return 'اسم جنس ضروری است';
      e
        ..item = item.text.trim()
        ..price = toDouble(price.text)
        ..paid = toDouble(paid.text)
        ..recalc();

      if (e.id == null) {
        e.invNum = await AppDb.instance.nextInvoiceNumber(T.expenses);
        await AppDb.instance.insert(T.expenses, e.toMap());
      } else {
        await AppDb.instance.update(T.expenses, e.id!, e.toMap());
      }
      return null;
    },
  );
}
