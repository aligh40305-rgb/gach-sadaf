import 'package:flutter/material.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';
import '../widgets/entity_scaffold.dart';

class WorkersPage extends StatelessWidget {
  const WorkersPage({super.key});

  static const Color _color = AppColors.amber;

  Future<List<Worker>> _load() async =>
      (await AppDb.instance.rows(T.workers)).map(Worker.fromMap).toList();

  @override
  Widget build(BuildContext context) {
    return EntityScaffold<Worker>(
      table: T.workers,
      color: _color,
      addLabel: 'ثبت کارگر',
      searchHint: 'جستجو با اسم، شماره فاکتور یا تاریخ…',
      emptyText: 'هنوز کارگری ثبت نشده است',
      load: _load,
      match: (r, q) => [r.name, r.invNum, r.startDate, r.endDate, r.paidDate, r.shift]
          .any((f) => f.toLowerCase().contains(q.toLowerCase())),
      openForm: (ctx, rec) => _openWorkerForm(ctx, rec),
      card: (context, w) => RecordCard(
        record: w,
        color: _color,
        title: w.name,
        subtitle: 'شیفت ${w.shift}  •  ${showDate(w.startDate)}',
        onEdit: () => _openWorkerForm(context, w),
        rows: [
          KeyValueRow('تعداد خلته تولید شده',
              '${fmtNum(w.gunny)} خلته${w.extraGunny > 0 ? ' + ${fmtNum(w.extraGunny)} اضافه' : ''}'),
          KeyValueRow('فی خلته', fmtMoney(w.rate, w.cur)),
          KeyValueRow('معاش کل', fmtMoney(w.total, w.cur), big: true),
          Row(children: [
            Pill.green('پرداخت: ${fmtMoney(w.paid, w.cur)}'),
            const SizedBox(width: 8),
            if (w.remaining > 0)
              Pill.red('باقی: ${fmtMoney(w.remaining, w.cur)}')
            else
              Pill.green('تصفیه شده'),
          ]),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

Future<bool> _openWorkerForm(BuildContext context, Worker? existing) async {
  final w = existing ??
      Worker(
        shift: 'روز',
        cur: Settings.instance.defaultCurrency,
        startDate: Jalali.today().storage,
        paidDate: Jalali.today().storage,
        paidTime: nowTimeStorage(),
      );

  final name = TextEditingController(text: w.name);
  final gunny = TextEditingController(text: w.gunny == 0 ? '' : plainNum(w.gunny));
  final extraGunny =
      TextEditingController(text: w.extraGunny == 0 ? '' : plainNum(w.extraGunny));
  final rate = TextEditingController(text: w.rate == 0 ? '' : plainNum(w.rate));
  final paid = TextEditingController(text: w.paid == 0 ? '' : plainNum(w.paid));

  double total() =>
      (toDouble(gunny.text) + toDouble(extraGunny.text)) * toDouble(rate.text);

  return openFormSheet(
    context: context,
    title: existing == null ? 'ثبت کارگر جدید' : 'ویرایش کارگر',
    icon: Icons.engineering,
    color: AppColors.amber,
    body: (ctx, refresh) => FieldGrid(children: [
      AppField(controller: name, label: 'اسم کارگر *', hint: 'اسم کامل'),
      AppDropdown(
        label: 'شیفت کاری',
        value: w.shift,
        items: const ['روز', 'شب', 'روز و شب'],
        onChanged: (v) {
          w.shift = v ?? 'روز';
          refresh();
        },
      ),
      JalaliField(
        label: 'تاریخ شروع',
        value: w.startDate,
        onChanged: (v) {
          w.startDate = v;
          refresh();
        },
      ),
      JalaliField(
        label: 'تاریخ ختم',
        value: w.endDate,
        onChanged: (v) {
          w.endDate = v;
          refresh();
        },
      ),
      AppField(
          controller: gunny,
          label: 'تعداد خلته تولید شده',
          number: true,
          onChanged: (_) => refresh()),
      AppField(
          controller: extraGunny,
          label: 'خلته اضافی (اضافه‌کاری)',
          number: true,
          onChanged: (_) => refresh()),
      AppField(
          controller: rate,
          label: 'پول فی خلته',
          number: true,
          onChanged: (_) => refresh()),
      AppDropdown(
        label: 'واحد پول',
        value: w.cur,
        items: kCurrencies,
        onChanged: (v) {
          w.cur = v ?? kAfghani;
          refresh();
        },
      ),
      AppField(
        controller: TextEditingController(text: fmtMoney(total(), w.cur)),
        label: 'معاش کل (خودکار)',
        readOnly: true,
        fill: AppColors.greenBg,
        textColor: AppColors.greenText,
      ),
      AppField(
          controller: paid,
          label: 'پول پرداخت شده',
          number: true,
          onChanged: (_) => refresh()),
      AppField(
        controller: TextEditingController(
            text: fmtMoney(total() - toDouble(paid.text), w.cur)),
        label: 'باقی پول (خودکار)',
        readOnly: true,
        fill: AppColors.redBg,
        textColor: AppColors.redText,
      ),
      JalaliField(
        label: 'تاریخ پرداخت',
        value: w.paidDate,
        onChanged: (v) {
          w.paidDate = v;
          refresh();
        },
      ),
      TimeField(
        label: 'ساعت پرداخت',
        value: w.paidTime,
        onChanged: (v) {
          w.paidTime = v;
          refresh();
        },
      ),
    ]),
    onSave: () async {
      if (name.text.trim().isEmpty) return 'اسم کارگر ضروری است';
      if (toDouble(gunny.text) < 0 || toDouble(rate.text) < 0) {
        return 'مقدارها نمی‌توانند منفی باشند';
      }
      w
        ..name = name.text.trim()
        ..gunny = toDouble(gunny.text)
        ..extraGunny = toDouble(extraGunny.text)
        ..rate = toDouble(rate.text)
        ..paid = toDouble(paid.text)
        ..recalc();

      if (w.id == null) {
        w.invNum = await AppDb.instance.nextInvoiceNumber(T.workers);
        await AppDb.instance.insert(T.workers, w.toMap());
      } else {
        await AppDb.instance.update(T.workers, w.id!, w.toMap());
      }
      return null;
    },
  );
}
