import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../core/theme_mode.dart';
import '../services/auth_service.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';
import '../widgets/pin_pad.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _owner =
      TextEditingController(text: Settings.instance.owner);
  late final TextEditingController _phone =
      TextEditingController(text: Settings.instance.phone);
  late final TextEditingController _address =
      TextEditingController(text: Settings.instance.address);

  late final TextEditingController _lowStock =
      TextEditingController(text: toPersianDigits(Settings.instance.lowStockThreshold));

  bool _bioAvailable = false;

  @override
  void initState() {
    super.initState();
    Auth.instance.bioAvailable().then((v) {
      if (mounted) setState(() => _bioAvailable = v);
    });
  }

  @override
  void dispose() {
    _owner.dispose();
    _phone.dispose();
    _address.dispose();
    _lowStock.dispose();
    super.dispose();
  }

  void _saveInfo() {
    final s = Settings.instance;
    s.owner = _owner.text.trim().isEmpty ? 'رضا محمدی' : _owner.text.trim();
    s.phone = _phone.text.trim();
    s.address = _address.text.trim();
    setState(() {});
    toast(context, 'معلومات کارخانه ذخیره شد');
  }

  Future<void> _changePin() async {
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const SingleChildScrollView(child: _PinChangeSheet()),
    );
    if (ok == true && mounted) {
      setState(() {});
      toast(context, 'پین با موفقیت تغییر کرد');
    }
  }

  String _autoLockLabel(int m) {
    switch (m) {
      case 1:
        return 'بعد از ۱ دقیقه';
      case 5:
        return 'بعد از ۵ دقیقه';
      case 15:
        return 'بعد از ۱۵ دقیقه';
      default:
        return 'هیچ‌وقت';
    }
  }

  int _autoLockValue(String? label) {
    switch (label) {
      case 'بعد از ۱ دقیقه':
        return 1;
      case 'بعد از ۵ دقیقه':
        return 5;
      case 'بعد از ۱۵ دقیقه':
        return 15;
      default:
        return 0;
    }
  }

  Future<void> _resetPreferences() async {
    final ok = await confirmDialog(
      context,
      title: 'بازنشانی تنظیمات',
      message:
          'ظاهر برنامه، واحد پول پیش‌فرض، یادآوری بکاپ، قفل خودکار و حد هشدار انبار به حالت اول برمی‌گردد.\n'
          'رکوردها، اطلاعات کارخانه، پین و بکاپ‌ها دست‌نخورده می‌مانند.',
      okText: 'بازنشانی',
    );
    if (!ok) return;
    await Settings.instance.resetPreferences();
    setAppThemeMode(ThemeMode.system);
    _lowStock.text = toPersianDigits(Settings.instance.lowStockThreshold);
    if (mounted) {
      setState(() {});
      toast(context, 'تنظیمات به حالت پیش‌فرض برگشت');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Settings.instance;

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 30),
      children: [
        SectionCard(
          title: 'معلومات کارخانه',
          icon: Icons.factory,
          titleColor: AppColors.amber,
          child: Column(children: [
            AppField(controller: _owner, label: 'نام مسئول کارخانه'),
            const SizedBox(height: 10),
            AppField(
                controller: _phone,
                label: 'شماره تماس',
                number: true,
                keyboard: TextInputType.phone),
            const SizedBox(height: 10),
            AppField(controller: _address, label: 'آدرس کارخانه'),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _saveInfo,
                icon: const Icon(Icons.save, size: 18),
                label: const Text('ذخیره معلومات'),
              ),
            ),
            const SizedBox(height: 6),
            const Text('این معلومات در سربرگ فاکتورها و گزارش PDF چاپ می‌شود',
                style: TextStyle(fontSize: 11, color: AppColors.textLight)),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'واحد پول پیش‌فرض',
          icon: Icons.attach_money,
          titleColor: AppColors.blue,
          child: AppDropdown(
            label: 'واحد پول',
            value: s.defaultCurrency,
            items: kCurrencies,
            onChanged: (v) {
              setState(() => s.defaultCurrency = v ?? kAfghani);
              toast(context, 'واحد پول پیش‌فرض ذخیره شد');
            },
          ),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'ظاهر برنامه',
          icon: Icons.dark_mode_outlined,
          titleColor: AppColors.purple,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('روشن، تاریک یا هماهنگ با تنظیمات گوشی',
                style: TextStyle(fontSize: 12, color: AppColors.textMid)),
            const SizedBox(height: 12),
            ValueListenableBuilder<ThemeMode>(
              valueListenable: appThemeMode,
              builder: (context, mode, _) => SegmentedButton<ThemeMode>(
                segments: const [
                  ButtonSegment(
                      value: ThemeMode.light,
                      icon: Icon(Icons.light_mode_rounded, size: 16),
                      label: Text('روشن')),
                  ButtonSegment(
                      value: ThemeMode.system,
                      icon: Icon(Icons.smartphone_rounded, size: 16),
                      label: Text('خودکار')),
                  ButtonSegment(
                      value: ThemeMode.dark,
                      icon: Icon(Icons.dark_mode_rounded, size: 16),
                      label: Text('تاریک')),
                ],
                selected: {mode},
                showSelectedIcon: false,
                onSelectionChanged: (s) => setAppThemeMode(s.first),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'یادآوری بکاپ',
          icon: Icons.notifications_active,
          titleColor: AppColors.greenText,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'هر چند روز یک‌بار هنگام باز کردن برنامه، یادآوری بکاپ نشان داده شود',
              style: TextStyle(fontSize: 12, color: AppColors.textMid),
            ),
            const SizedBox(height: 10),
            AppDropdown(
              label: 'فاصله یادآوری',
              value: _reminderLabel(s.backupEveryDays),
              items: const ['بدون یادآوری', 'هر روز', 'هر ۳ روز', 'هفته‌وار'],
              onChanged: (v) {
                setState(() => s.backupEveryDays = _reminderValue(v));
                toast(context, 'تنظیم یادآوری ذخیره شد');
              },
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'امنیت و ورود',
          icon: Icons.lock_rounded,
          titleColor: AppColors.navy,
          child: Column(children: [
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.pin_outlined, size: 20),
              title: const Text('تغییر پین', style: TextStyle(fontSize: 13.5)),
              subtitle: Text(
                Auth.instance.isDefaultPassword
                    ? 'هنوز پین پیش‌فرض (۱۲۳۴) فعال است'
                    : 'پین شخصی فعال است',
                style: TextStyle(
                  fontSize: 11.5,
                  color: Auth.instance.isDefaultPassword
                      ? AppColors.red
                      : context.textSecondary,
                ),
              ),
              trailing: const Icon(Icons.chevron_left),
              onTap: _changePin,
            ),
            if (_bioAvailable)
              SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: Auth.instance.bioEnabled,
                secondary: const Icon(Icons.fingerprint, size: 22),
                title: const Text('ورود با اثر انگشت',
                    style: TextStyle(fontSize: 13.5)),
                subtitle: const Text('ورود سریع به‌جای تایپ پین',
                    style: TextStyle(fontSize: 11.5)),
                onChanged: (v) async {
                  if (v) {
                    final ok = await Auth.instance.authenticateBio();
                    if (!ok) return;
                  }
                  await Auth.instance.setBioEnabled(v);
                  if (mounted) setState(() {});
                },
              ),
            const SizedBox(height: 10),
            AppDropdown(
              label: 'قفل خودکار بعد از ترک برنامه',
              value: _autoLockLabel(Settings.instance.autoLockMinutes),
              items: const ['هیچ‌وقت', 'بعد از ۱ دقیقه', 'بعد از ۵ دقیقه', 'بعد از ۱۵ دقیقه'],
              onChanged: (v) {
                setState(() => Settings.instance.autoLockMinutes = _autoLockValue(v));
                toast(context, 'قفل خودکار ذخیره شد');
              },
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'انبار',
          icon: Icons.warehouse_rounded,
          titleColor: AppColors.navySoft,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('وقتی موجودی یک نوع گچ از این تعداد کمتر شد، در انبار و داشبورد هشدار می‌گیرید',
                style: TextStyle(fontSize: 12, height: 1.8, color: context.textSecondary)),
            const SizedBox(height: 10),
            AppField(
              controller: _lowStock,
              label: 'حد هشدار موجودی (خلته)',
              number: true,
              onChanged: (v) {
                final n = int.tryParse(toEnglishDigits(v));
                if (n != null && n >= 0) Settings.instance.lowStockThreshold = n;
              },
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'نگهداری',
          icon: Icons.build_rounded,
          titleColor: AppColors.amber,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('اگر تنظیمات به هم ریخت، آن‌ها را به حالت اول برگردانید. اطلاعات و رکوردها پاک نمی‌شود.',
                style: TextStyle(fontSize: 12, height: 1.8, color: context.textSecondary)),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _resetPreferences,
              icon: const Icon(Icons.restart_alt_rounded, size: 18),
              label: const Text('بازنشانی تنظیمات'),
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'درباره برنامه',
          icon: Icons.info_outline,
          titleColor: AppColors.purple,
          child: Column(children: const [
            KeyValueRow('نام سیستم', 'گچ صدف — مدیریت کارخانه'),
            KeyValueRow('نسخه', '۴.۰ (موبایل)'),
            KeyValueRow('پایگاه داده', 'SQLite محلی روی گوشی'),
            KeyValueRow('انترنت', 'نیاز ندارد — کاملاً آفلاین'),
            KeyValueRow('سازنده', 'انجنیر علی محمد غلامی'),
          ]),
        ),
      ],
    );
  }

  String _reminderLabel(int days) {
    switch (days) {
      case 1:
        return 'هر روز';
      case 3:
        return 'هر ۳ روز';
      case 7:
        return 'هفته‌وار';
      default:
        return 'بدون یادآوری';
    }
  }

  int _reminderValue(String? label) {
    switch (label) {
      case 'هر روز':
        return 1;
      case 'هر ۳ روز':
        return 3;
      case 'هفته‌وار':
        return 7;
      default:
        return 0;
    }
  }
}

/// تغییر پین در سه گام: پین فعلی ← پین جدید ← تکرار پین جدید
class _PinChangeSheet extends StatefulWidget {
  const _PinChangeSheet();

  @override
  State<_PinChangeSheet> createState() => _PinChangeSheetState();
}

class _PinChangeSheetState extends State<_PinChangeSheet> {
  static const _len = 4;
  int _step = 0; // ۰ فعلی، ۱ جدید، ۲ تکرار
  String _pin = '';
  String _newPin = '';
  String _error = '';
  int _shake = 0;

  String get _title => const [
        'پین فعلی را وارد کنید',
        'پین جدید (۴ رقم) را وارد کنید',
        'پین جدید را دوباره وارد کنید',
      ][_step];

  void _onDigit(String d) {
    if (_pin.length >= _len) return;
    setState(() {
      _pin += d;
      _error = '';
    });
    if (_pin.length == _len) {
      final v = _pin;
      Future.delayed(const Duration(milliseconds: 140), () {
        if (mounted) _next(v);
      });
    }
  }

  void _fail(String msg) {
    HapticFeedback.heavyImpact();
    setState(() {
      _pin = '';
      _error = msg;
      _shake++;
    });
  }

  Future<void> _next(String v) async {
    if (_step == 0) {
      if (!Auth.instance.checkPassword(v)) {
        _fail('پین فعلی اشتباه است');
        return;
      }
      setState(() {
        _step = 1;
        _pin = '';
      });
    } else if (_step == 1) {
      setState(() {
        _newPin = v;
        _step = 2;
        _pin = '';
      });
    } else {
      if (v != _newPin) {
        setState(() {
          _step = 1;
          _newPin = '';
        });
        _fail('دو پین یکسان نبودند — دوباره پین جدید را وارد کنید');
        return;
      }
      await Auth.instance.setPin(v);
      if (mounted) Navigator.pop(context, true);
    }
  }

  /// برای نسخه‌های قدیمی که رمز آن‌ها حروف دارد
  Future<void> _verifyTextPassword() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('رمز متنی فعلی'),
        content: TextField(
          controller: c,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'رمز فعلی'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, Auth.instance.checkPassword(c.text.trim())),
            child: const Text('تایید'),
          ),
        ],
      ),
    );
    c.dispose();
    if (!mounted) return;
    if (ok == true) {
      setState(() {
        _step = 1;
        _pin = '';
        _error = '';
      });
    } else {
      _fail('رمز فعلی اشتباه است');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(28, 14, 28, 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: context.borderColor,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(height: 16),
          Text('تغییر پین',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: context.textPrimary)),
          const SizedBox(height: 4),
          Text(_title, style: TextStyle(fontSize: 12.5, color: context.textSecondary)),
          const SizedBox(height: 20),
          Shake(
            trigger: _shake,
            child: PinDots(
              length: _len,
              filled: _pin.length,
              error: _error.isNotEmpty,
              onDark: false,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 34,
            child: Text(_error,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 12, color: AppColors.red, fontWeight: FontWeight.w700)),
          ),
          NumPad(
            onDark: false,
            onDigit: _onDigit,
            onBackspace: () {
              if (_pin.isNotEmpty) setState(() => _pin = _pin.substring(0, _pin.length - 1));
            },
          ),
          if (_step == 0)
            TextButton(
              onPressed: _verifyTextPassword,
              child: const Text('رمز فعلی من حروف دارد', style: TextStyle(fontSize: 11.5)),
            ),
        ]),
      ),
    );
  }
}
