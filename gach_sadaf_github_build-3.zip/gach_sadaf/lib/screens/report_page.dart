import 'package:flutter/material.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../services/report_service.dart';
import '../widgets/common.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({super.key});

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  ReportRange _range = ReportRange.day;
  Jalali _day = Jalali.today();
  int _month = Jalali.today().month;
  int _year = Jalali.today().year;

  ReportData? _data;
  bool _busy = false;

  Future<void> _run() async {
    setState(() => _busy = true);
    final d = await ReportService.instance.build(
      range: _range,
      day: _day,
      month: _month,
      year: _year,
    );
    if (!mounted) return;
    setState(() {
      _data = d;
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 30),
      children: [
        SectionCard(
          title: 'انتخاب بازه گزارش',
          icon: Icons.filter_alt,
          child: Column(children: [
            SegmentedButton<ReportRange>(
              segments: const [
                ButtonSegment(value: ReportRange.day, label: Text('روزانه')),
                ButtonSegment(value: ReportRange.month, label: Text('ماهانه')),
                ButtonSegment(value: ReportRange.year, label: Text('سالانه')),
                ButtonSegment(value: ReportRange.all, label: Text('همه')),
              ],
              selected: {_range},
              showSelectedIcon: false,
              style: const ButtonStyle(
                textStyle: WidgetStatePropertyAll(
                    TextStyle(fontSize: 12, fontFamily: 'Vazirmatn')),
              ),
              onSelectionChanged: (s) => setState(() => _range = s.first),
            ),
            const SizedBox(height: 14),
            if (_range == ReportRange.day)
              JalaliField(
                label: 'تاریخ',
                value: _day.storage,
                onChanged: (v) =>
                    setState(() => _day = Jalali.tryParse(v) ?? Jalali.today()),
              ),
            if (_range == ReportRange.month)
              Row(children: [
                Expanded(
                  flex: 2,
                  child: AppDropdown(
                    label: 'ماه',
                    value: afghanMonths[_month - 1],
                    items: afghanMonths,
                    onChanged: (v) =>
                        setState(() => _month = afghanMonths.indexOf(v!) + 1),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: _yearDropdown()),
              ]),
            if (_range == ReportRange.year) _yearDropdown(),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _busy ? null : _run,
                icon: const Icon(Icons.search, size: 18),
                label: const Text('نمایش گزارش'),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 12),

        if (_busy)
          const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator(strokeWidth: 2.5)),
          )
        else if (_data == null)
          const SectionCard(
            child: EmptyState('بازه را انتخاب و روی «نمایش گزارش» کلیک کنید',
                icon: Icons.description_outlined),
          )
        else
          ..._buildResult(_data!),
      ],
    );
  }

  Widget _yearDropdown() => AppDropdown(
        label: 'سال',
        value: _year.toString(),
        items: [
          for (var y = Jalali.today().year - 5; y <= Jalali.today().year + 1; y++)
            y.toString()
        ],
        onChanged: (v) => setState(() => _year = int.parse(v!)),
      );

  List<Widget> _buildResult(ReportData d) {
    return [
      SectionCard(
        title: d.title,
        icon: Icons.summarize,
        child: Column(children: [
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 2.1,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            children: [
              _box('فروشات وصول‌شده', fmtNum(d.totalSalesPaid), AppColors.greenBg,
                  AppColors.greenText),
              _box('باقی از مشتریان', fmtNum(d.totalSalesRemaining),
                  AppColors.redBg, AppColors.redText),
              _box('مصارف', fmtNum(d.totalExpenses), AppColors.amberBg,
                  AppColors.amber),
              _box('پول سنگ', fmtNum(d.totalStonePaid), AppColors.purpleBg,
                  AppColors.purple),
              _box('معاش کارگران', fmtNum(d.totalWages), AppColors.blueBg,
                  AppColors.blue),
              _box('تولید (خلته)', fmtNum(d.totalGunny), AppColors.sky,
                  AppColors.navy),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: d.netProfit >= 0 ? AppColors.greenBg : AppColors.redBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(children: [
              const Text('سود خالص تخمینی',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(
                fmtMoney(d.netProfit, kAfghani),
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: d.netProfit >= 0 ? AppColors.greenText : AppColors.redText,
                ),
              ),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 12),
      SectionCard(
        title: 'خروجی PDF',
        icon: Icons.ios_share,
        child: Wrap(spacing: 10, runSpacing: 10, children: [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.navy),
            onPressed: () => ReportService.instance.printReport(d),
            icon: const Icon(Icons.print, size: 18),
            label: const Text('چاپ / ذخیره PDF'),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
            onPressed: () => ReportService.instance.shareReportPdf(d),
            icon: const Icon(Icons.share, size: 18),
            label: const Text('ارسال PDF'),
          ),
        ]),
      ),
      const SizedBox(height: 12),
      _countCard(d),
    ];
  }

  Widget _countCard(ReportData d) => SectionCard(
        title: 'تعداد رکوردها در این بازه',
        icon: Icons.list_alt,
        child: Column(children: [
          KeyValueRow('تولید', '${toPersianDigits(d.production.length)} رکورد'),
          KeyValueRow('فروشات', '${toPersianDigits(d.sales.length)} رکورد'),
          KeyValueRow('خرید سنگ', '${toPersianDigits(d.stones.length)} رکورد'),
          KeyValueRow('کارگران', '${toPersianDigits(d.workers.length)} رکورد'),
          KeyValueRow('مصارف', '${toPersianDigits(d.expenses.length)} رکورد'),
          if (d.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text('برای این بازه هیچ رکوردی پیدا نشد',
                  style: TextStyle(color: AppColors.textLight, fontSize: 12.5)),
            ),
        ]),
      );

  Widget _box(String label, String value, Color bg, Color fg) => Container(
        padding: const EdgeInsets.all(10),
        decoration:
            BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label,
                style: TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w700, color: fg)),
            const SizedBox(height: 3),
            FittedBox(
              child: Text(value,
                  style: TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800, color: fg)),
            ),
          ],
        ),
      );
}
