import 'package:flutter/material.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';
import '../widgets/entity_scaffold.dart';

class StonesPage extends StatelessWidget {
  const StonesPage({super.key});

  static const Color _color = AppColors.purple;

  Future<List<Stone>> _load() async =>
      (await AppDb.instance.rows(T.stones)).map(Stone.fromMap).toList();

  @override
  Widget build(BuildContext context) {
    return EntityScaffold<Stone>(
      table: T.stones,
      color: _color,
      addLabel: 'ثبت خرید سنگ',
      searchHint: 'جستجو با اسم فروشنده، راننده یا تاریخ…',
      emptyText: 'هنوز خرید سنگی ثبت نشده است',
      load: _load,
      match: (r, q) => [r.seller, r.invNum, r.type, r.date, r.driver]
          .any((f) => f.toLowerCase().contains(q.toLowerCase())),
      openForm: (ctx, rec) => _openStoneForm(ctx, rec),
      card: (context, s) => RecordCard(
        record: s,
        color: _color,
        title: s.seller,
        subtitle:
            '${showText(s.type)}  •  ${fmtNum(s.weight)} تن  •  ${showDate(s.date)}',
        onEdit: () => _openStoneForm(context, s),
        rows: [
          KeyValueRow('قیمت فی تن', fmtMoney(s.pricePerTon, s.cur)),
          KeyValueRow('قیمت کل سنگ', fmtMoney(s.total, s.cur), big: true),
          Row(children: [
            Pill.green('پرداخت: ${fmtMoney(s.paid, s.cur)}'),
            const SizedBox(width: 8),
            if (s.remaining > 0)
              Pill.red('باقی: ${fmtMoney(s.remaining, s.cur)}')
            else
              Pill.green('تصفیه شده'),
          ]),
          if (s.driver.isNotEmpty) ...[
            const Divider(height: 18),
            KeyValueRow('راننده', s.driver),
            KeyValueRow('کرایه کل', fmtMoney(s.driverTotal, s.driverCur)),
            Row(children: [
              Pill.green('پرداخت راننده: ${fmtMoney(s.driverPaid, s.driverCur)}'),
              const SizedBox(width: 8),
              if (s.driverRem > 0)
                Pill.red('باقی: ${fmtMoney(s.driverRem, s.driverCur)}'),
            ]),
          ],
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

Future<bool> _openStoneForm(BuildContext context, Stone? existing) async {
  final s = existing ??
      Stone(
        cur: Settings.instance.defaultCurrency,
        driverCur: Settings.instance.defaultCurrency,
        date: Jalali.today().storage,
        paidDate: Jalali.today().storage,
        deliverDate: Jalali.today().storage,
      );

  final seller = TextEditingController(text: s.seller);
  final type = TextEditingController(text: s.type);
  final weight = TextEditingController(text: s.weight == 0 ? '' : plainNum(s.weight));
  final perTon =
      TextEditingController(text: s.pricePerTon == 0 ? '' : plainNum(s.pricePerTon));
  final total = TextEditingController(text: s.total == 0 ? '' : plainNum(s.total));
  final paid = TextEditingController(text: s.paid == 0 ? '' : plainNum(s.paid));

  final driver = TextEditingController(text: s.driver);
  final dRate =
      TextEditingController(text: s.driverRate == 0 ? '' : plainNum(s.driverRate));
  final dTotal =
      TextEditingController(text: s.driverTotal == 0 ? '' : plainNum(s.driverTotal));
  final dPaid =
      TextEditingController(text: s.driverPaid == 0 ? '' : plainNum(s.driverPaid));

  void recomputeStone() {
    final w = toDouble(weight.text);
    final p = toDouble(perTon.text);
    if (w > 0 && p > 0) total.text = plainNum(w * p);
  }

  void recomputeDriver() {
    final w = toDouble(weight.text);
    final r = toDouble(dRate.text);
    if (w > 0 && r > 0) dTotal.text = plainNum(w * r);
  }

  return openFormSheet(
    context: context,
    title: existing == null ? 'ثبت خرید سنگ جدید' : 'ویرایش خرید سنگ',
    icon: Icons.landscape,
    color: AppColors.purple,
    body: (ctx, refresh) => Column(children: [
      SectionCard(
        title: 'مشخصات سنگ',
        icon: Icons.landscape,
        titleColor: AppColors.purple,
        child: FieldGrid(children: [
          AppField(controller: seller, label: 'اسم صاحب سنگ *'),
          AppField(controller: type, label: 'نوعیت سنگ', hint: 'مثلا: سنگ آهک'),
          AppField(
            controller: weight,
            label: 'وزن (تن)',
            number: true,
            onChanged: (_) {
              recomputeStone();
              recomputeDriver();
              refresh();
            },
          ),
          AppField(
            controller: perTon,
            label: 'قیمت فی تن',
            number: true,
            onChanged: (_) {
              recomputeStone();
              refresh();
            },
          ),
          AppField(
            controller: total,
            label: 'قیمت کل (قابل ویرایش)',
            number: true,
            fill: AppColors.greenBg,
            textColor: AppColors.greenText,
            onChanged: (_) => refresh(),
          ),
          AppDropdown(
            label: 'واحد پول',
            value: s.cur,
            items: kCurrencies,
            onChanged: (v) {
              s.cur = v ?? kAfghani;
              refresh();
            },
          ),
          AppField(
              controller: paid,
              label: 'پول پرداخت شده',
              number: true,
              onChanged: (_) => refresh()),
          AppField(
            controller: TextEditingController(
                text: fmtMoney(toDouble(total.text) - toDouble(paid.text), s.cur)),
            label: 'باقی پول (خودکار)',
            readOnly: true,
            fill: AppColors.redBg,
            textColor: AppColors.redText,
          ),
          JalaliField(
              label: 'تاریخ خرید',
              value: s.date,
              onChanged: (v) {
                s.date = v;
                refresh();
              }),
          JalaliField(
              label: 'تاریخ پرداخت',
              value: s.paidDate,
              onChanged: (v) {
                s.paidDate = v;
                refresh();
              }),
        ]),
      ),
      const SizedBox(height: 12),
      SectionCard(
        title: 'مشخصات راننده و کرایه',
        icon: Icons.local_shipping,
        titleColor: AppColors.greenText,
        child: FieldGrid(children: [
          AppField(controller: driver, label: 'اسم راننده'),
          AppDropdown(
            label: 'واحد کرایه',
            value: s.driverCur,
            items: kCurrencies,
            onChanged: (v) {
              s.driverCur = v ?? kAfghani;
              refresh();
            },
          ),
          AppField(
            controller: dRate,
            label: 'کرایه فی تن',
            number: true,
            onChanged: (_) {
              recomputeDriver();
              refresh();
            },
          ),
          AppField(
            controller: dTotal,
            label: 'کرایه کل (قابل ویرایش)',
            number: true,
            fill: AppColors.greenBg,
            textColor: AppColors.greenText,
            onChanged: (_) => refresh(),
          ),
          AppField(
              controller: dPaid,
              label: 'پرداخت به راننده',
              number: true,
              onChanged: (_) => refresh()),
          AppField(
            controller: TextEditingController(
                text: fmtMoney(
                    toDouble(dTotal.text) - toDouble(dPaid.text), s.driverCur)),
            label: 'باقی راننده (خودکار)',
            readOnly: true,
            fill: AppColors.redBg,
            textColor: AppColors.redText,
          ),
          JalaliField(
              label: 'تاریخ تحویل سنگ',
              value: s.deliverDate,
              onChanged: (v) {
                s.deliverDate = v;
                refresh();
              }),
          JalaliField(
              label: 'تاریخ پرداخت کرایه',
              value: s.driverPaidDate,
              onChanged: (v) {
                s.driverPaidDate = v;
                refresh();
              }),
        ]),
      ),
    ]),
    onSave: () async {
      if (seller.text.trim().isEmpty) return 'اسم صاحب سنگ ضروری است';
      s
        ..seller = seller.text.trim()
        ..type = type.text.trim()
        ..weight = toDouble(weight.text)
        ..pricePerTon = toDouble(perTon.text)
        ..total = toDouble(total.text)
        ..paid = toDouble(paid.text)
        ..driver = driver.text.trim()
        ..driverRate = toDouble(dRate.text)
        ..driverTotal = toDouble(dTotal.text)
        ..driverPaid = toDouble(dPaid.text);
      // مجموع دستی نباید با محاسبه خودکار بازنویسی شود
      s.remaining = s.total - s.paid;
      s.driverRem = s.driverTotal - s.driverPaid;

      if (s.id == null) {
        s.invNum = await AppDb.instance.nextInvoiceNumber(T.stones);
        await AppDb.instance.insert(T.stones, s.toMap());
      } else {
        await AppDb.instance.update(T.stones, s.id!, s.toMap());
      }
      return null;
    },
  );
}
