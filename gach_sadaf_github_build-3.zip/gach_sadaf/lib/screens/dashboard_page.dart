import 'package:flutter/material.dart';

import '../core/events.dart';
import '../core/format.dart';
import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../services/inventory_service.dart';
import '../widgets/common.dart';
import '../widgets/daily_sales_chart.dart';
import 'expenses_page.dart';
import 'inventory_page.dart';
import 'production_page.dart';
import 'sales_page.dart';
import 'stones_page.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  Future<_DashData> _load() async {
    final workers =
        (await AppDb.instance.rows(T.workers)).map(Worker.fromMap).toList();
    final stones =
        (await AppDb.instance.rows(T.stones)).map(Stone.fromMap).toList();
    final prod =
        (await AppDb.instance.rows(T.production)).map(Production.fromMap).toList();
    final sales = (await AppDb.instance.rows(T.sales)).map(Sale.fromMap).toList();
    final exps =
        (await AppDb.instance.rows(T.expenses)).map(Expense.fromMap).toList();
    final stock = await InventoryService.instance.all();
    return _DashData(workers, stones, prod, sales, exps, stock);
  }

  @override
  Widget build(BuildContext context) {
    return DataBuilder<_DashData>(
      load: _load,
      loading: const SkeletonList(count: 3),
      builder: (context, d) => ListView(
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 24),
        children: [
          _QuickActions(),
          const SizedBox(height: 14),

          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.5,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            children: [
              _StatCard(0, 'فروشات (وصول‌شده)', d.salesPaid, Icons.point_of_sale_rounded,
                  AppColors.greenBg, AppColors.greenText),
              _StatCard(1, 'باقی از مشتریان', d.salesRemaining, Icons.warning_amber_rounded,
                  AppColors.redBg, AppColors.redText),
              _StatCard(2, 'مصارف', d.expenses, Icons.receipt_long_rounded,
                  AppColors.amberBg, AppColors.amber),
              _StatCard(3, 'پول سنگ', d.stonePaid, Icons.landscape_rounded,
                  AppColors.purpleBg, AppColors.purple),
              _StatCard(4, 'معاش کارگران', d.wages, Icons.engineering_rounded,
                  AppColors.blueBg, AppColors.blue),
              _StatCard(5, 'تولید (خلته)', d.gunny, Icons.factory_rounded,
                  AppColors.sky, AppColors.navy, isMoney: false),
            ],
          ),
          const SizedBox(height: 14),

          FadeSlideIn(
            delay: const Duration(milliseconds: 200),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: d.netProfit >= 0
                    ? const LinearGradient(
                        colors: [AppColors.navyDark, AppColors.navySoft],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft)
                    : const LinearGradient(
                        colors: [Color(0xFF5A1A1E), AppColors.red],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft),
                borderRadius: BorderRadius.circular(AppRadii.xl),
                boxShadow: AppShadows.lifted(Theme.of(context).brightness),
              ),
              child: Column(children: [
                Row(children: [
                  Icon(Icons.trending_up_rounded,
                      color: Colors.white.withValues(alpha: .85), size: 18),
                  const SizedBox(width: 6),
                  Text('سود خالص تخمینی',
                      style: TextStyle(
                          color: Colors.white.withValues(alpha: .85),
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700)),
                ]),
                const SizedBox(height: 10),
                _AnimatedMoney(
                  value: d.netProfit,
                  style: const TextStyle(
                      fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white),
                ),
                const SizedBox(height: 8),
                Text(
                  'فروش وصول‌شده منهای مصارف، پول سنگ و معاش کارگران',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11.5, color: Colors.white.withValues(alpha: .7)),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 14),

          FadeSlideIn(
            delay: const Duration(milliseconds: 230),
            child: SectionCard(
              title: 'موجودی انبار',
              icon: Icons.warehouse_rounded,
              titleColor: AppColors.navySoft,
              child: d.stock.isEmpty
                  ? Text('هنوز موجودی ثبت نشده — با ثبت تولید، انبار خودکار پر می‌شود',
                      style: TextStyle(fontSize: 12, color: context.textSecondary))
                  : Column(children: [
                      KeyValueRow('مجموع موجودی', '${fmtNum(d.stockTotal)} خلته', big: true),
                      for (final it in d.stock.take(6))
                        KeyValueRow(
                            it.weight > 0
                                ? '${it.type} • ${fmtNum(it.weight)} کیلویی'
                                : it.type,
                            '${fmtNum(it.qty)} خلته',
                            valueColor: it.qty <= 0 ? AppColors.redText : null),
                    ]),
            ),
          ),
          const SizedBox(height: 14),

          FadeSlideIn(
            delay: const Duration(milliseconds: 260),
            child: SectionCard(
              title: 'فروش روزانه',
              icon: Icons.bar_chart_rounded,
              child: DailySalesChart(sales: d.sales),
            ),
          ),
          const SizedBox(height: 12),

          FadeSlideIn(
            delay: const Duration(milliseconds: 320),
            child: SectionCard(
              title: 'آخرین فروشات',
              icon: Icons.history_rounded,
              titleColor: AppColors.greenText,
              child: d.sales.isEmpty
                  ? const EmptyState('هنوز فروشی ثبت نشده')
                  : Column(
                      children: [
                        for (final s in d.sales.take(5))
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(children: [
                              Container(
                                width: 30,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: AppColors.greenBg,
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                child: const Icon(Icons.person_rounded,
                                    size: 16, color: AppColors.greenText),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(s.buyer,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 13, fontWeight: FontWeight.w700)),
                              ),
                              Text(showDate(s.date),
                                  style: TextStyle(fontSize: 11, color: context.textMuted)),
                              const SizedBox(width: 8),
                              Pill.green(fmtMoney(s.paid, s.cur)),
                            ]),
                          ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 12),

          FadeSlideIn(
            delay: const Duration(milliseconds: 380),
            child: SectionCard(
              title: 'آخرین تولید',
              icon: Icons.factory_rounded,
              titleColor: AppColors.amber,
              child: d.production.isEmpty
                  ? const EmptyState('هنوز تولیدی ثبت نشده')
                  : Column(
                      children: [
                        for (final pr in d.production.take(5))
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Row(children: [
                              Container(
                                width: 30,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: AppColors.amberBg,
                                  borderRadius: BorderRadius.circular(9),
                                ),
                                child: const Icon(Icons.factory_rounded,
                                    size: 16, color: AppColors.amber),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  '${showDate(pr.date)} — ${showText(pr.type)}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12.5),
                                ),
                              ),
                              Pill.blue('${fmtNum(pr.gunny)} خلته'),
                            ]),
                          ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

/// دسترسی سریع به ثبت‌های پرکاربرد
class _QuickActions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = <_QuickAction>[
      _QuickAction('فروش جدید', Icons.point_of_sale_rounded, AppColors.green,
          () => Navigator.push(context, modernRoute(const _PushedPage('فروشات', SalesPage())))),
      _QuickAction('تولید جدید', Icons.factory_rounded, AppColors.amber,
          () => Navigator.push(context, modernRoute(const _PushedPage('تولید', ProductionPage())))),
      _QuickAction('انبار', Icons.warehouse_rounded, AppColors.navySoft,
          () => Navigator.push(context, modernRoute(const _PushedPage('انبار', InventoryPage())))),
      _QuickAction('خرید سنگ', Icons.landscape_rounded, AppColors.purple,
          () => Navigator.push(context, modernRoute(const _PushedPage('خرید سنگ', StonesPage())))),
      _QuickAction('ثبت مصرف', Icons.receipt_long_rounded, AppColors.red,
          () => Navigator.push(context, modernRoute(const _PushedPage('مصارف', ExpensesPage())))),
    ];

    return SizedBox(
      height: 84,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, i) => FadeSlideIn(
          delay: Duration(milliseconds: 40 * i),
          offsetY: 8,
          child: Pressable(
            onTap: items[i].onTap,
            child: Container(
              width: 92,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              decoration: BoxDecoration(
                color: context.cardBg,
                borderRadius: BorderRadius.circular(AppRadii.md),
                border: Border.all(color: context.borderColor),
                boxShadow: AppShadows.soft(Theme.of(context).brightness),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: items[i].color.withValues(alpha: context.isDark ? .18 : .12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(items[i].icon, size: 18, color: items[i].color),
                ),
                const SizedBox(height: 6),
                Text(items[i].label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 10.5, fontWeight: FontWeight.w700, color: context.textPrimary)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _QuickAction {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  _QuickAction(this.label, this.icon, this.color, this.onTap);
}

class _DashData {
  final List<Worker> workers;
  final List<Stone> stones;
  final List<Production> production;
  final List<Sale> sales;
  final List<Expense> expenseList;
  final List<StockItem> stock;

  _DashData(this.workers, this.stones, this.production, this.sales,
      this.expenseList, this.stock);

  double get stockTotal => stock.fold(0, (s, i) => s + i.qty);

  double get salesPaid => sales.fold(0, (s, r) => s + r.paid);
  double get salesRemaining => sales.fold(0, (s, r) => s + r.remaining);
  double get expenses => expenseList.fold(0, (s, r) => s + r.paid);
  double get stonePaid => stones.fold(0, (s, r) => s + r.paid);
  double get wages => workers.fold(0, (s, r) => s + r.paid);
  double get gunny => production.fold(0, (s, r) => s + r.gunny);
  double get netProfit => salesPaid - expenses - stonePaid - wages;

}

/// شمارندهٔ عددی متحرک — از صفر تا مقدار واقعی هنگام ورود به صفحه بالا می‌رود
class _AnimatedMoney extends StatelessWidget {
  final double value;
  final TextStyle style;
  const _AnimatedMoney({required this.value, required this.style});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: value),
      duration: const Duration(milliseconds: 900),
      curve: Curves.easeOutCubic,
      builder: (context, v, _) => Text(fmtMoney(v, kAfghani), style: style),
    );
  }
}

class _StatCard extends StatelessWidget {
  final int index;
  final String label;
  final double value;
  final IconData icon;
  final Color bg;
  final Color fg;
  final bool isMoney;
  const _StatCard(this.index, this.label, this.value, this.icon, this.bg, this.fg,
      {this.isMoney = true});

  @override
  Widget build(BuildContext context) {
    final dark = context.isDark;
    return FadeSlideIn(
      delay: Duration(milliseconds: 40 * index),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: dark ? fg.withValues(alpha: .14) : bg,
          borderRadius: BorderRadius.circular(AppRadii.lg),
          border: Border.all(color: fg.withValues(alpha: .18)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: fg.withValues(alpha: .16),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(icon, size: 15, color: fg),
              ),
              const SizedBox(width: 7),
              Expanded(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg)),
              ),
            ]),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: AlignmentDirectional.centerStart,
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: value),
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeOutCubic,
                builder: (context, v, _) => Text(
                  isMoney ? fmtMoney(v, kAfghani) : '${fmtNum(v)} خلته',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: fg),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// صفحه‌ای که از داشبورد باز می‌شود — با نوار بالا و دکمهٔ برگشت
class _PushedPage extends StatelessWidget {
  final String title;
  final Widget child;
  const _PushedPage(this.title, this.child);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(decoration: const BoxDecoration(gradient: AppColors.navyGradient)),
        title: Text(title),
      ),
      body: child,
    );
  }
}
