import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../widgets/pin_pad.dart';
import 'home_screen.dart';

/// قفل برنامه: دو روش ورود — پین عددی (با صفحه‌کلید) و اثر انگشت.
/// اگر رمز قدیمی حروف داشته باشد، حالت «رمز متنی» هم در دسترس است تا کسی قفل نشود.
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _pw = TextEditingController();
  String _pin = '';
  String _error = '';
  int _attempts = 0;
  int _shake = 0;
  bool _locked = false;
  bool _bioAvailable = false;
  bool _busy = false;
  late bool _textMode;

  int get _len => Auth.instance.pinLength == 0 ? 4 : Auth.instance.pinLength;
  bool get _showBio => _bioAvailable && Auth.instance.bioEnabled;

  @override
  void initState() {
    super.initState();
    _textMode = Auth.instance.pinLength == 0;
    _checkBio();
  }

  Future<void> _checkBio() async {
    final ok = await Auth.instance.bioAvailable();
    if (!mounted) return;
    setState(() => _bioAvailable = ok);
    if (ok && Auth.instance.bioEnabled) _loginWithBio();
  }

  void _enter() {
    Navigator.pushReplacement(context, modernRoute(const HomeScreen()));
  }

  Future<void> _loginWithBio() async {
    if (_busy || _locked) return;
    setState(() => _busy = true);
    final ok = await Auth.instance.authenticateBio();
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      _enter();
    } else {
      setState(() => _error = 'اثر انگشت تایید نشد — پین را وارد کنید');
    }
  }

  void _onDigit(String d) {
    if (_locked || _busy || _pin.length >= _len) return;
    setState(() {
      _pin += d;
      _error = '';
    });
    if (_pin.length == _len) {
      final value = _pin;
      // کمی مکث تا آخرین نقطه پر دیده شود
      Future.delayed(const Duration(milliseconds: 140), () {
        if (mounted) _verify(value);
      });
    }
  }

  void _onBackspace() {
    if (_locked || _pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  void _verify(String value) {
    if (_locked) return;
    if (Auth.instance.checkPassword(value)) {
      _enter();
      return;
    }
    HapticFeedback.heavyImpact();
    _attempts++;
    setState(() {
      _pin = '';
      _pw.clear();
      _shake++;
    });
    if (_attempts >= 5) {
      setState(() {
        _locked = true;
        _error = 'پنج بار اشتباه! ۳۰ ثانیه صبر کنید';
      });
      Future.delayed(const Duration(seconds: 30), () {
        if (!mounted) return;
        setState(() {
          _locked = false;
          _attempts = 0;
          _error = '';
        });
      });
    } else {
      setState(() => _error = 'پین اشتباه است — تلاش ${toPersianDigits(_attempts)} از ۵');
    }
  }

  @override
  void dispose() {
    _pw.dispose();
    super.dispose();
  }

  Widget _bioButton() {
    return Pressable(
      scaleTo: 0.9,
      onTap: _busy ? null : _loginWithBio,
      child: Container(
        width: 58,
        height: 58,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.goldLight, width: 1.4),
          color: AppColors.goldLight.withValues(alpha: .10),
        ),
        child: const Icon(Icons.fingerprint, size: 30, color: AppColors.goldLight),
      ),
    );
  }

  Widget _pinMode() {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Shake(
        trigger: _shake,
        child: PinDots(length: _len, filled: _pin.length, error: _error.isNotEmpty),
      ),
      const SizedBox(height: 12),
      SizedBox(
        height: 36,
        child: AnimatedSwitcher(
          duration: AppMotion.base,
          child: Text(
            _error.isEmpty ? (_showBio ? 'پین را وارد کنید یا اثر انگشت بگذارید' : 'پین را وارد کنید') : _error,
            key: ValueKey(_error),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              height: 1.5,
              fontWeight: FontWeight.w700,
              color: _error.isEmpty ? Colors.white70 : const Color(0xFFFFC2B8),
            ),
          ),
        ),
      ),
      const SizedBox(height: 4),
      NumPad(
        onDigit: _onDigit,
        onBackspace: _onBackspace,
        extra: _showBio ? _bioButton() : null,
      ),
      TextButton(
        onPressed: () => setState(() {
          _textMode = true;
          _error = '';
          _pin = '';
        }),
        child: const Text('ورود با رمز متنی', style: TextStyle(color: Colors.white54, fontSize: 11.5)),
      ),
    ]);
  }

  Widget _textModeBody() {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(
        controller: _pw,
        obscureText: true,
        enabled: !_locked,
        textAlign: TextAlign.center,
        onSubmitted: (v) => _verify(v.trim()),
        style: const TextStyle(color: Colors.white, fontSize: 18, letterSpacing: 4),
        decoration: InputDecoration(
          hintText: 'رمز',
          hintStyle: const TextStyle(color: Colors.white38),
          filled: true,
          fillColor: Colors.white.withValues(alpha: .12),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: Colors.white30),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: AppColors.goldLight, width: 1.6),
          ),
        ),
      ),
      const SizedBox(height: 12),
      SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.gold,
            foregroundColor: AppColors.navyDark,
          ),
          onPressed: _locked ? null : () => _verify(_pw.text.trim()),
          child: const Text('ورود به سیستم'),
        ),
      ),
      const SizedBox(height: 8),
      SizedBox(
        height: 22,
        child: Text(_error,
            style: const TextStyle(color: Color(0xFFFFC2B8), fontSize: 12.5, fontWeight: FontWeight.w700)),
      ),
      if (Auth.instance.pinLength != 0)
        TextButton(
          onPressed: () => setState(() {
            _textMode = false;
            _error = '';
          }),
          child: const Text('بازگشت به ورود با پین', style: TextStyle(color: Colors.white54, fontSize: 11.5)),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final card = FadeSlideIn(
      offsetY: 20,
      child: Container(
        width: 340,
        padding: const EdgeInsets.fromLTRB(22, 26, 22, 14),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(AppRadii.xl),
          border: Border.all(color: Colors.white24),
          boxShadow: const [
            BoxShadow(color: Color(0x40000000), blurRadius: 40, offset: Offset(0, 20)),
          ],
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Image.asset('assets/images/crest.png', width: 80, height: 80, fit: BoxFit.cover),
          ),
          const SizedBox(height: 12),
          const Text('گچ صدف',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          const Text('سامانه مدیریت کارخانه',
              style: TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 20),
          _textMode ? _textModeBody() : _pinMode(),
          if (Auth.instance.isDefaultPassword)
            const Padding(
              padding: EdgeInsets.only(top: 4, bottom: 6),
              child: Text(
                'پین پیش‌فرض ۱۲۳۴ است — بعد از ورود آن را تغییر دهید',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54, fontSize: 10.5),
              ),
            ),
        ]),
      ),
    );

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.navyGradient),
        child: Stack(children: [
          Positioned(
            top: -60,
            left: -40,
            child: _glowCircle(220, AppColors.goldLight.withValues(alpha: .10)),
          ),
          Positioned(
            bottom: -80,
            right: -60,
            child: _glowCircle(260, AppColors.navySoft.withValues(alpha: .35)),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: card,
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _glowCircle(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
    );
  }
}
