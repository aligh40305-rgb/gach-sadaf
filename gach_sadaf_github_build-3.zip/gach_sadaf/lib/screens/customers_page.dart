import 'package:flutter/material.dart';

import '../core/events.dart';
import '../core/format.dart';
import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../data/customers.dart';
import '../data/models.dart';
import '../services/customer_service.dart';
import '../widgets/common.dart';
import '../widgets/invoice.dart';

String _moneyMap(Map<String, double> m) {
  final parts = [
    for (final e in m.entries)
      if (e.value.abs() > 0.0001) fmtMoney(e.value, e.key),
  ];
  return parts.isEmpty ? '—' : parts.join(' + ');
}

class CustomersPage extends StatefulWidget {
  const CustomersPage({super.key});

  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  String _query = '';

  bool _match(CustomerSummary s, String q) {
    final n = normalizeCustomerName(q);
    final digits = toEnglishDigits(q).replaceAll(RegExp(r'[^0-9]'), '');
    final c = s.customer;
    if (n.isNotEmpty && c.name.contains(n)) return true;
    if (digits.isNotEmpty && (c.phone.contains(digits) || c.id.toString() == digits)) {
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.navySoft,
        foregroundColor: Colors.white,
        onPressed: () => _editCustomer(context),
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('مشتری جدید',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
          child: SearchBox(
            hint: 'جستجو با نام، شماره تلفن یا کد مشتری…',
            onChanged: (v) => setState(() => _query = v.trim()),
          ),
        ),
        Expanded(
          child: DataBuilder<List<CustomerSummary>>(
            load: CustomerService.instance.summaries,
            loading: const SkeletonList(),
            builder: (context, all) {
              final list =
                  _query.isEmpty ? all : all.where((s) => _match(s, _query)).toList();
              final debtors = all.where((s) => s.hasDebt).length;

              if (all.isEmpty) {
                return SingleChildScrollView(
                  child: EmptyState(
                    'هنوز مشتری‌ای ثبت نشده — مشتریان با ثبت فروش خودکار اضافه می‌شوند',
                    icon: Icons.people_outline_rounded,
                    actionLabel: 'مشتری جدید',
                    onAction: () => _editCustomer(context),
                  ),
                );
              }

              return ListView(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
                children: [
                  Row(children: [
                    Expanded(
                      child: _Stat('تعداد مشتریان', toPersianDigits(all.length),
                          Icons.people_alt_rounded, AppColors.blue),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _Stat('مشتریان بدهکار', toPersianDigits(debtors),
                          Icons.warning_amber_rounded,
                          debtors > 0 ? AppColors.red : AppColors.green),
                    ),
                  ]),
                  const SizedBox(height: 12),
                  if (list.isEmpty)
                    const EmptyState('نتیجه‌ای پیدا نشد', icon: Icons.search_off_rounded)
                  else
                    for (var i = 0; i < list.length; i++)
                      FadeSlideIn(
                        delay: Duration(milliseconds: 28 * i.clamp(0, 10).toInt()),
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _CustomerCard(
                            summary: list[i],
                            onTap: () => showCustomerSheet(context, list[i].customer.id),
                          ),
                        ),
                      ),
                ],
              );
            },
          ),
        ),
      ]),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const _Stat(this.label, this.value, this.icon, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: context.isDark ? .16 : .09),
        borderRadius: BorderRadius.circular(AppRadii.md),
      ),
      child: Row(children: [
        Icon(icon, size: 20, color: color),
        const SizedBox(width: 8),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: color)),
            Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
          ]),
        ),
      ]),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String name;
  final double size;
  const _Avatar(this.name, {this.size = 44});

  @override
  Widget build(BuildContext context) {
    final letter = name.trim().isEmpty ? '؟' : name.trim().substring(0, 1);
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: AppColors.navyGradient),
      child: Text(letter,
          style: TextStyle(
              color: Colors.white, fontSize: size * .42, fontWeight: FontWeight.w800)),
    );
  }
}

class _CustomerCard extends StatelessWidget {
  final CustomerSummary summary;
  final VoidCallback onTap;
  const _CustomerCard({required this.summary, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = summary.customer;
    return Pressable(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: context.cardBg,
          borderRadius: BorderRadius.circular(AppRadii.lg),
          border: Border.all(color: context.borderColor),
          boxShadow: AppShadows.soft(Theme.of(context).brightness),
        ),
        child: Row(children: [
          _Avatar(c.name),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w800, color: context.textPrimary)),
              const SizedBox(height: 3),
              Text(
                'کد ${toPersianDigits(c.id)}  •  ${c.phone.isEmpty ? 'بدون شماره' : toPersianDigits(c.phone)}',
                style: TextStyle(fontSize: 11.5, color: context.textSecondary),
              ),
              if (c.location.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(c.location,
                      style: TextStyle(fontSize: 11, color: context.textMuted)),
                ),
            ]),
          ),
          const SizedBox(width: 8),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Pill.blue('${toPersianDigits(summary.count)} خرید'),
            const SizedBox(height: 6),
            if (summary.hasDebt)
              Pill.red('باقی: ${_moneyMap({
                for (final e in summary.remaining.entries)
                  if (e.value > 0.0001) e.key: e.value
              })}')
            else if (summary.count > 0)
              Pill.green('تصفیه')
            else
              Pill.amber('بدون خرید'),
          ]),
        ]),
      ),
    );
  }
}

// ───────────────────────── جزئیات مشتری ─────────────────────────

class _Detail {
  final CustomerSummary? summary;
  final List<Sale> sales;
  const _Detail(this.summary, this.sales);
}

Future<_Detail> _loadDetail(int id) async {
  final sums = await CustomerService.instance.summaries();
  final i = sums.indexWhere((x) => x.customer.id == id);
  if (i < 0) return const _Detail(null, []);
  final sales = await CustomerService.instance.salesOf(id);
  return _Detail(sums[i], sales);
}

Future<void> showCustomerSheet(BuildContext context, int id) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => DraggableScrollableSheet(
      initialChildSize: .9,
      minChildSize: .5,
      maxChildSize: .95,
      expand: false,
      builder: (ctx, controller) => Container(
        decoration: BoxDecoration(
          color: Theme.of(ctx).scaffoldBackgroundColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadii.xl)),
        ),
        child: DataBuilder<_Detail>(
          load: () => _loadDetail(id),
          builder: (c, d) {
            final sum = d.summary;
            if (sum == null) {
              return const Center(child: Text('این مشتری دیگر وجود ندارد'));
            }
            return _CustomerDetail(
              summary: sum,
              sales: d.sales,
              controller: controller,
              sheetContext: ctx,
            );
          },
        ),
      ),
    ),
  );
}

class _CustomerDetail extends StatelessWidget {
  final CustomerSummary summary;
  final List<Sale> sales;
  final ScrollController controller;
  final BuildContext sheetContext;

  const _CustomerDetail({
    required this.summary,
    required this.sales,
    required this.controller,
    required this.sheetContext,
  });

  Future<void> _merge(BuildContext context) async {
    final c = summary.customer;
    final target = await _pickCustomer(context, exceptId: c.id);
    if (target == null || !context.mounted) return;
    final ok = await confirmDialog(
      context,
      title: 'ادغام مشتریان',
      message:
          'همهٔ خریدهای «${c.name}» (کد ${toPersianDigits(c.id)}) به «${target.name}» (کد ${toPersianDigits(target.id)}) منتقل می‌شود '
          'و مشتری اول حذف می‌شود. ادامه می‌دهید؟',
      okText: 'ادغام',
    );
    if (!ok) return;
    final err = await CustomerService.instance.merge(c.id, target.id);
    notifyDataChanged();
    if (!sheetContext.mounted) return;
    if (err != null) {
      toast(sheetContext, err, error: true);
    } else {
      Navigator.pop(sheetContext);
    }
  }

  Future<void> _delete(BuildContext context) async {
    final c = summary.customer;
    final ok = await confirmDialog(
      context,
      title: 'حذف مشتری',
      message: '«${c.name}» از لیست مشتریان حذف شود؟',
      okText: 'حذف',
      danger: true,
    );
    if (!ok) return;
    final err = await CustomerService.instance.delete(c.id);
    if (!sheetContext.mounted) return;
    if (err != null) {
      toast(sheetContext, err, error: true);
    } else {
      notifyDataChanged();
      Navigator.pop(sheetContext);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = summary.customer;

    return ListView(
      controller: controller,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 30),
      children: [
        Center(
          child: Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: context.borderColor,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: AppColors.navyGradient,
            borderRadius: BorderRadius.circular(AppRadii.lg),
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white30, width: 1.4),
              ),
              child: _Avatar(c.name, size: 54),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c.name,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('کد مشتری: ${toPersianDigits(c.id)}',
                    style: const TextStyle(color: AppColors.goldLight, fontSize: 12)),
                Text(c.phone.isEmpty ? 'بدون شماره تلفن' : toPersianDigits(c.phone),
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
                if (c.location.isNotEmpty)
                  Text(c.location,
                      style: const TextStyle(color: Colors.white60, fontSize: 11.5)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'حساب مشتری',
          icon: Icons.account_balance_wallet_rounded,
          child: Column(children: [
            KeyValueRow('تعداد خرید', '${toPersianDigits(summary.count)} فاکتور'),
            KeyValueRow('مجموع خرید', _moneyMap(summary.totals), big: true),
            KeyValueRow('پرداخت‌شده', _moneyMap(summary.paid), valueColor: AppColors.greenText),
            KeyValueRow('باقی‌مانده', _moneyMap(summary.remaining),
                valueColor: summary.hasDebt ? AppColors.redText : null, big: true),
          ]),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => _editCustomer(context, existing: summary),
              icon: const Icon(Icons.edit_rounded, size: 17),
              label: const Text('ویرایش', style: TextStyle(fontSize: 12.5)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => _merge(context),
              icon: const Icon(Icons.call_merge_rounded, size: 17),
              label: const Text('ادغام', style: TextStyle(fontSize: 12.5)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(foregroundColor: AppColors.red),
              onPressed: () => _delete(context),
              icon: const Icon(Icons.delete_outline_rounded, size: 17),
              label: const Text('حذف', style: TextStyle(fontSize: 12.5)),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        SectionCard(
          title: 'تاریخچه خرید',
          icon: Icons.history_rounded,
          child: sales.isEmpty
              ? const EmptyState('این مشتری هنوز خریدی ندارد', icon: Icons.receipt_long_outlined)
              : Column(children: [
                  for (final s in sales)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: Pressable(
                        onTap: () => showInvoiceSheet(context, s),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: context.cardBgAlt,
                            borderRadius: BorderRadius.circular(AppRadii.md),
                          ),
                          child: Row(children: [
                            Pill.blue(s.invNum.isEmpty ? '—' : s.invNum),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(
                                  '${showDate(s.date)}${s.gypsumType.isEmpty ? '' : '  •  ${s.gypsumType}'}',
                                  style: TextStyle(fontSize: 11.5, color: context.textSecondary),
                                ),
                                Text(
                                  s.displayItems.length > 1
                                      ? '${toPersianDigits(s.displayItems.length)} قلم • ${fmtNum(s.qty)} خلته'
                                      : '${fmtNum(s.qty)} خلته${s.bagWeight > 0 ? ' × ${fmtNum(s.bagWeight)} کیلو' : ''}',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: context.textPrimary),
                                ),
                              ]),
                            ),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text(fmtMoney(s.total, s.cur),
                                  style: TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w800,
                                      color: context.textPrimary)),
                              if (s.remaining > 0)
                                Text('باقی: ${fmtMoney(s.remaining, s.cur)}',
                                    style: const TextStyle(
                                        fontSize: 10.5,
                                        color: AppColors.redText,
                                        fontWeight: FontWeight.w700)),
                            ]),
                          ]),
                        ),
                      ),
                    ),
                ]),
        ),
      ],
    );
  }
}

// ───────────────────────── ویرایش / ثبت دستی / انتخاب ─────────────────────────

/// ثبت مشتری جدید یا ویرایش مشتری موجود. برای ثبت جدید هم از همان قاعدهٔ «بدون تکرار» استفاده می‌شود.
Future<void> _editCustomer(BuildContext context, {CustomerSummary? existing}) async {
  final name = TextEditingController(text: existing?.customer.name ?? '');
  final phone = TextEditingController(text: existing?.customer.phone ?? '');
  final location = TextEditingController(text: existing?.customer.location ?? '');
  String error = '';

  final saved = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(existing == null ? 'مشتری جدید' : 'ویرایش مشتری'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AppField(controller: name, label: 'اسم و تخلص *', icon: Icons.person_rounded),
            const SizedBox(height: 10),
            AppField(
              controller: phone,
              label: 'شماره تلفن',
              number: true,
              keyboard: TextInputType.phone,
              icon: Icons.phone_rounded,
            ),
            const SizedBox(height: 10),
            AppField(controller: location, label: 'موقعیت / آدرس', icon: Icons.place_rounded),
            if (error.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(error,
                    style: const TextStyle(
                        color: AppColors.red,
                        fontSize: 12,
                        height: 1.6,
                        fontWeight: FontWeight.w700)),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          ElevatedButton(
            onPressed: () async {
              if (existing != null) {
                final err = await CustomerService.instance.update(
                  existing.customer.id,
                  name: name.text,
                  phone: phone.text,
                  location: location.text,
                );
                if (err != null) {
                  setState(() => error = err);
                  return;
                }
              } else {
                final m = await CustomerService.instance.findOrCreate(
                  name: name.text,
                  phone: phone.text,
                  location: location.text,
                );
                if (m == null) {
                  setState(() => error = 'نام مشتری ضروری است');
                  return;
                }
                if (!m.created) {
                  setState(() => error =
                      'این مشتری قبلاً با کد ${toPersianDigits(m.customer.id)} ثبت شده بود — رکورد تازه ساخته نشد');
                  return;
                }
              }
              if (ctx.mounted) Navigator.pop(ctx, true);
            },
            child: const Text('ذخیره'),
          ),
        ],
      ),
    ),
  );

  name.dispose();
  phone.dispose();
  location.dispose();

  if (saved == true) {
    notifyDataChanged();
    if (context.mounted) toast(context, 'اطلاعات مشتری ذخیره شد');
  }
}

/// انتخاب یک مشتری از لیست (برای ادغام)
Future<Customer?> _pickCustomer(BuildContext context, {required int exceptId}) async {
  final all = (await CustomerService.instance.summaries())
      .map((s) => s.customer)
      .where((c) => c.id != exceptId)
      .toList();
  if (!context.mounted) return null;
  var query = '';

  return showDialog<Customer>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setState) {
        final n = normalizeCustomerName(query);
        final digits = toEnglishDigits(query).replaceAll(RegExp(r'[^0-9]'), '');
        final list = query.trim().isEmpty
            ? all
            : all
                .where((c) =>
                    (n.isNotEmpty && c.name.contains(n)) ||
                    (digits.isNotEmpty && c.phone.contains(digits)))
                .toList();
        return AlertDialog(
          title: const Text('ادغام با کدام مشتری؟'),
          content: SizedBox(
            width: 320,
            height: 380,
            child: Column(children: [
              SearchBox(hint: 'جستجوی نام یا شماره…', onChanged: (v) => setState(() => query = v)),
              const SizedBox(height: 8),
              Expanded(
                child: list.isEmpty
                    ? const Center(child: Text('مشتری‌ای پیدا نشد'))
                    : ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (_, i) => ListTile(
                          dense: true,
                          leading: _Avatar(list[i].name, size: 34),
                          title: Text(list[i].name, style: const TextStyle(fontSize: 13)),
                          subtitle: Text(
                            'کد ${toPersianDigits(list[i].id)}  •  ${list[i].phone.isEmpty ? 'بدون شماره' : toPersianDigits(list[i].phone)}',
                            style: const TextStyle(fontSize: 11),
                          ),
                          onTap: () => Navigator.pop(ctx, list[i]),
                        ),
                      ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
          ],
        );
      },
    ),
  );
}
