import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../core/events.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../services/backup_service.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});

  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  bool _busy = false;
  String _status = '';
  bool _error = false;

  void _set(String msg, {bool error = false}) {
    if (!mounted) return;
    setState(() {
      _status = msg;
      _error = error;
      _busy = false;
    });
  }

  Future<void> _backup() async {
    setState(() {
      _busy = true;
      _status = 'در حال آماده‌سازی فایل بکاپ…';
    });
    try {
      await BackupService.instance.shareBackup();
      _set('فایل بکاپ ساخته شد — اپلیکیشن دلخواه (واتساپ، تلگرام، ایمیل، گوگل درایو) را انتخاب کنید');
    } catch (e) {
      _set('خطا در بکاپ‌گیری: $e', error: true);
    }
  }

  Future<void> _backupDb() async {
    setState(() {
      _busy = true;
      _status = 'در حال کپی کردن دیتابیس…';
    });
    try {
      await BackupService.instance.shareRawDatabase();
      _set('کپی کامل دیتابیس آماده ارسال شد');
    } catch (e) {
      _set('خطا: $e', error: true);
    }
  }

  Future<void> _restore() async {
    final ok = await confirmDialog(
      context,
      title: 'بازگردانی اطلاعات',
      message:
          'اطلاعات فعلی برنامه پاک شده و اطلاعات فایل بکاپ جایگزین می‌شود. ادامه می‌دهید؟',
      okText: 'انتخاب فایل',
    );
    if (!ok) return;

    setState(() {
      _busy = true;
      _status = 'در حال بازگردانی…';
    });
    final result = await BackupService.instance.pickAndRestore();
    if (result.ok) notifyDataChanged();
    _set(result.message, error: !result.ok);
  }

  Future<void> _wipe() async {
    final one = await confirmDialog(
      context,
      title: 'پاک کردن همه اطلاعات',
      message:
          'همه کارگران، خرید سنگ، تولید، فروشات و مصارف برای همیشه پاک می‌شوند. قبل از این کار حتماً بکاپ بگیرید.',
      okText: 'ادامه',
      danger: true,
    );
    if (!one || !mounted) return;
    final two = await confirmDialog(
      context,
      title: 'تایید نهایی',
      message: 'واقعاً می‌خواهید همه اطلاعات پاک شود؟ این کار برگشت‌پذیر نیست.',
      okText: 'بله، پاک کن',
      danger: true,
    );
    if (!two) return;

    await AppDb.instance.clearAll();
    notifyDataChanged();
    _set('همه اطلاعات پاک شد');
  }

  @override
  Widget build(BuildContext context) {
    final last = Settings.instance.lastBackup;

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 30),
      children: [
        SectionCard(
          title: 'گرفتن بکاپ',
          icon: Icons.cloud_upload,
          titleColor: AppColors.greenText,
          background: AppColors.greenBg.withValues(alpha: .45),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'یک فایل از تمام اطلاعات (کارگران، سنگ، تولید، فروشات، مصارف) ساخته می‌شود '
              'و پنجره اشتراک‌گذاری گوشی باز می‌گردد تا آن را برای خود بفرستید.',
              style: TextStyle(fontSize: 12.5, height: 1.9),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 10, runSpacing: 10, children: [
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.green),
                onPressed: _busy ? null : _backup,
                icon: const Icon(Icons.backup, size: 18),
                label: const Text('بکاپ و ارسال'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _backupDb,
                icon: const Icon(Icons.storage, size: 18),
                label: const Text('کپی کامل دیتابیس'),
              ),
            ]),
            const SizedBox(height: 10),
            Text(
              last == null
                  ? 'تا حالا بکاپ نگرفته‌اید'
                  : 'آخرین بکاپ: ${Jalali.fromDateTime(last).fullDisplay}',
              style: const TextStyle(fontSize: 11.5, color: AppColors.textMid),
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'بازگردانی بکاپ',
          icon: Icons.cloud_download,
          titleColor: AppColors.blue,
          background: AppColors.blueBg.withValues(alpha: .45),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'اگر گوشی عوض شد یا اطلاعات پاک شد، فایل بکاپ (با پسوند json) را از حافظه گوشی '
              'انتخاب کنید تا همه اطلاعات برگردد. بکاپ‌های نسخه قدیمی HTML هم پذیرفته می‌شود.',
              style: TextStyle(fontSize: 12.5, height: 1.9),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.blue),
              onPressed: _busy ? null : _restore,
              icon: const Icon(Icons.restore, size: 18),
              label: const Text('انتخاب فایل و بازگردانی'),
            ),
          ]),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'بکاپ‌های ذخیره‌شده روی گوشی',
          icon: Icons.folder,
          child: DataBuilder<List<File>>(
            load: BackupService.instance.localBackups,
            builder: (context, files) {
              if (files.isEmpty) {
                return const EmptyState('هنوز بکاپی ساخته نشده',
                    icon: Icons.folder_open);
              }
              return Column(children: [
                for (final f in files.take(8))
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.description,
                        size: 20, color: AppColors.navy),
                    title: Text(p.basename(f.path),
                        style: const TextStyle(fontSize: 12)),
                    subtitle: Text(
                      '${(f.lengthSync() / 1024).toStringAsFixed(1)} کیلوبایت',
                      style: const TextStyle(fontSize: 11),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.restore, size: 20),
                      tooltip: 'بازگردانی از همین فایل',
                      onPressed: () async {
                        final ok = await confirmDialog(
                          context,
                          title: 'بازگردانی',
                          message:
                              'اطلاعات فعلی با محتوای این فایل جایگزین شود؟',
                          okText: 'بازگردانی',
                        );
                        if (!ok) return;
                        final r = await BackupService.instance.restoreFromFile(f);
                        if (r.ok) notifyDataChanged();
                        _set(r.message, error: !r.ok);
                      },
                    ),
                  ),
              ]);
            },
          ),
        ),
        const SizedBox(height: 12),

        SectionCard(
          title: 'پاک کردن همه اطلاعات',
          icon: Icons.delete_forever,
          titleColor: AppColors.redText,
          background: AppColors.redBg.withValues(alpha: .45),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'این کار همه رکوردهای ثبت‌شده را برای همیشه پاک می‌کند. قبل از آن حتماً بکاپ بگیرید.',
              style: TextStyle(fontSize: 12.5, height: 1.9),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.red),
              onPressed: _busy ? null : _wipe,
              icon: const Icon(Icons.delete_outline, size: 18),
              label: const Text('پاک کردن همه اطلاعات'),
            ),
          ]),
        ),

        if (_status.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _error ? AppColors.redBg : AppColors.greenBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(children: [
              Icon(_error ? Icons.error_outline : Icons.check_circle_outline,
                  size: 20,
                  color: _error ? AppColors.redText : AppColors.greenText),
              const SizedBox(width: 8),
              Expanded(
                child: Text(_status,
                    style: TextStyle(
                        fontSize: 12.5,
                        height: 1.8,
                        fontWeight: FontWeight.w700,
                        color:
                            _error ? AppColors.redText : AppColors.greenText)),
              ),
            ]),
          ),
        ],

        const SizedBox(height: 16),
        DataBuilder<Map<String, int>>(
          load: () async {
            final m = <String, int>{};
            for (final t in T.all) {
              m[t] = await AppDb.instance.count(t);
            }
            m[T.customers] = await AppDb.instance.count(T.customers);
            return m;
          },
          builder: (context, counts) => SectionCard(
            title: 'وضعیت فعلی دیتابیس',
            icon: Icons.storage,
            child: Column(children: [
              for (final e in counts.entries)
                KeyValueRow(T.labels[e.key] ?? e.key,
                    '${toPersianDigits(e.value)} رکورد'),
            ]),
          ),
        ),
      ],
    );
  }
}
