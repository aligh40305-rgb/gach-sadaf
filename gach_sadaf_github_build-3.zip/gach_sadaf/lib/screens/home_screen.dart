import 'package:flutter/material.dart';

import '../core/jalali.dart';
import '../core/motion.dart';
import '../core/theme.dart';
import '../services/settings_service.dart';
import 'backup_page.dart';
import 'customers_page.dart';
import 'dashboard_page.dart';
import 'expenses_page.dart';
import 'inventory_page.dart';
import 'lock_screen.dart';
import 'production_page.dart';
import 'report_page.dart';
import 'sales_page.dart';
import 'settings_page.dart';
import 'stones_page.dart';
import 'workers_page.dart';

class _NavItem {
  final String title;
  final IconData icon;
  final IconData iconOutline;
  final Color color;
  final Widget page;
  const _NavItem(this.title, this.icon, this.iconOutline, this.color, this.page);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  int _index = 0;
  DateTime? _leftAt;

  static const List<_NavItem> _items = [
    _NavItem('داشبورد', Icons.dashboard_rounded, Icons.dashboard_outlined, AppColors.navy,
        DashboardPage()),
    _NavItem('کارگران', Icons.engineering_rounded, Icons.engineering_outlined, AppColors.amber,
        WorkersPage()),
    _NavItem('خرید سنگ', Icons.landscape_rounded, Icons.landscape_outlined, AppColors.purple,
        StonesPage()),
    _NavItem('تولید', Icons.factory_rounded, Icons.factory_outlined, AppColors.amber,
        ProductionPage()),
    _NavItem('انبار', Icons.warehouse_rounded, Icons.warehouse_outlined, AppColors.navySoft,
        InventoryPage()),
    _NavItem('فروشات', Icons.point_of_sale_rounded, Icons.point_of_sale_outlined, AppColors.green,
        SalesPage()),
    _NavItem('مشتریان', Icons.people_alt_rounded, Icons.people_alt_outlined, AppColors.blue,
        CustomersPage()),
    _NavItem('مصارف', Icons.receipt_long_rounded, Icons.receipt_long_outlined, AppColors.red,
        ExpensesPage()),
    _NavItem('گزارش', Icons.description_rounded, Icons.description_outlined, AppColors.blue,
        ReportPage()),
    _NavItem('بکاپ', Icons.backup_rounded, Icons.backup_outlined, AppColors.green, BackupPage()),
    _NavItem('تنظیمات', Icons.settings_rounded, Icons.settings_outlined, AppColors.navySoft,
        SettingsPage()),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _backupReminder());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// قفل خودکار: اگر کاربر بیشتر از زمان تنظیم‌شده از برنامه دور بوده، دوباره پین می‌خواهد
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _leftAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final left = _leftAt;
      _leftAt = null;
      final minutes = Settings.instance.autoLockMinutes;
      if (left != null &&
          minutes > 0 &&
          DateTime.now().difference(left) >= Duration(minutes: minutes) &&
          mounted) {
        Navigator.pushReplacement(context, modernRoute(const LockScreen()));
      }
    }
  }

  void _backupReminder() {
    if (!Settings.instance.backupReminderDue) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.navyDark,
        duration: const Duration(seconds: 8),
        content: Row(children: [
          const Icon(Icons.info_outline_rounded, size: 18, color: AppColors.goldLight),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('یادآوری: مدتی است بکاپ نگرفته‌اید. بهتر است همین حالا بکاپ بگیرید.',
                style: TextStyle(fontSize: 12.5)),
          ),
        ]),
        action: SnackBarAction(
          label: 'بکاپ',
          textColor: AppColors.goldLight,
          onPressed: () => setState(() => _index = 9), // بکاپ
        ),
      ),
    );
  }

  void _go(int i) {
    setState(() => _index = i);
    Navigator.maybePop(context);
  }

  @override
  Widget build(BuildContext context) {
    final item = _items[_index];
    // ردیف پایین: داشبورد، فروشات، تولید، گزارش
    const bottomTargets = [0, 5, 3, 8];
    final bottomIndex = bottomTargets.indexOf(_index);

    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(gradient: AppColors.navyGradient),
        ),
        title: AnimatedSwitcher(
          duration: AppMotion.base,
          transitionBuilder: (child, anim) => FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween(begin: const Offset(0, .25), end: Offset.zero).animate(anim),
              child: child,
            ),
          ),
          child: Column(
            key: ValueKey(_index),
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              Text(Jalali.today().fullDisplay,
                  style: const TextStyle(fontSize: 11, color: Colors.white70)),
            ],
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'قفل کردن برنامه',
            icon: const Icon(Icons.lock_outline_rounded),
            onPressed: () => Navigator.pushReplacement(
              context,
              modernRoute(const LockScreen()),
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(context),
      body: IndexedStack(
        index: _index,
        children: [for (final it in _items) it.page],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: bottomIndex < 0 ? 0 : bottomIndex,
        onDestinationSelected: (i) => setState(() => _index = bottomTargets[i]),
        height: 66,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard_rounded),
              label: 'داشبورد'),
          NavigationDestination(
              icon: Icon(Icons.point_of_sale_outlined),
              selectedIcon: Icon(Icons.point_of_sale_rounded),
              label: 'فروشات'),
          NavigationDestination(
              icon: Icon(Icons.factory_outlined),
              selectedIcon: Icon(Icons.factory_rounded),
              label: 'تولید'),
          NavigationDestination(
              icon: Icon(Icons.description_outlined),
              selectedIcon: Icon(Icons.description_rounded),
              label: 'گزارش'),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 20),
            decoration: const BoxDecoration(gradient: AppColors.navyGradient),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.white24, width: 1.4),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset('assets/images/crest.png',
                        width: 54, height: 54, fit: BoxFit.cover),
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text('کارخانه گچ صدف',
                      style: TextStyle(
                          color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                ),
              ]),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${Settings.instance.owner}  •  ${toPersianDigits(Settings.instance.phone)}',
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ),
            ]),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              children: [
                for (var i = 0; i < _items.length; i++)
                  _DrawerTile(
                    item: _items[i],
                    active: _index == i,
                    onTap: () => _go(i),
                  ),
              ],
            ),
          ),
          Divider(height: 1, color: context.borderColor),
          const Padding(
            padding: EdgeInsets.all(14),
            child: Text('نسخه ۴.۰ موبایل  •  سازنده: انجنیر علی محمد غلامی',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 10.5, color: AppColors.textLight)),
          ),
        ]),
      ),
    );
  }
}

class _DrawerTile extends StatelessWidget {
  final _NavItem item;
  final bool active;
  final VoidCallback onTap;
  const _DrawerTile({required this.item, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Pressable(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadii.md),
        child: AnimatedContainer(
          duration: AppMotion.base,
          curve: AppMotion.enter,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(
            color: active ? item.color.withValues(alpha: context.isDark ? .22 : .12) : null,
            borderRadius: BorderRadius.circular(AppRadii.md),
            border: active ? Border.all(color: item.color.withValues(alpha: .35)) : null,
          ),
          child: Row(children: [
            AnimatedContainer(
              duration: AppMotion.base,
              width: 3,
              height: 18,
              margin: const EdgeInsetsDirectional.only(end: 10),
              decoration: BoxDecoration(
                color: active ? item.color : Colors.transparent,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            Icon(active ? item.icon : item.iconOutline,
                size: 20, color: active ? item.color : context.textSecondary),
            const SizedBox(width: 12),
            Expanded(
              child: Text(item.title,
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                    color: active ? item.color : context.textPrimary,
                  )),
            ),
            if (active) Icon(Icons.chevron_left_rounded, size: 18, color: item.color),
          ]),
        ),
      ),
    );
  }
}
