import 'package:flutter/material.dart';

import '../core/events.dart';
import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/customers.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../data/sales_repo.dart';
import '../services/customer_service.dart';
import '../services/inventory_service.dart';
import '../services/settings_service.dart';
import '../widgets/common.dart';
import '../widgets/entity_scaffold.dart';
import '../widgets/type_field.dart';

class SalesPage extends StatefulWidget {
  const SalesPage({super.key});

  @override
  State<SalesPage> createState() => _SalesPageState();
}

class _SalesPageState extends State<SalesPage> {
  static const Color _color = AppColors.green;
  bool _grouped = false;

  Future<List<Sale>> _load() => SalesRepo.all();

  @override
  Widget build(BuildContext context) {
    if (_grouped) return _buildGrouped();

    return EntityScaffold<Sale>(
      table: T.sales,
      color: _color,
      addLabel: 'ثبت فروش',
      searchHint: 'جستجو با اسم خریدار، موبایل یا تاریخ…',
      emptyText: 'هنوز فروشی ثبت نشده است',
      load: _load,
      topBar: _groupButton(),
      match: (r, q) => [r.buyer, r.phone, r.invNum, r.date, r.location]
          .any((f) => f.toLowerCase().contains(q.toLowerCase())),
      openForm: (ctx, rec) => openSaleForm(ctx, rec),
      card: (context, s) => saleCard(context, s),
    );
  }

  Widget _groupButton() => Align(
        alignment: AlignmentDirectional.centerStart,
        child: OutlinedButton.icon(
          onPressed: () => setState(() => _grouped = !_grouped),
          icon: Icon(_grouped ? Icons.list : Icons.groups, size: 18),
          label: Text(_grouped ? 'نمایش لیست عادی' : 'گروه‌بندی با مشتری',
              style: const TextStyle(fontSize: 12.5)),
        ),
      );

  Widget _buildGrouped() {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: _color,
        foregroundColor: Colors.white,
        onPressed: () => openSaleForm(context, null),
        icon: const Icon(Icons.add),
        label: const Text('ثبت فروش',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
          child: _groupButton(),
        ),
        Expanded(
          child: DataBuilder<List<Sale>>(
            load: _load,
            builder: (context, all) {
              if (all.isEmpty) {
                return const SingleChildScrollView(
                    child: EmptyState('هنوز فروشی ثبت نشده است'));
              }
              // گروه‌بندی بر اساس شناسهٔ مشتری (کد)؛ فروش‌های بدون مشتری بر اساس نام
              final groups = <String, List<Sale>>{};
              for (final s in all) {
                final key = s.customerId != null ? 'c${s.customerId}' : 'n${s.buyer.trim()}';
                groups.putIfAbsent(key, () => []).add(s);
              }
              final keys = groups.keys.toList()
                ..sort((a, b) => groups[a]!.first.buyer.compareTo(groups[b]!.first.buyer));
              return ListView(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
                children: [
                  for (final k in keys)
                    _CustomerGroup(name: groups[k]!.first.buyer, sales: groups[k]!),
                ],
              );
            },
          ),
        ),
      ]),
    );
  }
}

class _CustomerGroup extends StatelessWidget {
  final String name;
  final List<Sale> sales;
  const _CustomerGroup({required this.name, required this.sales});

  @override
  Widget build(BuildContext context) {
    final total = sales.fold<double>(0, (s, r) => s + r.total);
    final paid = sales.fold<double>(0, (s, r) => s + r.paid);
    final rem = sales.fold<double>(0, (s, r) => s + r.remaining);
    final cur = sales.first.cur;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        decoration: BoxDecoration(
          color: context.cardBg,
          borderRadius: BorderRadius.circular(AppRadii.lg),
          border: Border.all(color: context.borderColor),
        ),
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(horizontal: 14),
            childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            title: Text(name,
                style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: AppColors.greenText)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Wrap(spacing: 6, runSpacing: 4, children: [
                Pill.blue('${toPersianDigits(sales.length)} خرید'),
                Pill.amber('مجموع: ${fmtMoney(total, cur)}'),
                Pill.green('پرداخت: ${fmtMoney(paid, cur)}'),
                if (rem > 0) Pill.red('باقی: ${fmtMoney(rem, cur)}'),
              ]),
            ),
            children: [
              for (final s in sales)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: saleCard(context, s),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget saleCard(BuildContext context, Sale s) {
  final items = s.displayItems;
  return RecordCard(
    record: s,
    color: AppColors.green,
    title: s.buyer,
    subtitle: [
      if (s.phone.isNotEmpty) toPersianDigits(s.phone),
      if (s.location.isNotEmpty) s.location,
      showDate(s.date),
    ].join('  •  '),
    onEdit: () => openSaleForm(context, s),
    onBeforeDelete: () => SalesRepo.reverseStock(s),
    rows: [
      for (final it in items)
        KeyValueRow(
          '${it.type.isEmpty ? 'بدون نوعیت' : it.type}${it.weight > 0 ? ' • ${fmtNum(it.weight)} کیلویی' : ''}',
          '${fmtNum(it.qty)} × ${fmtNum(it.price)} = ${fmtNum(it.lineTotal)}',
        ),
      if (s.discount > 0) ...[
        KeyValueRow('جمع اقلام', fmtMoney(s.subtotal, s.cur)),
        KeyValueRow('تخفیف', '- ${fmtMoney(s.discount, s.cur)}',
            valueColor: AppColors.redText),
      ],
      KeyValueRow('مجموع فاکتور', fmtMoney(s.total, s.cur), big: true),
      Row(children: [
        Pill.green('پرداخت: ${fmtMoney(s.paid, s.cur)}'),
        const SizedBox(width: 8),
        if (s.remaining > 0)
          Pill.red('باقی: ${fmtMoney(s.remaining, s.cur)}')
        else
          Pill.green('تصفیه شده'),
      ]),
      if (s.truck.isNotEmpty) KeyValueRow('موتر تحویل', s.truck),
      const SizedBox(height: 6),
    ],
  );
}

/// یک قلم در فرم فاکتور (کنترلرهای متن)
class _ItemEd {
  final TextEditingController type;
  final TextEditingController weight;
  final TextEditingController qty;
  final TextEditingController price;

  _ItemEd({SaleItem? from})
      : type = TextEditingController(text: from?.type ?? ''),
        weight = TextEditingController(
            text: (from == null || from.weight == 0) ? '' : plainNum(from.weight)),
        qty = TextEditingController(
            text: (from == null || from.qty == 0) ? '' : plainNum(from.qty)),
        price = TextEditingController(text: _initialPrice(from));

  /// فروش‌های قدیمی که فقط مجموع داشتند: قیمت فی از روی مجموع/تعداد ساخته می‌شود
  static String _initialPrice(SaleItem? it) {
    if (it == null) return '';
    if (it.price > 0) return plainNum(it.price);
    if (it.qty > 0 && it.lineTotal > 0) {
      return plainNum(double.parse((it.lineTotal / it.qty).toStringAsFixed(4)));
    }
    return '';
  }

  double get w => toDouble(weight.text);
  double get q => toDouble(qty.text);
  double get p => toDouble(price.text);
  double get line => q * p;
  bool get isBlank => type.text.trim().isEmpty && w == 0 && q == 0 && p == 0;
}

Future<bool> openSaleForm(BuildContext context, Sale? existing) async {
  final s = existing ??
      Sale(
        cur: Settings.instance.defaultCurrency,
        date: Jalali.today().storage,
        time: nowTimeStorage(),
      );

  // اقلام قبلی (برای برگرداندن اثرشان روی انبار هنگام ویرایش)
  final oldItems = [for (final it in (existing?.displayItems ?? const <SaleItem>[])) it.copy()];
  final editors = <_ItemEd>[for (final it in oldItems) _ItemEd(from: it)];
  if (editors.isEmpty) editors.add(_ItemEd());

  final buyer = TextEditingController(text: s.buyer);
  final phone = TextEditingController(text: s.phone);
  final location = TextEditingController(text: s.location);
  final discount =
      TextEditingController(text: s.discount == 0 ? '' : plainNum(s.discount));
  final paid = TextEditingController(text: s.paid == 0 ? '' : plainNum(s.paid));
  final order = TextEditingController(text: s.orderType);
  final truck = TextEditingController(text: s.truck);

  double subtotal() => editors.fold(0.0, (a, e) => a + e.line);
  double total() {
    final t = subtotal() - toDouble(discount.text);
    return t < 0 ? 0 : t;
  }

  return openFormSheet(
    context: context,
    title: existing == null ? 'ثبت فاکتور فروش جدید' : 'ویرایش فاکتور فروش',
    icon: Icons.point_of_sale,
    color: AppColors.green,
    body: (ctx, refresh) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _CustomerHint(
        name: buyer.text,
        phone: phone.text,
        onPick: (c) {
          buyer.text = c.name;
          phone.text = c.phone;
          location.text = c.location;
          refresh();
        },
      ),
      FieldGrid(children: [
        AppField(
            controller: buyer,
            label: 'اسم و تخلص خریدار *',
            hint: 'اسم مشتری',
            onChanged: (_) => refresh()),
        AppField(
            controller: phone,
            label: 'شماره موبایل',
            number: true,
            keyboard: TextInputType.phone,
            onChanged: (_) => refresh()),
        AppField(controller: location, label: 'موقعیت مشتری', hint: 'مثلا: کابل'),
        JalaliField(
            label: 'تاریخ فاکتور',
            value: s.date,
            onChanged: (v) {
              s.date = v;
              refresh();
            }),
        TimeField(
            label: 'ساعت',
            value: s.time,
            onChanged: (v) {
              s.time = v;
              refresh();
            }),
      ]),
      const SizedBox(height: 16),
      Row(children: [
        Icon(Icons.list_alt_rounded, size: 19, color: ctx.accent),
        const SizedBox(width: 6),
        Text('اقلام فاکتور',
            style: TextStyle(
                fontSize: 14, fontWeight: FontWeight.w800, color: ctx.textPrimary)),
        const Spacer(),
        Pill.blue('${toPersianDigits(editors.length)} قلم'),
      ]),
      const SizedBox(height: 8),
      for (var i = 0; i < editors.length; i++)
        _ItemCard(
          key: ObjectKey(editors[i]),
          index: i,
          ed: editors[i],
          canRemove: editors.length > 1,
          onChanged: refresh,
          onRemove: () {
            editors.removeAt(i);
            refresh();
          },
        ),
      OutlinedButton.icon(
        onPressed: () {
          editors.add(_ItemEd());
          refresh();
        },
        icon: const Icon(Icons.add_rounded, size: 18),
        label: const Text('افزودن قلم دیگر'),
      ),
      const SizedBox(height: 16),
      SectionCard(
        title: 'مجموع فاکتور',
        icon: Icons.calculate_rounded,
        titleColor: AppColors.greenText,
        child: Column(children: [
          KeyValueRow('جمع اقلام', fmtMoney(subtotal(), s.cur)),
          const SizedBox(height: 6),
          FieldGrid(children: [
            AppDropdown(
              label: 'واحد پول',
              value: s.cur,
              items: kCurrencies,
              onChanged: (v) {
                s.cur = v ?? kAfghani;
                refresh();
              },
            ),
            AppField(
                controller: discount,
                label: 'تخفیف',
                number: true,
                onChanged: (_) => refresh()),
          ]),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.green,
              borderRadius: BorderRadius.circular(AppRadii.md),
            ),
            child: Row(children: [
              const Text('مجموع قابل پرداخت',
                  style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
              const Spacer(),
              Text(fmtMoney(total(), s.cur),
                  style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
            ]),
          ),
          const SizedBox(height: 10),
          FieldGrid(children: [
            AppField(
                controller: paid,
                label: 'پول پرداخت شده',
                number: true,
                onChanged: (_) => refresh()),
            AppField(
              controller: TextEditingController(
                  text: fmtMoney(total() - toDouble(paid.text), s.cur)),
              label: 'باقی مانده (خودکار)',
              readOnly: true,
              fill: AppColors.redBg,
              textColor: AppColors.redText,
            ),
          ]),
        ]),
      ),
      const SizedBox(height: 12),
      FieldGrid(children: [
        AppField(controller: order, label: 'توضیح فاکتور'),
        AppField(controller: truck, label: 'اسم یا نمبر موتر تحویل'),
      ]),
    ]),
    onSave: () async {
      if (buyer.text.trim().isEmpty) return 'اسم خریدار ضروری است';

      // اقلام معتبر؛ ردیف‌های کاملاً خالی نادیده گرفته می‌شوند
      final items = <SaleItem>[];
      for (var i = 0; i < editors.length; i++) {
        final e = editors[i];
        if (e.isBlank) continue;
        final n = toPersianDigits(i + 1);
        final type = normalizeGypsumType(e.type.text);
        if (type.isEmpty) return 'نوعیت گچ قلم $n را بنویسید';
        if (e.w <= 0) return 'وزن هر خلته در قلم $n را وارد کنید';
        if (e.q <= 0) return 'تعداد خلته در قلم $n را وارد کنید';
        items.add(SaleItem(
            type: type, weight: e.w, qty: e.q, price: e.p, lineTotal: e.q * e.p));
      }
      if (items.isEmpty) return 'حداقل یک قلم فاکتور (نوعیت، وزن و تعداد) را وارد کنید';

      final disc = toDouble(discount.text);
      final sub = items.fold(0.0, (a, it) => a + it.lineTotal);
      if (disc < 0) return 'تخفیف نمی‌تواند منفی باشد';
      if (disc > sub) return 'تخفیف از جمع اقلام بیشتر است';

      // موجودی انبار برای هر «نوع + وزن» (در ویرایش، اقلام قبلی همین فاکتور کسر می‌شود)
      String key(String t, double w) => '${AppDb.stockType(t)}|${AppDb.stockWeight(w)}';
      final need = <String, double>{};
      final sample = <String, SaleItem>{};
      for (final it in items) {
        final k = key(it.type, it.weight);
        need[k] = (need[k] ?? 0) + it.qty;
        sample[k] = it;
      }
      for (final it in oldItems) {
        final k = key(it.type, it.weight);
        if (need.containsKey(k)) need[k] = need[k]! - it.qty;
      }
      final shortages = <String>[];
      for (final e in need.entries) {
        if (e.value <= 0) continue;
        final it = sample[e.key]!;
        final available = await InventoryService.instance.qtyFor(it.type, it.weight);
        if (available - e.value < 0) {
          shortages.add(
              '• ${it.type} ${fmtNum(it.weight)} کیلویی: موجودی ${fmtNum(available)} خلته، لازم ${fmtNum(e.value)}');
        }
      }
      if (shortages.isNotEmpty) {
        if (!context.mounted) return 'موجودی انبار کافی نیست';
        final proceed = await confirmDialog(
          context,
          title: 'موجودی انبار کافی نیست',
          message: '${shortages.join('\n')}\nآیا با وجود این، همین فاکتور ثبت شود؟',
          okText: 'بلی، ثبت شود',
        );
        if (!proceed) return 'ثبت فاکتور لغو شد';
      }

      s
        ..buyer = buyer.text.trim()
        ..phone = phone.text.trim()
        ..location = location.text.trim()
        ..discount = disc
        ..paid = toDouble(paid.text)
        ..orderType = order.text.trim()
        ..truck = truck.text.trim();
      s.applyItems(items);

      // مشتری: نام + شماره قبلاً ثبت بود ← همان رکورد؛ مشتری تکراری ساخته نمی‌شود
      final match = await CustomerService.instance.findOrCreate(
        name: buyer.text,
        phone: phone.text,
        location: location.text,
      );
      if (match == null) return 'اسم خریدار ضروری است';
      s
        ..customerId = match.customer.id
        ..buyer = match.customer.name
        ..phone = match.customer.phone
        ..location = match.customer.location;

      await SalesRepo.save(s, oldItems: oldItems);
      return null;
    },
  );
}

/// کارت یک قلم در فرم فاکتور
class _ItemCard extends StatelessWidget {
  final int index;
  final _ItemEd ed;
  final bool canRemove;
  final VoidCallback onChanged;
  final VoidCallback onRemove;

  const _ItemCard({
    super.key,
    required this.index,
    required this.ed,
    required this.canRemove,
    required this.onChanged,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: context.cardBg,
        borderRadius: BorderRadius.circular(AppRadii.md),
        border: Border.all(color: context.borderColor),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
                shape: BoxShape.circle, color: AppColors.green),
            child: Text(toPersianDigits(index + 1),
                style: const TextStyle(
                    color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 8),
          Text('قلم ${toPersianDigits(index + 1)}',
              style: TextStyle(
                  fontSize: 13, fontWeight: FontWeight.w800, color: context.textPrimary)),
          const Spacer(),
          if (canRemove)
            IconButton(
              tooltip: 'حذف این قلم',
              visualDensity: VisualDensity.compact,
              onPressed: onRemove,
              icon: const Icon(Icons.delete_outline_rounded, size: 20, color: AppColors.red),
            ),
        ]),
        const SizedBox(height: 10),
        TypeField(controller: ed.type, onChanged: onChanged),
        _StockHint(
          type: ed.type.text,
          selectedWeight: ed.w,
          onPick: (w) {
            ed.weight.text = plainNum(w);
            onChanged();
          },
        ),
        const SizedBox(height: 10),
        FieldGrid(children: [
          AppField(
              controller: ed.weight,
              label: 'وزن هر خلته (کیلو) *',
              number: true,
              onChanged: (_) => onChanged()),
          AppField(
              controller: ed.qty,
              label: 'تعداد خلته *',
              number: true,
              onChanged: (_) => onChanged()),
          AppField(
              controller: ed.price,
              label: 'قیمت فی خلته',
              number: true,
              onChanged: (_) => onChanged()),
          AppField(
            controller: TextEditingController(text: fmtNum(ed.line)),
            label: 'مبلغ این قلم (خودکار)',
            readOnly: true,
            fill: AppColors.greenBg,
            textColor: AppColors.greenText,
          ),
        ]),
      ]),
    );
  }
}

/// موجودی انبار برای نوع گچ نوشته‌شده — به‌تفکیک وزن هر خلته؛ با لمس، همان وزن پر می‌شود
class _StockHint extends StatelessWidget {
  final String type;
  final double selectedWeight;
  final ValueChanged<double> onPick;
  const _StockHint({
    required this.type,
    required this.selectedWeight,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    if (type.trim().isEmpty) return const SizedBox.shrink();

    return FutureBuilder<List<StockItem>>(
      future: InventoryService.instance.forType(type),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final items = snap.data!;
        if (items.isEmpty) {
          return Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text('برای «${normalizeGypsumType(type)}» هنوز موجودی‌ای در انبار نیست',
                style: const TextStyle(
                    fontSize: 11.5, color: AppColors.redText, fontWeight: FontWeight.w700)),
          );
        }
        return Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.warehouse_rounded, size: 15, color: context.accent),
              const SizedBox(width: 5),
              Text('موجودی انبار — برای انتخاب وزن لمس کنید',
                  style: TextStyle(fontSize: 11, color: context.textSecondary)),
            ]),
            const SizedBox(height: 6),
            Wrap(spacing: 8, runSpacing: 6, children: [
              for (final it in items)
                ActionChip(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => onPick(it.weight),
                  backgroundColor:
                      AppDb.stockWeight(it.weight) == AppDb.stockWeight(selectedWeight)
                          ? context.accent.withValues(alpha: .22)
                          : context.cardBgAlt,
                  side: BorderSide(
                      color: it.qty <= 0 ? AppColors.red : context.borderColor),
                  avatar: Icon(Icons.inventory_2_rounded,
                      size: 14, color: it.qty <= 0 ? AppColors.red : AppColors.green),
                  label: Text(
                    it.weight > 0
                        ? '${fmtNum(it.weight)} کیلویی: ${fmtNum(it.qty)} خلته'
                        : 'بدون وزن: ${fmtNum(it.qty)} خلته',
                    style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        color: it.qty <= 0 ? AppColors.redText : context.textPrimary),
                  ),
                ),
            ]),
          ]),
        );
      },
    );
  }
}

/// وضعیت مشتری هنگام ثبت فروش: مشتری موجود / مشتری جدید + پیشنهاد مشتریان مشابه
class _CustomerHint extends StatelessWidget {
  final String name;
  final String phone;
  final ValueChanged<Customer> onPick;
  const _CustomerHint({required this.name, required this.phone, required this.onPick});

  @override
  Widget build(BuildContext context) {
    final hasName = name.trim().isNotEmpty;
    final hasPhone = normalizePhone(phone).length >= 3;
    if (!hasName && !hasPhone) return const SizedBox.shrink();

    return FutureBuilder<CustomerPreview>(
      future: CustomerService.instance.preview(name, phone),
      builder: (context, snap) {
        final p = snap.data;
        if (p == null) return const SizedBox.shrink();

        final exists = p.match != null;
        final color = exists ? AppColors.greenText : AppColors.blue;
        final bg = exists ? AppColors.greenBg : AppColors.blueBg;

        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (hasName)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: context.isDark ? color.withValues(alpha: .16) : bg,
                  borderRadius: BorderRadius.circular(AppRadii.md),
                ),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(exists ? Icons.verified_user_rounded : Icons.person_add_alt_1_rounded,
                      size: 18, color: color),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      exists
                          ? 'مشتری موجود — کد ${toPersianDigits(p.match!.id)} • '
                              '${toPersianDigits(p.matchSalesCount)} خرید قبلی. '
                              'این فروش به همان مشتری وصل می‌شود و مشتری تکراری ساخته نمی‌شود.'
                          : 'مشتری جدید — بعد از ثبت فروش با یک کد تازه در لیست مشتریان ذخیره می‌شود.',
                      style: TextStyle(
                          fontSize: 11.5, height: 1.7, fontWeight: FontWeight.w700, color: color),
                    ),
                  ),
                ]),
              ),
            if (p.suggestions.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('مشتریان مشابه — برای انتخاب لمس کنید:',
                  style: TextStyle(fontSize: 11, color: context.textSecondary)),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 6, children: [
                for (final c in p.suggestions)
                  ActionChip(
                    onPressed: () => onPick(c),
                    avatar: Icon(Icons.person_rounded, size: 15, color: context.accent),
                    label: Text(
                      c.phone.isEmpty ? c.name : '${c.name} • ${toPersianDigits(c.phone)}',
                      style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
                    ),
                  ),
              ]),
            ],
          ]),
        );
      },
    );
  }
}
