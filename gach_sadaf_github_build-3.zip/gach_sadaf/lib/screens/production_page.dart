import 'package:flutter/material.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/theme.dart';
import '../data/customers.dart';
import '../data/db.dart';
import '../data/models.dart';
import '../services/inventory_service.dart';
import '../widgets/common.dart';
import '../widgets/entity_scaffold.dart';
import '../widgets/type_field.dart';

class ProductionPage extends StatelessWidget {
  const ProductionPage({super.key});

  static const Color _color = AppColors.amber;

  Future<List<Production>> _load() async =>
      (await AppDb.instance.rows(T.production)).map(Production.fromMap).toList();

  @override
  Widget build(BuildContext context) {
    return EntityScaffold<Production>(
      table: T.production,
      color: _color,
      addLabel: 'ثبت تولید',
      searchHint: 'جستجو با تاریخ یا نوعیت گچ…',
      emptyText: 'هنوز تولیدی ثبت نشده است',
      load: _load,
      match: (r, q) => [r.date, r.type, r.invNum]
          .any((f) => f.toLowerCase().contains(q.toLowerCase())),
      openForm: (ctx, rec) => _openProductionForm(ctx, rec),
      card: (context, pr) => RecordCard(
        record: pr,
        color: _color,
        title: showDate(pr.date),
        subtitle: showText(pr.type),
        onEdit: () => _openProductionForm(context, pr),
        onBeforeDelete: () =>
            InventoryService.instance.adjust(pr.type, pr.bagWeight, -pr.gunny),
        rows: [
          KeyValueRow('تعداد خلته', '${fmtNum(pr.gunny)} خلته', big: true),
          KeyValueRow('وزن هر خلته', '${fmtNum(pr.bagWeight)} کیلو'),
          KeyValueRow('وزن کل تولید', '${fmtNum(pr.totalWeight)} کیلو',
              valueColor: AppColors.amber, big: true),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

Future<bool> _openProductionForm(BuildContext context, Production? existing) async {
  final pr = existing ?? Production(date: Jalali.today().storage);
  final oldType = existing?.type ?? '';
  final oldGunny = existing?.gunny ?? 0;
  final oldWeight = existing?.bagWeight ?? 0;
  final typeC = TextEditingController(text: pr.type);
  final gunny = TextEditingController(text: pr.gunny == 0 ? '' : plainNum(pr.gunny));
  final weight =
      TextEditingController(text: pr.bagWeight == 0 ? '' : plainNum(pr.bagWeight));

  return openFormSheet(
    context: context,
    title: existing == null ? 'ثبت تولید جدید' : 'ویرایش تولید',
    icon: Icons.factory,
    color: AppColors.amber,
    body: (ctx, refresh) => FieldGrid(children: [
      JalaliField(
        label: 'تاریخ تولید *',
        value: pr.date,
        onChanged: (v) {
          pr.date = v;
          refresh();
        },
      ),
      TypeField(controller: typeC, onChanged: refresh),
      AppField(
          controller: gunny,
          label: 'تعداد خلته',
          number: true,
          onChanged: (_) => refresh()),
      AppField(
        controller: weight,
        label: 'وزن هر خلته (کیلو)',
        number: true,
        onChanged: (_) => refresh(),
      ),
      AppField(
        controller: TextEditingController(
            text: '${fmtNum(toDouble(gunny.text) * toDouble(weight.text))} کیلو'),
        label: 'وزن کل تولید (خودکار)',
        readOnly: true,
        fill: AppColors.amberBg,
        textColor: AppColors.amber,
      ),
    ]),
    onSave: () async {
      if (pr.date.trim().isEmpty) return 'تاریخ تولید ضروری است';
      if (toDouble(gunny.text) <= 0) return 'تعداد خلته را وارد کنید';
      if (toDouble(weight.text) <= 0) return 'وزن هر خلته را وارد کنید (برای انبار لازم است)';
      pr.type = normalizeGypsumType(typeC.text);
      if (pr.type.isEmpty) return 'نوعیت گچ را بنویسید';
      pr.gunny = toDouble(gunny.text);
      pr.bagWeight = toDouble(weight.text);

      if (pr.id == null) {
        pr.invNum = await AppDb.instance.nextInvoiceNumber(T.production);
        await AppDb.instance.insert(T.production, pr.toMap());
        await InventoryService.instance.adjust(pr.type, pr.bagWeight, pr.gunny);
      } else {
        await AppDb.instance.update(T.production, pr.id!, pr.toMap());
        await InventoryService.instance.move(
          fromType: oldType,
          fromWeight: oldWeight,
          fromDelta: -oldGunny,
          toType: pr.type,
          toWeight: pr.bagWeight,
          toDelta: pr.gunny,
        );
      }
      return null;
    },
  );
}
