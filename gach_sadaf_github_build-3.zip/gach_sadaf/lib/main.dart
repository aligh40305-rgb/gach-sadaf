import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/theme.dart';
import 'core/theme_mode.dart';
import 'screens/lock_screen.dart';
import 'services/auth_service.dart';
import 'services/settings_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await Settings.instance.init();
  await Auth.instance.init();
  // اکنون که تنظیمات خوانده شده، حالت روشن/تاریک ذخیره‌شده را بار می‌کنیم
  appThemeMode.value = _initialThemeMode();
  runApp(const GachSadafApp());
}

ThemeMode _initialThemeMode() {
  switch (Settings.instance.themeModeStorage) {
    case 'light':
      return ThemeMode.light;
    case 'dark':
      return ThemeMode.dark;
    default:
      return ThemeMode.system;
  }
}

class GachSadafApp extends StatelessWidget {
  const GachSadafApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: appThemeMode,
      builder: (context, mode, _) => MaterialApp(
        title: 'گچ صدف',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        darkTheme: buildAppDarkTheme(),
        themeMode: mode,
        themeAnimationDuration: const Duration(milliseconds: 260),
        themeAnimationCurve: Curves.easeOutCubic,
        home: const LockScreen(),
        builder: (context, child) => Directionality(
          textDirection: TextDirection.rtl,
          child: MediaQuery.withClampedTextScaling(
            minScaleFactor: 0.9,
            maxScaleFactor: 1.2,
            child: child!,
          ),
        ),
      ),
    );
  }
}
