#!/usr/bin/env python3
"""بعد از `flutter create .` اجرا می‌شود و پروژه اندروید را برای برنامه آماده می‌کند."""
import glob, os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
app = os.path.join(root, "android", "app")
main = os.path.join(app, "src", "main")

def rw(path, fn):
    with open(path, encoding="utf-8") as f:
        s = f.read()
    n = fn(s)
    if n != s:
        with open(path, "w", encoding="utf-8") as f:
            f.write(n)
        print("patched", os.path.relpath(path, root))

# 1) Manifest: مجوزها + نام فارسی
def manifest(s):
    perms = ('    <uses-permission android:name="android.permission.USE_BIOMETRIC"/>\n'
             '    <uses-permission android:name="android.permission.USE_FINGERPRINT"/>\n')
    if "USE_BIOMETRIC" not in s:
        s = s.replace("<application", perms + "    <application", 1)
    s = re.sub(r'android:label="[^"]*"', 'android:label="گچ صدف"', s, count=1)
    return s
rw(os.path.join(main, "AndroidManifest.xml"), manifest)

# 2) MainActivity -> FlutterFragmentActivity (لازم برای اثر انگشت)
for f in glob.glob(os.path.join(main, "kotlin", "**", "MainActivity.kt"), recursive=True) + \
         glob.glob(os.path.join(main, "java", "**", "MainActivity.java"), recursive=True):
    rw(f, lambda s: s.replace("FlutterActivity", "FlutterFragmentActivity"))

# 3) تم AppCompat
for path, parent in [(os.path.join(main, "res", "values", "styles.xml"), "Theme.AppCompat.Light.NoActionBar"),
                     (os.path.join(main, "res", "values-night", "styles.xml"), "Theme.AppCompat.NoActionBar")]:
    if os.path.exists(path):
        rw(path, lambda s, p=parent: re.sub(r'parent="@android:style/Theme[^"]*"', f'parent="{p}"', s))

# 4) minSdk = 23
for g in ("build.gradle", "build.gradle.kts"):
    p = os.path.join(app, g)
    if os.path.exists(p):
        rw(p, lambda s: s.replace("flutter.minSdkVersion", "23"))

# 5) آیکن برنامه از crest.png
try:
    from PIL import Image
    src = Image.open(os.path.join(root, "assets", "images", "crest.png")).convert("RGB")
    for folder, size in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
        d = os.path.join(main, "res", f"mipmap-{folder}")
        os.makedirs(d, exist_ok=True)
        src.resize((size, size)).save(os.path.join(d, "ic_launcher.png"))
    print("launcher icons written")
except Exception as e:
    print("icon step skipped:", e)
